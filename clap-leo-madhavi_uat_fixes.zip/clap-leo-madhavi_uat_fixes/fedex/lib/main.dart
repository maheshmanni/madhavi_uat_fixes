import 'package:fedex_app/routes.dart';
import 'package:fedex_app/utility/common_provider.dart';
import 'package:fedex_app/utility/services/base_service.dart';
import 'package:fedex_app/utility/theme_colors.dart';
import 'package:fedex_app/view/login_user/LoginScreen.dart';
import 'package:fedex_app/view/login_user/auth_okta_service.dart';

import 'package:fedex_app/viewmodel/user_view_model.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:provider/provider.dart';
import 'local_notification/notification_service.dart';

import 'viewmodel/custom_appbar_viewmodel.dart';
import 'viewmodel/individual_lead_viewmodel.dart';
import 'viewmodel/lead_list_view_model.dart';
import 'viewmodel/new_lead_viewmodel.dart';
import 'package:flutter_flavor/flutter_flavor.dart';
import 'package:easy_localization/easy_localization.dart';

// class MyHttpOverrides extends HttpOverrides {
//   @override
//   HttpClient createHttpClient(SecurityContext? context) {
//     return super.createHttpClient(context)
//       ..badCertificateCallback =
//           (X509Certificate cert, String host, int port) => true;
//   }
// }

//BaseURL
String baseUrl = "https://alps-gateway-dev.app.singdev1.paas.fedex.com/";

//OKTA Configs
String oktaDomain = "purpleid-test.oktapreview.com";
String oktaAuthorizer = 'aus14jeflq47cJVW20h8';
String oktaClientId = '0oa14rsfrccHjQtHi0h8';

String oktaIssuerUrl = 'https://$oktaDomain/oauth2/$oktaAuthorizer';
String oktaDiscoveryUrl =
    'https://$oktaDomain/oauth2/$oktaAuthorizer/.well-known/oauth-authorization-server';

void main() async {
  FlavorConfig(
    name: "Clap-dev",
    variables: {
      "baseUrl": baseUrl,
      "okta_domain": oktaDomain,
      "oktaAuthorizer": oktaAuthorizer,
      "oktaClientId": oktaClientId,
      "oktaIssuerUrl": oktaIssuerUrl,
      "oktaDiscoveryUrl": oktaDiscoveryUrl
    },
  );
  SystemChrome.setSystemUIOverlayStyle(const SystemUiOverlayStyle(
    statusBarColor: Colors.transparent,
  ));
  //HttpOverrides.global = MyHttpOverrides();

  // var httpClient = new HttpClient();
  // httpClient.findProxy = (url) {
  //   return HttpClient.findProxyFromEnvironment(url, environment: {
  //     "HTTP_PROXY": 'http://sin-proxy.apac.fedex.com:3128',
  //     "HTTPS_PROXY": 'http://sin-proxy.apac.fedex.com:3128',
  //     "NO_PROXY":
  //         '*.apac.fedex.com,*.paas.fedex.com,10.44.39.*,localhost,127.0.0.1,::1'
  //   });
  // };

  WidgetsFlutterBinding.ensureInitialized();
  await init();
  runApp(EasyLocalization(
    path: 'assets/language',
    supportedLocales: const [
      Locale('en'),
      Locale('ja'),
      Locale('id'),
      Locale('ko'),
      Locale('my'),
      Locale('th'),
      Locale.fromSubtags(
          languageCode: "zh", scriptCode: "Hant", countryCode: "zh_Hans_CN"),
      Locale.fromSubtags(
          languageCode: "zh", scriptCode: "Hant", countryCode: "zh_Hans_HK"),
      Locale.fromSubtags(
          languageCode: "zh", scriptCode: "Hant", countryCode: "zh_Hans_TW"),
      Locale('vi')
    ],
    fallbackLocale: const Locale('en'),
    useOnlyLangCode: true,
    saveLocale: true,
    //assetLoader: const CodegenLoader(),
    child: const MyApp(),
  ));
}

Future init() async {
  LocalNotificationService().init();
  await EasyLocalization.ensureInitialized();
}

class MyApp extends StatefulWidget {
  const MyApp({Key? key}) : super(key: key);

  @override
  _MyAppState createState() => _MyAppState();
}

class _MyAppState extends State<MyApp> {
  //fetch config data according build flavors
  String baseURL = FlavorConfig.instance.variables["baseUrl"];

  String oktaDomain = FlavorConfig.instance.variables["okta_domain"];
  String oktaAuthorizer = FlavorConfig.instance.variables["oktaAuthorizer"];
  String oktaClientId = FlavorConfig.instance.variables["oktaClientId"];
  String oktaIssuerUrl = FlavorConfig.instance.variables["oktaIssuerUrl"];
  String oktaDiscoveryUrl = FlavorConfig.instance.variables["oktaDiscoveryUrl"];

  // _MyAppState({Key? key}) : super(key: key);

  final ThemeData appColorTheme = buildAppTheme();
  // This widget is the root of your application.

  @override
  void initState() {
    debugPrint('MyAppState');
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    debugPrint("baseurl is : $baseURL");
    debugPrint("okta domain : $oktaDomain");

    BaseService.baseAccountUrl = baseURL;
    BaseService.baseUrl = baseURL;

    AuthOktaService.OKTA_DOMAIN = oktaDomain;
    AuthOktaService.OKTA_AUTHORIZER = oktaAuthorizer;
    AuthOktaService.OKTA_CLIENT_ID = oktaClientId;
    AuthOktaService.OKTA_ISSUER_URL = oktaIssuerUrl;
    AuthOktaService.OKTA_DISCOVERY_URL = oktaDiscoveryUrl;

    return MultiProvider(
      providers: [
        //
        ChangeNotifierProvider.value(value: LeadListViewModel()),
        ChangeNotifierProvider.value(value: CustomAppBarViewModel()),
        ChangeNotifierProvider.value(value: LocalNotificationService()),
        ChangeNotifierProvider.value(value: UserViewModel()),
        ChangeNotifierProvider.value(value: NewLeadViewModel()),
        ChangeNotifierProvider.value(value: CommonProvider()),
        ChangeNotifierProvider.value(value: IndividualLeadSubmitedViewmodel()),
      ],
      child: MaterialApp(
          debugShowCheckedModeBanner: false,
          title: 'ALPS',
          theme: appColorTheme,
          // home: const NewLeadPage(),

          initialRoute: LoginScreen.routeName,
          routes: routes,
          supportedLocales: context.supportedLocales,
          localizationsDelegates: context.localizationDelegates,
          locale: context.locale),
    );
  }
}
