import 'package:easy_localization/easy_localization.dart';
import 'package:fedex_app/model/api_repository.dart';
import 'package:fedex_app/model/lead_list_model.dart';
import 'package:fedex_app/utility/services/base_service.dart';
import 'package:flutter/material.dart';
import 'package:rxdart/rxdart.dart';
import 'package:shared_preferences/shared_preferences.dart';

class LeadListViewModel with ChangeNotifier {
  late final _apiRepository = APiRepository();
  final _leadListFetcher = PublishSubject<LeadListModel>();
  final List<int> pageSizeArr = [
    1,
    2,
    3,
    4,
    5,
    6,
    7,
    8,
    9,
    10,
  ];

  List<Status> statusFilterList = <Status>[
    Status('All', 'all'.tr()),
    Status('1', 'toBeFollowedUpByInsideSalesDCR'.tr()),
    Status('2', 'insideSalesDCRAssigned'.tr()),
    Status('3', 'sucessfulAccountOpening'.tr()),
    Status('4', 'failedToOpenAccount'.tr()),
    Status('5', 'invalidLead'.tr()),
    Status('6', 'moveToOpenAC'.tr()),
    Status('7', 'invalidLeadOrFailedToOpenAccount'.tr()),
  ];

//   userRole :
//    {"1" : "COURIER",
// "2": "LMD",
// "3" : "DISPATCH",
// "4": "SALES",
// "5": "SALES_CO_ORDINATOR",
// "6": "SUPPORT",
// "7": "ADMIN",
// "8": "STATION_MANAGER",
// "9":"SENIOR_STATION_MANAGER",
// "10": "MANAGING_DIRECTOR",
// "11": "VICE_PRESIDENT",
// "12": "SENIOR_VICE_PRESIDENT "} //346

  String? checkStatus(String? str) {
    if (str == '1') {
      return 'toBeFollowedUpByInsideSalesDCR'.tr();
    } else if (str == '2') {
      return 'insideSalesDCRAssigned'.tr();
    } else if (str == '3') {
      return 'sucessfulAccountOpening'.tr();
    } else if (str == '4') {
      return 'failedToOpenAccount'.tr();
    } else if (str == '5') {
      return 'invalidLead'.tr();
    } else if (str == '6') {
      return 'moveToOpenAC'.tr();
    } else if (str == '7') {
      return 'invalidLeadOrFailedToOpenAccount'.tr();
    }
    return '';
  }

  getEmpNumber() async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.getString('employeeNumber')!;
  }

  int selectedPageSize = 10;
  int pageNumber = 1;
  int fromPageSize = 1;
  int toPageSize = 10;
  int totalRecords = 0;
  String dateFilter = '';
  String sortFilter = 'All';
  String statusFilter = 'All';
  String sortByAscDesc = 'DESC';

  Stream<LeadListModel> get leadList => _leadListFetcher.stream;

  Future<void> fetchLeadListData(String url, int pageNumber, int pageSize,
      status, dateStr, sortyBy, sortorder) async {
    final body = {
      "filters": {
        "admin": false,
        "countryCode": "${await getCountryCode()}",
        "date": dateStr,
        "deptNumber": [""],
        "sortBy": sortyBy,
        "sortorder": sortorder,
        "status": status,
        "support": false,
        "userIds": ["${await getEmpNumber()}"],
        "userRole": {"1": "COURIER"}
      },
      "pageNumber": pageNumber,
      "pageSize": pageSize
    };
    //["${await getEmpNumber()}"]
    debugPrint('JSON_BODY : {$body}');
    final prefs = await SharedPreferences.getInstance();
    String? token = prefs.getString('accessToken');

    debugPrint('access token from prefs : {$token}');

    dynamic response =
        await _apiRepository.fetchLeadListDetail(url, body, token!);
    //219162
    LeadListModel _leadListModel = LeadListModel.fromJson(response);
    if (_leadListModel.serviceStatus!.statusCode == 200) {
      _leadListFetcher.sink.add(_leadListModel);
    } else {
      debugPrint("error_mesage: ${_leadListModel.serviceStatus?.message}");
    }
  }

  getCountryCode() async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.getString('countryCode') ?? " ";
  }

  paginationCalulation(ViewLeadPagination leadPagination) {
    totalRecords = leadPagination.totalRecords!;
    pageNumber = leadPagination.pageNumber!;
    selectedPageSize = leadPagination.pageSize!;

    fromPageSize = (pageNumber - 1) * selectedPageSize + 1;
    toPageSize = pageNumber * selectedPageSize;
    toPageSize = toPageSize > totalRecords ? totalRecords : toPageSize;
  }

  onSelectPageSize(pageSize) {
    selectedPageSize = pageSize;
    pageNumber = 1;
    read();
  }

  onSelectNextPage() {
    pageNumber = pageNumber + 1;
    read();
  }

  onSelectPreviousPage() {
    pageNumber = pageNumber - 1;
    read();
  }

  onSelectFirstPage() {
    pageNumber = 1;
    read();
  }

  onSelectLastPage() {
    pageNumber = getLastPageNumber();
    read();
  }

  onFilterSubmit(sortBy, status, date, ascDesc) {
    sortFilter = sortBy;
    statusFilter = status;
    dateFilter = date;
    sortByAscDesc = ascDesc;
    debugPrint(
        'onFilterSubmit : $sortFilter+' '+$statusFilter+' '+$dateFilter');
    read();
  }

  onSortByAll(sortBy, ascDesc) {
    sortFilter = sortBy;
    sortByAscDesc = ascDesc;
    read();
  }

  onSortByStatus(sortBy, ascDesc) {
    sortFilter = sortBy;
    sortByAscDesc = ascDesc;
    read();
  }

  onSortByDate(sortBy, ascDesc) {
    sortFilter = sortBy;
    sortByAscDesc = ascDesc;
    read();
  }

  int getLastPageNumber() {
    int quitant = totalRecords ~/ selectedPageSize;
    return (totalRecords % selectedPageSize) == 0 ? quitant : quitant + 1;
  }

  read() {
    //https://clap-leads-dev.app.singdev1.paas.fedex.com/lead/lead-list

    fetchLeadListData(BaseService.leadSubmitedList, pageNumber,
        selectedPageSize, statusFilter, dateFilter, sortFilter, sortByAscDesc);

    debugPrint('pageNumber : $pageNumber');
    debugPrint('pageSize :$selectedPageSize');
    debugPrint('date : $dateFilter');
    debugPrint('sortBy : $sortFilter');
    debugPrint('status : $statusFilter');
    debugPrint('sortorder : $sortByAscDesc');
  }

  Future getDateTimeFromPicker(context) async {
    DateTime? newDateTime = await showDatePicker(
      context: context,
      initialDate: DateTime.now(),
      firstDate: DateTime(DateTime.now().year - 3),
      lastDate: DateTime(DateTime.now().year + 3),
      //borderRadius: 16,
    );

    final dateString = DateFormat('MM/dd/yy').format(newDateTime!);
    debugPrint('Date_selected : $dateString');
// var dateString = format.format(DateTime.now());
    return dateString;
  }

  @override
  // ignore: must_call_super
  dispose() {
    _leadListFetcher.close();
  }

  //   '',
}

class Status {
  const Status(this.id, this.name);

  final String name;
  final String id;
}
