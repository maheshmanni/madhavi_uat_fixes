import 'package:fedex_app/model/api_repository.dart';
import 'package:fedex_app/model/kpi_date_status.dart';
import 'package:fedex_app/model/kpi_report_newlead.dart';
import 'package:fedex_app/model/kpi_reports_accounts.dart';
import 'package:fedex_app/utility/apis/api_response.dart';
import 'package:fedex_app/utility/services/base_service.dart';
import 'package:flutter/material.dart';
import 'package:rxdart/rxdart.dart';
import 'package:shared_preferences/shared_preferences.dart';

class KPIReportsViewModel with ChangeNotifier {
  ApiResponse _apiResponse = ApiResponse.initial('no data');

  final kpiReportsReponse = PublishSubject<KPIReportNewLead>();
  Stream<KPIReportNewLead> get kpiReportsResponse => kpiReportsReponse.stream;

  final kpiAccountsDataReponse = PublishSubject<KpiAccountsData>();
  Stream<KpiAccountsData> get kpiAccountsdata => kpiAccountsDataReponse.stream;

  final kpiReportsMonthRes = PublishSubject<KpiDateStatusResponse>();
  Stream<KpiDateStatusResponse> get kpiReportsMonthResponse =>
      kpiReportsMonthRes.stream;

  ApiResponse get response {
    return _apiResponse;
  }

  getEmpNumber() async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.getString('employeeNumber')!;
  }

  readNewLeadData(String month) {
    fetchKPIReportsNewLeadData(month);
  }

  readExistingAccountData(
    String month,
  ) {
    fetchKPIReportsAccountsData(month);
  }
//{required Function successCallback, required Function failureCallback}

  Future<void> fetchKPIReportsNewLeadData(
    month,
  ) async {
    _apiResponse = ApiResponse.loading('Fetching user data');
    final body = {
      "month": month,
      "userId": "${await getEmpNumber()}",
      "userRole": {"1": "COURIER"}
    };

    try {
      final prefs = await SharedPreferences.getInstance();
      String? token = prefs.getString('accessToken');

      KPIReportNewLead kpiReports = await APiRepository()
          .fetchKPIReportsNewLead(BaseService.kpiReportsNewLead, body, token!);

      if (kpiReports.serviceStatus?.statusCode == 200) {
        _apiResponse = ApiResponse.completed(kpiReports);
        kpiReportsReponse.sink.add(kpiReports);
        debugPrint('json_encode_kpi_newlead : $kpiReports');
        //notifyListeners();
        return _apiResponse.data;
      } else {
        _apiResponse = ApiResponse.error(kpiReports);
        kpiReportsReponse.sink.add(kpiReports);
        return _apiResponse.data;
      }
    } catch (e) {
      _apiResponse = ApiResponse.error(e);
      //notifyListeners();

      return debugPrint('user api error: ${e.toString()}');
    }
  }

  Future<void> fetchKPIReportsAccountsData(
    month,
  ) async {
    _apiResponse = ApiResponse.loading('Fetching user data');
    final body = {
      "month": month,
      "routeNumber": "${await getRouteNumber()}",
      "userId": "${await getEmpNumber()}",
      "userRole": {"1": "COURIER"}
    };
    debugPrint("JSON-BODY : $body");
    try {
      final prefs = await SharedPreferences.getInstance();
      String? token = prefs.getString('accessToken');

      KpiAccountsData kpiReports = await APiRepository()
          .fetchKPIReportsAccounts(
              BaseService.kpiReportsAccounts, body, token!);
      debugPrint('kpiReports-response : ${kpiReports.responseData}');
      if (kpiReports.serviceStatus?.statusCode == 200) {
        _apiResponse = ApiResponse.completed(kpiReports);
        kpiAccountsDataReponse.sink.add(kpiReports);
        debugPrint('response : $kpiReports');
        //notifyListeners();
        return _apiResponse.data;
      } else {
        _apiResponse = ApiResponse.error(kpiReports);
        //notifyListeners();
        return _apiResponse.data;
      }
    } catch (e) {
      _apiResponse = ApiResponse.error(e);
      //notifyListeners();

      return debugPrint('user api error: ${e.toString()}');
    }
  }

  Future<void> fetchKpiNewleadMonths(
      {required Function successCallback,
      required Function failureCallback}) async {
    try {
      final prefs = await SharedPreferences.getInstance();
      String? token = prefs.getString('accessToken');

      KpiDateStatusResponse individualLead = await APiRepository()
          .fetchKpiNewleadMonths(BaseService.kpiReportsNewLeadMonths, token!);
      if (individualLead.serviceStatus?.statusCode == 200) {
        kpiReportsMonthRes.sink.add(individualLead);
        _apiResponse = ApiResponse.completed(individualLead);
        notifyListeners();
        return successCallback(_apiResponse);
        //
      } else {
        return failureCallback(_apiResponse);
      }
    } catch (e) {
      _apiResponse = ApiResponse.error(e.toString());
      return failureCallback(_apiResponse);
    }
  }

  Future<void> fetchKpiAccountsMonths(
      {required Function successCallback,
      required Function failureCallback}) async {
    try {
      final prefs = await SharedPreferences.getInstance();
      String? token = prefs.getString('accessToken');

      KpiDateStatusResponse individualLead = await APiRepository()
          .fetchKpiAccountsMonths(BaseService.kpiReportsAccountsMonths, token!);
      if (individualLead.serviceStatus?.statusCode == 200) {
        kpiReportsMonthRes.sink.add(individualLead);
        _apiResponse = ApiResponse.completed(individualLead);
        notifyListeners();
        return successCallback(_apiResponse);
        //
      } else if (individualLead.serviceStatus?.statusCode == 502) {
        kpiReportsMonthRes.sink.add(individualLead);
        _apiResponse = ApiResponse.completed(individualLead);
        notifyListeners();
        return successCallback(_apiResponse);
      } else {
        return failureCallback(_apiResponse);
      }
    } catch (e) {
      _apiResponse = ApiResponse.error(e.toString());
      return failureCallback(_apiResponse);
    }
  }

  int getTimeDifference(endDateStr) {
    debugPrint('getTimeDifference endDateStr: $endDateStr');
    int sec;
    if (endDateStr != null) {
      DateTime? currentDate = DateTime.now();
      DateTime? endDate = DateTime.tryParse(endDateStr);
      sec = endDate != null ? endDate.difference(currentDate).inSeconds : 0;
      debugPrint('getTimeDifference: $sec');
      if (sec < 0) sec = 0;
    } else {
      sec = 0;
    }

    return sec;
  }

  getRouteNumber() async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.getString('routeNumber') ?? " ";
  }
}
