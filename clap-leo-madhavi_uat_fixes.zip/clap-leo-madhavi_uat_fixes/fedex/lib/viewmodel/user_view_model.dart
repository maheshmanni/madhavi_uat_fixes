import 'package:fedex_app/model/api_repository.dart';
import 'package:fedex_app/model/user_model.dart';
import 'package:fedex_app/utility/apis/api_response.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

class UserViewModel with ChangeNotifier {
  ApiResponse _apiResponse = ApiResponse.initial('no data');

  ApiResponse get response {
    return _apiResponse;
  }

  getCountryCode() async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.getString('OKTACountryCode') ?? " ";
  }

  Future<void> fetchUserData(String stationId, String routeNumber,
      {required Function successCallback,
      required Function failureCallback}) async {
    _apiResponse = ApiResponse.loading('Fetching user data');

    final body = {
      "countryCode": "${await getCountryCode()}",
      "routerNumber": routeNumber,
      "stationCode": stationId
    };

    try {
      final prefs = await SharedPreferences.getInstance();
      String? token = prefs.getString('accessToken');

      UserConfirmationModel user = await APiRepository()
          .fetchUserConfirmationDetail('lead/station', body, token!);

      if (user.serviceStatus?.statusCode == 200) {
        await setPreferenceData(
            stationId,
            routeNumber,
            user.responseData?.data?.countryCode,
            user.responseData?.data?.postalAwareMarket,
            user.responseData?.data?.dcrEnabled);
        _apiResponse = ApiResponse.completed(user);
        //notifyListeners();
        return successCallback(_apiResponse);
      } else {
        _apiResponse = ApiResponse.error(user);
        //notifyListeners();
        return failureCallback(_apiResponse);
      }
    } catch (e) {
      _apiResponse = ApiResponse.error(e);
      //notifyListeners();
      debugPrint('user api error: ${e.toString()}');
      return failureCallback(null);
    }
  }

  setPreferenceData(
      stationid, routeNo, countryCode, postalAwareMarket, dcrEnabled) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString('stationId', '$stationid');
    await prefs.setString('routeNumber', '$routeNo');
    await prefs.setString('countryCode', countryCode);
    await prefs.setBool('postalAwareMarket', postalAwareMarket);
    await prefs.setBool('dcrEnabled', dcrEnabled);
    debugPrint('Get CountryCode for UserConfirmation: $countryCode');
  }
}
