import 'dart:async';

import 'package:fedex_app/local_notification/notification_service.dart';
import 'package:fedex_app/model/api_repository.dart';
import 'package:fedex_app/model/notification_response.dart';
import 'package:fedex_app/utility/apis/api_response.dart';
import 'package:fedex_app/utility/services/base_service.dart';
import 'package:flutter/material.dart';
import 'package:rxdart/rxdart.dart';
import 'package:shared_preferences/shared_preferences.dart';

class CustomAppBarViewModel with ChangeNotifier {
  LocalNotificationService notificationService = LocalNotificationService();
  ApiResponse _apiResponse = ApiResponse.initial('no data');
  final _apiRepository = APiRepository();
  final _notificationListFetcher = PublishSubject<NotificationResponse>();
  NotificationResponse? notificationResponse;
  Stream<NotificationResponse> get notificationList =>
      _notificationListFetcher.stream;
  ApiResponse get response {
    return _apiResponse;
  }

  int totalNotificationCount = 0;

  set setTotalNotificationCount(int value) {
    totalNotificationCount = value;
    debugPrint('setTotalNotificationCount : $totalNotificationCount');
    notifyListeners();
  }

  int count = 0;
  Timer? timer;

  Future<void> checkNotificationTimer() async {
    try {
      timer = Timer.periodic(
        const Duration(seconds: 120),
        (Timer tmr) {
          if (timer!.isActive) {
            read();
            debugPrint('Timer : ${timer!.isActive}');
          } else {
            debugPrint('CheckTimer : ${timer!.isActive}');
          }
        },
      );
    } catch (e) {
      debugPrint('CheckActivi_error: ${timer!.isActive}');
    }
  }

  //Get from Lead individual details
  Future<void> fetchNotificationDetails(String submitterID,
      {required Function successCallback,
      required Function failureCallback}) async {
    try {
      final prefs = await SharedPreferences.getInstance();
      String? token = prefs.getString('accessToken');
      NotificationResponse individualLead =
          await _apiRepository.fetchNotificationDetails(
              BaseService.notification(submitterID), token!);
      debugPrint('notification api : ${BaseService.notification(submitterID)}');
      if (individualLead.serviceStatus?.statusCode == 200) {
        //Check services status code 200
        _notificationListFetcher.sink.add(individualLead);
        _apiResponse = ApiResponse.completed(individualLead);
        notifyListeners();
        return successCallback(_apiResponse);
        //
      } else {
        return failureCallback(_apiResponse);
      }
    } catch (e) {
      _apiResponse = ApiResponse.error(e.toString());
      debugPrint('notification api error: $e');
      return failureCallback(_apiResponse);
    }
  }

  //Get from Lead individual details
  Future<void> readNotificationDetails(String? body, int? leadIOD, leadNoteOID,
      String? title, String? type, String? from,
      {required Function successCallback,
      required Function failureCallback}) async {
    final jsonbody = [
      {
        "id": leadIOD,
        "title": title,
        "body": body,
        "type": type,
        "from": from,
        "noteOID": leadNoteOID
      }
    ];
    try {
      final prefs = await SharedPreferences.getInstance();
      String? token = prefs.getString('accessToken');

      NotificationResponse individualLead = await _apiRepository
          .readNotification(BaseService.readNotification(), jsonbody, token!);
      if (individualLead.serviceStatus?.statusCode == 200) {
        //Check services status code 200
        // read();
        _apiResponse = ApiResponse.completed(individualLead);
        notifyListeners();

        return successCallback(_apiResponse);
        //fv
      } else {
        _apiResponse = ApiResponse.error(individualLead);
        notifyListeners();
        return failureCallback(_apiResponse);
      }
    } catch (e) {
      _apiResponse = ApiResponse.error(e.toString());
      debugPrint('notification api error: $e');
      return;
    }
  }

//54763
  read() {
    getEmpNumber().then((value) {
      if (value != null) {
        fetchNotificationDetails(value,
            successCallback: success, failureCallback: failure);
      }
    });
  }

  getEmpNumber() async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.getString('employeeNumber')!;
  }

  success(response) {
    getnotificationDetail(response);
  }

  failure() {
    getnotificationDetail(response);
  }

  Future<void> getnotificationDetail(ApiResponse apiResponse) async {
    notificationResponse = apiResponse.data;
    switch (apiResponse.status) {
      case Status.LOADING:
        return debugPrint('Loading...');
      case Status.COMPLETED:
        {
          var notificationList = notificationResponse?.responseData?.data!;
          count = notificationList!.length;
          setTotalNotificationCount = count;
          // debugPrint('notificationCounts : ${count}');
          // Future.delayed(const Duration(seconds: 120), () {
          //   notificationService.showNotifications(
          //       count++,
          //       notificationList[i].title.toString(),
          //       notificationList[i].body.toString());
          // });
          for (int i = 0; i < notificationList.length; i++) {}

          return debugPrint(
              'Success... ${notificationResponse?.responseData?.data}');
        }
      case Status.ERROR:
        // ignore: unused_local_variable
        String msg = 'Please try again latter!';
        if (notificationResponse != null) {
          msg = notificationResponse!.serviceStatus!.message!;
        }
        return debugPrint('Error: Please try again latter!');
      case Status.INITIAL:
      // break;
    }
  }
}
