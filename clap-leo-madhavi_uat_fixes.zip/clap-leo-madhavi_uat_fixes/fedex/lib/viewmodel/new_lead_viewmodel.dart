// ignore_for_file: avoid_unnecessary_containers

import 'dart:convert';
import 'package:easy_localization/easy_localization.dart';
import 'package:fedex_app/model/api_repository.dart';
import 'package:fedex_app/model/fileupload_response.dart';
import 'package:fedex_app/model/new_lead_model.dart';
import 'package:fedex_app/utility/apis/api_response.dart';
import 'package:fedex_app/utility/constant.dart';
import 'package:fedex_app/utility/services/base_service.dart';
import 'package:fedex_app/utility/styles.dart';
import 'package:fedex_app/view/lead_submitted/lead_submitted_page.dart';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'dart:async';
import 'dart:io';
import 'package:http_parser/http_parser.dart';
import 'package:path/path.dart';
import 'package:async/async.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../model/delete_file.dart';

class CustometTitle {
  const CustometTitle(this.id, this.name);

  final String name;
  final String id;
}

class NewLeadViewModel with ChangeNotifier {
  ApiResponse _apiResponse = ApiResponse.initial('no data');
  List<LeadDocuments>? leadUploaddoclist = [];

  List<CustometTitle> customerTitleList = <CustometTitle>[
    CustometTitle('Mr', 'mr'.tr()),
    CustometTitle('Mrs', 'mrs'.tr()),
    CustometTitle('Miss', 'miss'.tr()),
    CustometTitle('Dr', 'dr'.tr()),
  ];
  ApiResponse get response {
    return _apiResponse;
  }

  removeFileListItem(index) {
    leadUploaddoclist?.removeAt(index);
    notifyListeners();
    debugPrint('Photo_list : ${leadUploaddoclist?.length}');
  }

  getEmpNumber() async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.getString('employeeNumber') ?? "";
  }

  getEmpName() async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.getString('userName') ?? " ";
  }

  Future<void> postLeadGenerate(Lead newLead, String apiEndPoint,
      {required Function successCallback,
      required Function failureCallback}) async {
    _apiResponse = ApiResponse.loading('Fetching user data');
    notifyListeners();

    final jsonBody = {
      "address1": newLead.address1,
      "address2": newLead.address2,
      "city": newLead.city,
      "companyName": newLead.companyName,
      "contactMobile": newLead.contactMobile,
      "contactPhone": newLead.contactPhone,
      "customerTitle": newLead.customerTitle,
      "email": newLead.email,
      "endReason": newLead.endReason,
      "firstName": newLead.firstName,
      "lastName": newLead.lastName,
      "leadDocuments": newLead.leadDocuments,
      "locationCode": newLead.locationCode,
      "managerId": newLead.managerId,
      "postalCode": newLead.postalCode,
      "readyForAccountOpening": newLead.readyForAccountOpening,
      "remark": newLead.remark,
      "routerNumber": newLead.routerNumber,
      "status": newLead.status,
      "submitterUserId": "${await getEmpNumber()}",
      "submitterUserName": "${await getEmpName()}",
    };
    debugPrint('Json_Body: $jsonBody');
    debugPrint('doc_json: ${newLead.leadDocuments}');

    // "submitterUserId": "${await getEmpNumber()}",
    // "submitterUserName": "${await getEmpName()}",

    try {
      final prefs = await SharedPreferences.getInstance();
      String? token = prefs.getString('accessToken');
      LeadResponseData _leadResData =
          await APiRepository().fetchNewLeadData(apiEndPoint, jsonBody, token!);

      if (_leadResData.serviceStatus?.statusCode == 200) {
        _apiResponse = ApiResponse.completed(_leadResData);
        notifyListeners();
        return successCallback(_apiResponse);
      } else if (_leadResData.serviceStatus?.statusCode == 201) {
        _apiResponse = ApiResponse.completed(_leadResData);
        notifyListeners();
        return successCallback(_apiResponse);
      } else {
        notifyListeners();
        _apiResponse = ApiResponse.error(_leadResData);
        debugPrint('user api error response: $_apiResponse');
        return failureCallback(_apiResponse);
      }
    } catch (e) {
      _apiResponse = ApiResponse.error(e.toString());
      debugPrint('user api error: $e');
      return failureCallback(_apiResponse);
    }
  }

  Future<void> deleteFile(
    String docKeys,
  ) async {
    _apiResponse = ApiResponse.loading('Fetching user data');
    notifyListeners();

    final jsonBody = [docKeys];

    try {
      final prefs = await SharedPreferences.getInstance();
      String? token = prefs.getString('accessToken');
      DeleteFile _deletefile = await APiRepository()
          .deleteFileUploaded(BaseService.deleteDocument, jsonBody, token!);

      if (_deletefile.serviceStatus?.statusCode == 200) {
        _apiResponse = ApiResponse.completed(_deletefile);
        notifyListeners();
        return;
      } else {
        notifyListeners();
        _apiResponse = ApiResponse.error(_deletefile);
        return;
      }
    } catch (e) {
      _apiResponse = ApiResponse.error(e.toString());
      return;
    }
  }

  validateMobile(String value) {
    RegExp regExp = RegExp(Constant.pattternPhone);
    if (value.length < 8) {
      return 'Please enter mobile number';
    } else if (!regExp.hasMatch(value)) {
      return 'Please enter valid mobile number';
    }
    return null;
  }

  validateEmail(String value) {
    RegExp regex = RegExp(Constant.patternEmailAddress);
    if (!regex.hasMatch(value.trimLeft())) {
      return 'Enter Valid Email';
    } else {
      return null;
    }
  }

  showSucessfullyDialog(
      BuildContext ctx, String statusMessage, Color backgroundclr) async {
    return showDialog<void>(
      context: ctx,
      barrierDismissible: true, // user must tap button!
      builder: (BuildContext context) {
        return Container(
          child: AlertDialog(
            backgroundColor: backgroundclr,
            title: Container(
              decoration: const BoxDecoration(),
              child: Text('Message', style: Styles.titleWhiteTextWithF20W700),
            ),
            content: SingleChildScrollView(
              child: ListBody(
                children: <Widget>[
                  Container(
                    child: Text(statusMessage,
                        style: Styles.titleWhiteTextWithF12W700),
                  ),
                  const Text(''),
                ],
              ),
            ),
            actions: <Widget>[
              TextButton(
                onPressed: () {
                  Navigator.pop(context);
                  Navigator.pushNamed(context, LeadSubmittedPage.routeName);
                },
                child: Text('submit'.tr(),
                    style: Styles.titleWhiteTextWithF12W700),
              ),
            ],
          ),
        );
      },
    );
  }

  showLoadingDialog(
      BuildContext ctx, String statusMessage, Color backgroundclr) async {
    return showDialog<void>(
      context: ctx,
      barrierDismissible: true, // user must tap button!
      builder: (BuildContext context) {
        return Container(
          child: AlertDialog(
            backgroundColor: backgroundclr,
            title: Container(
              decoration: const BoxDecoration(),
              child: Text('Message', style: Styles.titleWhiteTextWithF20W700),
            ),
            content: SingleChildScrollView(
              child: ListBody(
                children: <Widget>[
                  const CircularProgressIndicator(
                    color: Colors.red,
                  ),
                  Container(
                    child: Text(statusMessage,
                        style: Styles.titleWhiteTextWithF12W700),
                  ),
                  const Text('Loading...'),
                ],
              ),
            ),
          ),
        );
      },
    );
  }

  Future<FileUploadResponse> uploadImageFile(
      String xFilePath, String docType) async {
    final prefs = await SharedPreferences.getInstance();
    String? token = prefs.getString('accessToken');
    String empNumber = await getEmpNumber();
    FileUploadResponse? fileResponse;
    File imageFile = File(xFilePath);
    // ignore: deprecated_member_use
    var stream = http.ByteStream(DelegatingStream.typed(imageFile.openRead()));
    var length = await imageFile.length();
    String uploadURL = BaseService.baseUrl + BaseService.leadUploadDocument;
    debugPrint('uploadURL : $uploadURL');
    var uri = Uri.parse(uploadURL);

    var request = http.MultipartRequest("POST", uri);
    var multipartFile = http.MultipartFile('file', stream, length,
        filename: basename(imageFile.path),
        contentType: MediaType('image', 'png'));
    request.headers['Authorization'] = 'Bearer $token';
    request.files.add(multipartFile);
    var response = await request.send();
    debugPrint('token: $token');
    response.stream.transform(utf8.decoder).listen((value) {
      Map<String, dynamic> res = jsonDecode(value);
      fileResponse = FileUploadResponse.fromJson(res);
      debugPrint('response:== ${fileResponse?.responseData?.data?.key}');
      debugPrint('docKey: ${fileResponse?.responseData?.data?.key}');
      debugPrint('docName: ${fileResponse?.responseData?.data?.fileName}');
      debugPrint('docType: $docType');
      debugPrint('size: ${fileResponse?.responseData?.data?.size.toString()}');

      debugPrint('EmpNumber: $empNumber');

      leadUploaddoclist!.add(LeadDocuments(
        docKey: fileResponse?.responseData?.data?.key,
        docName: fileResponse?.responseData?.data?.fileName,
        docType: docType,
        size: fileResponse?.responseData?.data?.size.toString(),
        uploadUID: empNumber,
      ));
    });
    notifyListeners();
    return fileResponse!;
  }

  String getDocKey(String filename) {
    String dockey = "";
    for (int i = 0; i < leadUploaddoclist!.length; i++) {
      String str1 = leadUploaddoclist![i].docName.toString();
      if (filename == str1) {
        dockey = leadUploaddoclist![i].docKey.toString();
      }
    }
    return dockey;
  }
}
