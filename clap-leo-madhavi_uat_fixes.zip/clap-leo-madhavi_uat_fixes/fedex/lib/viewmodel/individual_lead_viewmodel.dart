// ignore: file_names
import 'dart:convert';
import 'dart:io';
import 'dart:typed_data';

import 'package:easy_localization/easy_localization.dart';
import 'package:fedex_app/model/account_existing_update.dart';
import 'package:fedex_app/model/add_comments.dart';
import 'package:fedex_app/model/api_repository.dart';
import 'package:fedex_app/model/individual_account_model.dart';
import 'package:fedex_app/model/individual_lead_model.dart';
import 'package:fedex_app/utility/apis/api_response.dart';
import 'package:fedex_app/utility/common_urls.dart';
import 'package:fedex_app/utility/constant.dart';
import 'package:fedex_app/utility/services/base_service.dart';
import 'package:flutter/cupertino.dart';
import 'package:image_gallery_saver/image_gallery_saver.dart';
import 'package:path_provider/path_provider.dart';
import 'package:rxdart/rxdart.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../model/file_download.dart';

class IndividualLeadSubmitedViewmodel with ChangeNotifier {
  //
  List<AccountPenetrationStatus> statusUpdateList = [
    AccountPenetrationStatus('0', 'select'.tr()),
    AccountPenetrationStatus('1', 'rejectToEnrol'.tr()),
    AccountPenetrationStatus('2', 'agreeToEnrol'.tr()),
  ];

  List<AccountPenetrationStatus> accountUpdateReasonList = [
    AccountPenetrationStatus('0', 'select'.tr()),
    AccountPenetrationStatus('1', 'unreachable'.tr()),
    AccountPenetrationStatus('2', 'notInterested'.tr()),
    AccountPenetrationStatus('3', 'notApplicable'.tr()),
    AccountPenetrationStatus('4', 'businessMoved'.tr()),
    AccountPenetrationStatus('5', 'noPackage'.tr()),
    AccountPenetrationStatus('6', 'other_provide'.tr()),
  ];

  String fileTitleLocal(String? str) {
    if (str == Constant.businessRegistration) {
      return 'businessRegistration'.tr();
    } else if (str == Constant.acOpeningForm) {
      return 'acOpeningForm'.tr();
    } else if (str == Constant.businessCard) {
      return 'businessCard'.tr();
    } else if (str == Constant.other) {
      return 'other'.tr();
    }
    return '';
  }

  bool isAddCommentsCheck(String str) {
    if (str == '1') {
      return true;
    } else if (str == '2') {
      return true;
    } else if (str == '3') {
      return false;
    } else if (str == '4') {
      return false;
    } else if (str == '5') {
      return true;
    } else if (str == '6') {
      return false;
    } else if (str == '7') {
      return true;
    }
    return true;
  }

  String? checkStatus(String? str) {
    if (str == '1') {
      return 'toBeFollowedUpByInsideSalesDCR'.tr();
    } else if (str == '2') {
      return 'insideSalesDCRAssigned'.tr();
    } else if (str == '3') {
      return 'sucessfulAccountOpening'.tr();
    } else if (str == '4') {
      return 'failedToOpenAccount'.tr();
    } else if (str == '5') {
      return 'invalidLead'.tr();
    } else if (str == '6') {
      return 'moveToOpenAC'.tr();
    } else if (str == '7') {
      return 'invalidLeadOrFailedToOpenAccount'.tr();
    }
    return '';
  }

  String? checkEndResonStatusForInvalidLead(String? str) {
    if (str == '1') {
      return 'personalAccount'.tr();
    } else if (str == '2') {
      return 'ineligibleToJoin'.tr();
    } else if (str == '3') {
      return 'alreadHaveAFedexAccount'.tr();
    } else if (str == '4') {
      return 'locatedInNSARegion'.tr();
    } else if (str == '5') {
      return 'duplicateLeadSubmission'.tr();
    } else if (str == '6') {
      return 'customerWithOutIntrest'.tr();
    } else if (str == '7') {
      return 'invalidContact'.tr();
    } else if (str == '8') {
      return 'nonprofitOrganization'.tr();
    } else if (str == '9') {
      return 'industryAssociation'.tr();
    } else if (str == '10') {
      return 'others2'.tr();
    }
    return '';
  }

  String? checkEndResonStatusForInvalidAndFaileToOpen(String? str) {
    if (str == '1') {
      return 'alreadEngageWithCustomer'.tr();
    } else if (str == '2') {
      return 'corporateDecisionAccountRestricition'.tr();
    } else if (str == '3') {
      return 'insuffecientIncorrectDetails'.tr();
    } else if (str == '4') {
      return 'noOportunityForAdditionalBusiness'.tr();
    } else if (str == '5') {
      return 'notDecisionMaker'.tr();
    } else if (str == '6') {
      return 'notInterestedPricing'.tr();
    } else if (str == '7') {
      return 'notInterestedServives'.tr();
    } else if (str == '8') {
      return 'notInteerestedTransitTime'.tr();
    } else if (str == '9') {
      return 'notINterestedOthers'.tr();
    } else if (str == '10') {
      return 'outOfBusinessClosedBankruptcy'.tr();
    } else if (str == '11') {
      return 'notReachable'.tr();
    } else if (str == '12') {
      return 'others2'.tr();
    }

    return '';
  }

  String? checkEndResonStatusForFailedToOpenAccountEndReasons(String? str) {
    if (str == '1') {
      return 'discountIsNotGoodEnough'.tr();
    } else if (str == '2') {
      return 'notYetDecided'.tr();
    } else if (str == '3') {
      return 'notExpressUser'.tr();
    } else if (str == '4') {
      return 'personalForwarderJeweller'.tr();
    } else if (str == '5') {
      return 'decidedByConsignee'.tr();
    } else if (str == '6') {
      return 'incrrectContactInfo'.tr();
    } else if (str == '7') {
      return 'othersCommentsAreMandatory'.tr();
    }

    return '';
  }

  final _apiRepository = APiRepository();
  final _leadListFetcher = PublishSubject<IndividualLeadResponse>();
  ApiResponse _apiResponse = ApiResponse.initial('no data');
  Stream<IndividualLeadResponse> get leadList => _leadListFetcher.stream;

  final _accountDetailFetcher = PublishSubject<IndividualAccountModel>();
  Stream<IndividualAccountModel> get accountDetail =>
      _accountDetailFetcher.stream;
  //
  ApiResponse get response {
    return _apiResponse;
  }

//Get from Lead individual details
  Future<void> fetchExistingAccountLeadDetailsData(leadOid,
      {required Function successCallback,
      required Function failureCallback}) async {
    try {
      final prefs = await SharedPreferences.getInstance();
      String? token = prefs.getString("accessToken");

      IndividualAccountModel individualAccount =
          await _apiRepository.fetchAccountDetails(
              token!, BaseService.existingleadIndividual(leadOid),
              baseURL: BaseService.baseAccountUrl);
      //
      if (individualAccount.serviceStatus?.statusCode == 200) {
        //Check services status code 200

        _accountDetailFetcher.sink.add(individualAccount);
        _apiResponse = ApiResponse.completed(individualAccount);

        return successCallback(_apiResponse);
        //
      } else {
        _apiResponse = ApiResponse.completed(individualAccount);
        notifyListeners();

        return failureCallback(_apiResponse);
      }
    } catch (e) {
      _apiResponse = ApiResponse.error(e.toString());
      return failureCallback(_apiResponse);
    }
  }

  Future<void> updateExistingAccountLeadDetailsData(accountOID, status,
      {required Function successCallback,
      required Function failureCallback}) async {
    try {
      final prefs = await SharedPreferences.getInstance();
      String? token = prefs.getString("accessToken");

      AccountExistingUpdate accountExistingUpdate =
          await _apiRepository.updateExistingAccountPenetration(token!,
              BaseService.existingleadIndividualUpdated(accountOID, status),
              baseURL: BaseService.baseAccountUrl);
      //
      if (accountExistingUpdate.serviceStatus?.statusCode == 200) {
        //Check services status code 200

        _apiResponse = ApiResponse.completed(accountExistingUpdate);
        notifyListeners();
        return successCallback(_apiResponse);
        //
      } else {
        //notifyListeners();
        return failureCallback(_apiResponse);
      }
    } catch (e) {
      _apiResponse = ApiResponse.error(e.toString());
      return failureCallback(_apiResponse);
    }
  }

  //Get from Lead individual details
  Future<void> fetchLeadDetailsData(String leadOid,
      {required Function successCallback,
      required Function failureCallback}) async {
    try {
      final prefs = await SharedPreferences.getInstance();
      String? token = prefs.getString("accessToken");

      IndividualLeadResponse individualLead = await _apiRepository
          .fetchLeadDetails(token!, BaseService.leadIndividual(leadOid));
      //
      if (individualLead.serviceStatus?.statusCode == 200) {
        //Check services status code 200
        _leadListFetcher.sink.add(individualLead);
        _apiResponse = ApiResponse.completed(individualLead);
        notifyListeners();
        return successCallback(_apiResponse);
        //
      } else {
        _apiResponse = ApiResponse.completed(individualLead);
        notifyListeners();
        return failureCallback(_apiResponse);
      }
    } catch (e) {
      _apiResponse = ApiResponse.error(e.toString());
      return failureCallback(_apiResponse);
    }
  }

  getEmpNumber() async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.getString('employeeNumber')!;
  }

  getEmpName() async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.getString('userName')!;
  }

  Future<void> updateStatusComments(
      AccountDetails? accountDetails, comments, status, endreason,
      {required Function successCallback,
      required Function failureCallback}) async {
    final body = {
      "accountOIDs": [accountDetails!.accountOID],
      "comment": comments,
      "endReason": endreason,
      "status": status
    };

    notifyListeners();
    try {
      _apiResponse = ApiResponse.loading('updating status - comments');

      final prefs = await SharedPreferences.getInstance();
      String? token = prefs.getString('accessToken');

      AccountExistingUpdate addComments = await APiRepository()
          .fetchExistingAccountStatusUpdate(
              BaseService.existingleadStatusCommentsUpdate, body, token!);

      if (addComments.serviceStatus?.status == true) {
        _apiResponse = ApiResponse.completed(addComments);
        notifyListeners();
        return successCallback(_apiResponse);
      } else {
        _apiResponse = ApiResponse.error(addComments);
        notifyListeners();
        return failureCallback(_apiResponse);
      }
    } catch (e) {
      _apiResponse = ApiResponse.error(e.toString());
      return failureCallback(_apiResponse);
    }
  }

  Future<void> fetchLeadComments(LeadDetails? leadDetails, String comments,
      {required Function successCallback,
      required Function failureCallback}) async {
    String currentDateStr =
        getCurrentDateTimeFormat("yyyy-MM-dd'T'HH:mm:ss.SSS");

    final body = {
      "accountNumber": "",
      "address1": leadDetails!.address1,
      "address2": leadDetails.address2,
      "city": leadDetails.city,
      "clapLeadOid": leadDetails.leadOID,
      "comment": comments,
      "companyName": leadDetails.companyName,
      "contactMobile": leadDetails.contactMobile,
      "contactPhone": leadDetails.contactPhone,
      "customerTitle": leadDetails.customerTitle,
      "email": leadDetails.email,
      "firstName": leadDetails.firstName,
      "lastName": leadDetails.lastName,
      "leadEndReason": leadDetails.endReason,
      "leadNoteOID": 0,
      "leadStatus": leadDetails.status,
      "postalCode": leadDetails.postalCode,
      "receiverName": "",
      "receiverTimestamp": currentDateStr,
      "receiverUid": "",
      "sendTimeStamp": currentDateStr,
      "statusUpdated": true,
      "submitterUserId": "${await getEmpNumber()}",
      "submitterUserName": "${await getEmpName()}",
      "userRole": {"1": "COURIER"}
    };
    //"submitterUserId": "${await getEmpNumber()}",
    // "submitterUserName": "${await getEmpName()}",

    notifyListeners();
    try {
      _apiResponse = ApiResponse.loading('Fetching add- comments');

      final prefs = await SharedPreferences.getInstance();
      String? token = prefs.getString('accessToken');

      CommentsResponseModel addComments = await APiRepository()
          .fetchAddComments(BaseService.leadNotes, body, token!);

      if (addComments.serviceStatus?.status == true) {
        _apiResponse = ApiResponse.completed(addComments);
        notifyListeners();
        return successCallback(_apiResponse);
      } else {
        _apiResponse = ApiResponse.error(addComments);
        notifyListeners();
        return failureCallback(_apiResponse);
      }
    } catch (e) {
      _apiResponse = ApiResponse.error(e.toString());
      return failureCallback(_apiResponse);
    }
  }

  //Get from Lead individual details
  Future<void> fetchDownloadDocument(String docKey,
      {required Function successCallback,
      required Function failureCallback}) async {
    try {
      final prefs = await SharedPreferences.getInstance();
      String? token = prefs.getString('accessToken');

      FileDownloadResponse fileDownloadResponse = await _apiRepository
          .getFileDownload(BaseService.leadDownloadDocument(docKey), token!);
      //
      if (fileDownloadResponse.serviceStatus?.statusCode == 200) {
        //Check services status code 200

        _apiResponse = ApiResponse.completed(fileDownloadResponse);
        notifyListeners();
        return successCallback(_apiResponse);
        //
      } else {
        _apiResponse = ApiResponse.completed(fileDownloadResponse);
        notifyListeners();
        return failureCallback(_apiResponse);
      }
    } catch (e) {
      _apiResponse = ApiResponse.error(e.toString());
      return failureCallback(_apiResponse);
    }
  }

  Future<String> imageSaveInGallery(String encodeStr) async {
    Uint8List bytes = base64.decode(encodeStr);
    String dir = (await getApplicationDocumentsDirectory()).path;

    String fullpath = dir;
    File file = File(fullpath);
    await file.writeAsBytes(bytes);
    // ignore: unused_local_variable
    final result = await ImageGallerySaver.saveImage(bytes);
    return file.path;
  }
}

class AccountPenetrationStatus {
  const AccountPenetrationStatus(this.id, this.name);

  final String name;
  final String id;
}
