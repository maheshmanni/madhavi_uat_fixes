import 'package:easy_localization/easy_localization.dart';
import 'package:fedex_app/model/account_penetration.dart';
import 'package:fedex_app/model/account_time_frame.dart';
import 'package:fedex_app/model/api_repository.dart';
import 'package:fedex_app/utility/services/base_service.dart';
import 'package:flutter/material.dart';
import 'package:rxdart/rxdart.dart';
import 'package:shared_preferences/shared_preferences.dart';

class AccountsPenetrationViewModel {
  late final _apiRepository = APiRepository();

  final List<int> pageSizeArr = [
    1,
    2,
    3,
    4,
    5,
    6,
    7,
    8,
    9,
    10,
  ];

  List<ExistingAccountStatus> statusFilterList = <ExistingAccountStatus>[
    ExistingAccountStatus('All', 'all'.tr()),
    ExistingAccountStatus('1', 'toBeVisited'.tr()),
    ExistingAccountStatus('2', 'rejectToEnrol'.tr()),
    ExistingAccountStatus('3', 'agreeToEnrol'.tr()),
    ExistingAccountStatus('4', 'salesFollowedRejected'.tr()),
    ExistingAccountStatus('5', 'salesDiscount'.tr()),
    //const ExistingAccountStatus('6', Constant.moveToOpenAC),
  ];

  int selectedPageSize = 10;
  int pageNumber = 1;
  int fromPageSize = 1;
  int toPageSize = 10;
  int totalRecords = 0;
  String dateFilter = '';
  String sortFilter = 'All';
  String statusFilter = 'All';
  String sortByAscDesc = 'DESC';
  String? routeNumber;

  String? checkViewStatus(String? str) {
    if (str == '1') {
      return 'toBeVisited'.tr();
    } else if (str == '2') {
      return 'rejectToEnrol'.tr();
    } else if (str == '3') {
      return 'agreeToEnrol'.tr();
    } else if (str == '4') {
      return 'salesFollowedRejected'.tr();
    } else if (str == '5') {
      return 'salesDiscount'.tr();
    }
    return '';
  }

  String? checkStatus(String? str) {
    if (str == '1') {
      return 'rejectToEnrol'.tr();
    } else if (str == '2') {
      return 'agreeToEnrol'.tr();
    }
    return '';
  }

  final timeFrameData = PublishSubject<AccountTimeFrame>();
  Stream<AccountTimeFrame> get accountTimeFrame => timeFrameData.stream;

  final accountPenetrationData = PublishSubject<AccountPenetration>();
  Stream<AccountPenetration> get accountPenetrationList =>
      accountPenetrationData.stream;

  Future<void> fetchAccountTimeFrameData() async {
    final body = {
      "routeNumber": "${await getRouteNumber()}",
      "userIds": ["${await getEmpNumber()}"],
      "userRole": "courier"
    };
    debugPrint('BODY: $body');
    debugPrint('body_TimeFrame: $body');

    final prefs = await SharedPreferences.getInstance();
    String? token = prefs.getString('accessToken');
    dynamic response = await _apiRepository.fetchTimeFrameDetail(
        BaseService.existingAccountTimeFrame, body, token!);
    //
    AccountTimeFrame apData = AccountTimeFrame.fromJson(response);
    if (apData.serviceStatus!.statusCode == 200) {
      //debugPrint('response:: ${apData.serviceStatus?.message}');
      timeFrameData.sink.add(apData);
    } else {
      debugPrint("error_mesage: ${apData.serviceStatus?.message}"); //
    }
  }

  int getTimeDifference(endDateStr) {
    debugPrint('getTimeDifference endDateStr: $endDateStr');
    int sec;
    if (endDateStr != null) {
      DateTime? currentDate = DateTime.now();
      DateTime? endDate = DateTime.tryParse(endDateStr);
      sec = endDate != null ? endDate.difference(currentDate).inSeconds : 0;
      debugPrint('getTimeDifference: $sec');
      if (sec < 0) sec = 0;
    } else {
      sec = 0;
    }

    return sec;
  }

  Future<void> fetcAccountPenetrationData(String url, int pageNumber,
      int pageSize, status, dateStr, sortyBy, sortorder) async {
    // "sortorder": "DESC",

    debugPrint('body: First');

    final body = {
      "filters": {
        "date": dateStr,
        "admin": false,
        "countryCode": "${await getCountryCode()}",
        "invalidAccounts": "false",
        "market": "",
        "month": "",
        "operation": "AccInProgress",
        "routeNumber": "${await getRouteNumber()}",
        "deptNumber": [""],
        "sortBy": sortyBy,
        "sortorder": sortorder,
        "status": status,
        "support": false,
        "userIds": ["${await getEmpNumber()}"],
        "userRole": {"1": "COURIER"}
      },
      "pageNumber": pageNumber,
      "pageSize": pageSize
    };

    debugPrint('Accounts_body: $body');

    final prefs = await SharedPreferences.getInstance();
    String? token = prefs.getString('accessToken');
    dynamic response =
        await _apiRepository.fetchAccountPenetrationDetail(url, body, token!);
    //
    AccountPenetration apData = AccountPenetration.fromJson(response);
    if (apData.serviceStatus!.statusCode == 200) {
      accountPenetrationData.sink.add(apData);

      //debugPrint('response : ${response?.serviceStatus?.statusCode}');

    } else {
      accountPenetrationData.sink.add(apData);
      debugPrint("error_mesage: ${apData.serviceStatus?.message}");
    }
  }

  getCountryCode() async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.getString('countryCode') ?? " ";
  }

  getRouteNumber() async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.getString('routeNumber') ?? " ";
  }

  getEmpNumber() async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.getString('employeeNumber')!;
  }

  paginationCalulation(ViewAccountPagination leadPagination) {
    totalRecords = leadPagination.totalRecords!;
    pageNumber = leadPagination.pageNumber!;
    selectedPageSize = leadPagination.pageSize!;

    fromPageSize = (pageNumber - 1) * selectedPageSize + 1;
    toPageSize = pageNumber * selectedPageSize;
    toPageSize = toPageSize > totalRecords ? totalRecords : toPageSize;
  }

  onSelectPageSize(pageSize) {
    selectedPageSize = pageSize;
    pageNumber = 1;
    read();
  }

  onSelectNextPage() {
    pageNumber = pageNumber + 1;
    read();
  }

  onSelectPreviousPage() {
    pageNumber = pageNumber - 1;
    read();
  }

  onSelectFirstPage() {
    pageNumber = 1;
    read();
  }

  onSelectLastPage() {
    pageNumber = getLastPageNumber();
    read();
  }

  onFilterSubmit(sortBy, status, date, ascDesc) {
    sortFilter = sortBy;
    statusFilter = status;
    dateFilter = date;
    sortByAscDesc = ascDesc;
    debugPrint(
        'onFilterSubmit : $sortFilter+' '+$statusFilter+' '+$dateFilter');
    read();
  }

  onSortByAll(sortBy, ascDesc) {
    sortFilter = sortBy;
    sortByAscDesc = ascDesc;
    read();
  }

  onSortByStatus(sortBy, ascDesc) {
    sortFilter = sortBy;
    sortByAscDesc = ascDesc;
    read();
  }

  onSortByDate(sortBy, ascDesc) {
    sortFilter = sortBy;
    sortByAscDesc = ascDesc;
    read();
  }

  int getLastPageNumber() {
    int quitant = totalRecords ~/ selectedPageSize;
    return (totalRecords % selectedPageSize) == 0 ? quitant : quitant + 1;
  }

  read() {
    //https://clap-leads-dev.app.singdev1.paas.fedex.com/lead/lead-list

    fetcAccountPenetrationData(
        BaseService.existingAccountPenetrationList,
        pageNumber,
        selectedPageSize,
        statusFilter,
        dateFilter,
        sortFilter,
        sortByAscDesc);

    debugPrint('pageNumber : $pageNumber');
    debugPrint('pageSize :$selectedPageSize');
    debugPrint('date : $dateFilter');
    debugPrint('sortBy : $sortFilter');
    debugPrint('status : $statusFilter');
    debugPrint('sortorder : $sortByAscDesc');
  }

  Future getDateTimeFromPicker(context) async {
    DateTime? newDateTime = await showDatePicker(
      context: context,
      initialDate: DateTime.now(),
      firstDate: DateTime(DateTime.now().year - 3),
      lastDate: DateTime(DateTime.now().year + 3),
      //borderRadius: 16,
    );

    final dateString = DateFormat('MM/dd/yy').format(newDateTime!);
    debugPrint('Date_selected : $dateString');
// var dateString = format.format(DateTime.now());
    return dateString;
  }

  dispose() {
    accountPenetrationData.close();
  }

  //   '',
}

class ExistingAccountStatus {
  const ExistingAccountStatus(this.id, this.name);

  final String name;
  final String id;
}
