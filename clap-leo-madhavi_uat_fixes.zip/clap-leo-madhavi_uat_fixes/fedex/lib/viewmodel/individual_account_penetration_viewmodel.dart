// ignore: file_names
import 'package:easy_localization/easy_localization.dart';
import 'package:fedex_app/model/account_existing_update.dart';
import 'package:fedex_app/model/api_repository.dart';
import 'package:fedex_app/model/individual_account_model.dart';
import 'package:fedex_app/utility/apis/api_response.dart';
import 'package:fedex_app/utility/services/base_service.dart';
import 'package:flutter/cupertino.dart';
import 'package:rxdart/rxdart.dart';
import 'package:shared_preferences/shared_preferences.dart';

class IndividualAccountPenetrationViewmodel with ChangeNotifier {
  List<AccountPenetrationStatus> statusUpdateList = [
    AccountPenetrationStatus('0', 'select'.tr()),
    AccountPenetrationStatus('1', 'rejectToEnrol'.tr()),
    AccountPenetrationStatus('2', 'agreeToEnrol'.tr()),
  ];

  List<AccountPenetrationStatus> accountUpdateReasonList = [
    AccountPenetrationStatus('0', 'select'.tr()),
    AccountPenetrationStatus('1', 'unreachable'.tr()),
    AccountPenetrationStatus('2', 'notInterested'.tr()),
    AccountPenetrationStatus('3', 'notApplicable'.tr()),
    AccountPenetrationStatus('4', 'businessMoved'.tr()),
    AccountPenetrationStatus('5', 'noPackage'.tr()),
    AccountPenetrationStatus('6', 'other_provide'.tr()),
  ];

  final _apiRepository = APiRepository();

  ApiResponse _apiResponse = ApiResponse.initial('no data');

  final _accountDetailFetcher = PublishSubject<IndividualAccountModel>();
  Stream<IndividualAccountModel> get accountDetail =>
      _accountDetailFetcher.stream;
  //
  ApiResponse get response {
    return _apiResponse;
  }

//Get from Lead individual details
  Future<void> fetchExistingAccountLeadDetailsData(leadOid,
      {required Function successCallback,
      required Function failureCallback}) async {
    try {
      final prefs = await SharedPreferences.getInstance();
      String? token = prefs.getString("accessToken");

      IndividualAccountModel individualAccount =
          await _apiRepository.fetchAccountDetails(
              token!, BaseService.existingleadIndividual(leadOid),
              baseURL: BaseService.baseAccountUrl);
      //
      if (individualAccount.serviceStatus?.statusCode == 200) {
        //Check services status code 200
        debugPrint(
            'Accounts api Status Code: ${individualAccount.serviceStatus?.statusCode}');
        _accountDetailFetcher.sink.add(individualAccount);
        _apiResponse = ApiResponse.completed(individualAccount);

        // notifyListeners();
        //debugPrint('IndividualLead response: $_apiResponse');

        return successCallback(_apiResponse);
        //
      } else {
        _apiResponse = ApiResponse.completed(individualAccount);
        notifyListeners();
        debugPrint('Accounts details api error response: $_apiResponse');

        return failureCallback(_apiResponse);
      }
    } catch (e) {
      _apiResponse = ApiResponse.error(e.toString());
      debugPrint('Accounts api error: $e');
      return failureCallback(_apiResponse);
    }
  }

  Future<void> updateExistingAccountLeadDetailsData(accountOID, status,
      {required Function successCallback,
      required Function failureCallback}) async {
    debugPrint('accountOID: $_apiResponse');
    try {
      final prefs = await SharedPreferences.getInstance();
      String? token = prefs.getString("accessToken");

      AccountExistingUpdate accountExistingUpdate =
          await _apiRepository.updateExistingAccountPenetration(token!,
              BaseService.existingleadIndividualUpdated(accountOID, status),
              baseURL: BaseService.baseAccountUrl);
      //
      if (accountExistingUpdate.serviceStatus?.statusCode == 200) {
        //Check services status code 200
        //_accountDetailFetcher.sink.add(individualAccount);
        _apiResponse = ApiResponse.completed(accountExistingUpdate);
        notifyListeners();
        //debugPrint('accountExistingUpdate response: $_apiResponse');
        return successCallback(_apiResponse);
        //
      } else {
        //notifyListeners();
        debugPrint('account updated api error response: $_apiResponse');
        return failureCallback(_apiResponse);
      }
    } catch (e) {
      _apiResponse = ApiResponse.error(e.toString());
      debugPrint('account updated api error: $e');
      return failureCallback(_apiResponse);
    }
  }

  Future<void> updateStatusComments(
      AccountDetails? accountDetails, comments, status, endreason,
      {required Function successCallback,
      required Function failureCallback}) async {
    final body = {
      "accountOIDs": [accountDetails!.accountOID],
      "comment": comments,
      "endReason": endreason,
      "status": status
    };

    debugPrint('JSON_BODY: $body');
    notifyListeners();
    try {
      _apiResponse = ApiResponse.loading('updating status - comments');

      final prefs = await SharedPreferences.getInstance();
      String? token = prefs.getString('accessToken');

      AccountExistingUpdate addComments = await APiRepository()
          .fetchExistingAccountStatusUpdate(
              BaseService.existingleadStatusCommentsUpdate, body, token!);

      if (addComments.serviceStatus?.status == true) {
        _apiResponse = ApiResponse.completed(addComments);
        notifyListeners();
        return successCallback(_apiResponse);
      } else {
        _apiResponse = ApiResponse.error(addComments);
        notifyListeners();
        return failureCallback(_apiResponse);
      }
    } catch (e) {
      _apiResponse = ApiResponse.error(e.toString());
      debugPrint('add comments error: $e');
      return failureCallback(_apiResponse);
    }
  }
}

class AccountPenetrationStatus {
  const AccountPenetrationStatus(this.id, this.name);

  final String name;
  final String id;
}
