import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

const kPrimaryColor = Color(0xFF4D148C);
const kBackgroundColor = Color(0xFFFFFFFF);
const kErrorColor = Color(0xFFFF0000);
const xColor = Color(0xFFFF6200);
const xNotificationColor = Color(0xFFF36717);
const xColorGrey = Color(0xFF707070);
const xColorlightGrey = Color(0xFFF2F2F2);
const xColorlightGreyX = Color(0xFFEEEEEE);
const xColorThinlightGrey = Color(0xFFCCCCCC);
const xColorNormalGrey = Color(0xFFd4d4d4);
const xColorBlack = Color(0xFF000000);
const xColorWhite = Color(0xFFFFFFFF);
const xColorlightblue = Color(0xFF4D148C);
const xColorDarkGrey = Color(0xFF333333);
const xColorLightBlues = Color(0xFF007ab7);

ThemeData buildAppTheme() {
  final ThemeData base = ThemeData.light();
  return base.copyWith(
    primaryColor: kPrimaryColor,
    // for iOS  cursor
    cupertinoOverrideTheme: const CupertinoThemeData(
      primaryColor: kPrimaryColor,
    ),
    // for others Android cursor
    textSelectionTheme:
        const TextSelectionThemeData(cursorColor: kPrimaryColor),
    textTheme: buildAppTextTheme(base.textTheme),
    primaryTextTheme: buildAppTextTheme(base.primaryTextTheme),
    buttonTheme: base.buttonTheme.copyWith(
      buttonColor: kPrimaryColor,
      textTheme: ButtonTextTheme.normal,
    ),
    iconTheme: buildAppIconTheme(base.iconTheme),
    primaryIconTheme: base.iconTheme.copyWith(color: kPrimaryColor),
    scaffoldBackgroundColor: kBackgroundColor,
    cardColor: Colors.white,
    errorColor: xColor,
    backgroundColor: Colors.white,
    brightness: Brightness.light,
  );
}

TextTheme buildAppTextTheme(TextTheme base) {
  return base.apply(
    fontFamily: 'Roboto',
  );
}

IconThemeData buildAppIconTheme(IconThemeData base) {
  return base.copyWith(color: Colors.black);
}

Widget linerGradientColor(BuildContext context){
  return Container(
        height: MediaQuery.of(context).size.height,
        width: MediaQuery.of(context).size.width,
        decoration:const BoxDecoration(
          gradient:LinearGradient(colors: [Color(0xFF4D148C), Color(0xFFF36717)]),
        )
      );
}
