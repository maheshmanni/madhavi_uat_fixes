import 'dart:convert';
import 'dart:io';
import 'package:fedex_app/utility/apis/app_exception.dart';
import 'package:fedex_app/utility/services/base_service.dart';
import 'package:flutter/material.dart';
import 'package:meta/meta.dart';

import 'package:http/http.dart' as http;

class ApiService extends BaseService {
  @override
  Future putResponse(String url, headers, requestBody) async {
    dynamic responseJson;
    try {
      final response = await http.put(Uri.parse(BaseService.baseUrl + url),
          headers: headers, body: requestBody);
      responseJson = returnResponse(response);
      // debugPrint('responseJson: ${jsonEncode(responseJson)}');
    } on SocketException {
      throw FetchDataException('No Internet Connection');
    }
    return responseJson;
  }

  @override
  Future deleteResponse(String url, headers, requestBody) async {
    dynamic responseJson;
    try {
      final response = await http.delete(Uri.parse(BaseService.baseUrl + url),
          headers: headers, body: requestBody);
      responseJson = returnResponse(response);
    } on SocketException {
      throw FetchDataException('No Internet Connection');
    }
    return responseJson;
  }

  @override
  Future getResponse(String url, headers, {String baseURL = ""}) async {
    dynamic responseJson;
    try {
      //debugPrint('url: ${BaseService.baseUrl + url}, baseURL: $baseURL');
      dynamic response;
      if (baseURL != "") {
        response = await http.get(Uri.parse(baseURL + url), headers: headers);
      } else {
        response = await http.get(Uri.parse(BaseService.baseUrl + url),
            headers: headers);
      }
      // final response = await http.get(Uri.parse(BaseService.baseUrl + url));
      responseJson = returnResponse(response);
    } on SocketException {
      throw FetchDataException('No Internet Connection');
    }
    return responseJson;
  }

  @override
  Future postResponse(String url, headers, requestBody,
      {String baseURL = ""}) async {
    dynamic responseJson;
    try {
      // debugPrint(
      //     'baseUrl: ${BaseService.baseUrl + url}\n account_baseurl $baseURL');
      dynamic response;
      if (baseURL != "") {
        if (requestBody == null) {
          response =
              await http.post(Uri.parse(baseURL + url), headers: headers);
        } else {
          response = await http.post(Uri.parse(baseURL + url),
              headers: headers, body: requestBody);
        }
      } else {
        response = await http.post(Uri.parse(BaseService.baseUrl + url),
            headers: headers, body: requestBody);
      }

      responseJson = returnResponse(response);
    } on SocketException {
      throw FetchDataException('No Internet Connection');
    }
    return responseJson;
  }

  @visibleForTesting
  dynamic returnResponse(http.Response response) {
    switch (response.statusCode) {
      case 200:
      case 201:
        dynamic responseJson = jsonDecode(response.body);
        return responseJson;
      case 400:
        throw BadRequestException(response.body.toString());
      case 401:
      case 403:
        throw UnauthorisedException(response.body.toString());
      case 500:
      default:
        dynamic responseJson = jsonDecode(response.body);
        return responseJson;
    }
  }
}
