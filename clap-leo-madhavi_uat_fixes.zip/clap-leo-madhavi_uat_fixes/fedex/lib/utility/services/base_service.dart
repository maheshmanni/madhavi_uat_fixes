abstract class BaseService {
  //
  static String baseUrl =
      "https://alps-gateway-dev.app.singdev1.paas.fedex.com/";
  static String baseAccountUrl =
      "https://alps-gateway-dev.app.singdev1.paas.fedex.com/";
  //
  static const String lead = "lead";
  //https://clap-leads-dev.app.singdev1.paas.fedex.com/lead/uploadDocument
  static const String leadUploadDocument = "lead/uploadDocument";

  //https://alps-lead-dev.app.singdev1.paas.fedex.com/lead/downloadDocument?docKey=c80f8936-5dbf-46ee-8506-c9320d6d2a81ac_opening_02.jpg
  static const String documenturl = "lead/downloadDocument?docKey=";

  static String leadDownloadDocument(dockey) {
    return documenturl + dockey;
  }
  //https://alps-lead-dev.app.singdev1.paas.fedex.com/lead/deleteDocument

  static const String deleteDocument = "lead/deleteDocument";

  //https://clap-leads-dev.app.singdev1.paas.fedex.com/lead/leadNotes
  static const String leadNotes = "lead/leadNotes";

  //'lead/lead-list'
  static const String leadSubmitedList = "lead/lead-list";

  // https://alps-account-dev.app.singdev1.paas.fedex.com/account-list
  static const String existingAccountTimeFrame = "account/account-timeframe";
  static const String existingAccountPenetrationList = "account/accounts-list";
  static String existingleadIndividual(accountOID) {
    return 'account/$accountOID';
  }

  //https://alps-account-dev.app.singdev1.paas.fedex.com/account/update/140/2
  static String existingleadIndividualUpdated(accountOID, status) {
    return 'account/update/$accountOID/$status';
  }

  static String existingleadStatusCommentsUpdate = "account/update-status";

  //https://alps-lead-dev.app.singdev1.paas.fedex.com/reports//
  static String kpiReportsNewLead = "lead/reports";
  static String kpiReportsNewLeadMonths = "lead/months";
  static String kpiReportsAccounts = "account/reports";
  static String kpiReportsAccountsMonths = "account/months";

  //https://clap-leads-dev.app.singdev1.paas.fedex.com/lead/100
  static String leadIndividual(String requestPath) {
    return 'lead/$requestPath';
  }
  //https://alps-lead-dev.app.singdev1.paas.fedex.com/lead/notification/1234

  static String notification(String requestPath) {
    return 'lead/notification/$requestPath';
  }

  //https://alps-lead-dev.app.singdev1.paas.fedex.com/lead/read/notification
  static String readNotification() {
    return 'lead/read/notification/';
  }

  Future<dynamic> putResponse(String url, headers, requestBody);
  Future<dynamic> getResponse(String url, headers, {String baseURL = ""});
  Future postResponse(String url, headers, requestBody, {String baseURL = ""});
  Future<dynamic> deleteResponse(String url, headers, requestBody);
}
