// ignore_for_file: constant_identifier_names

import 'package:flutter/material.dart';

import 'theme_colors.dart';

abstract class Styles {
  static var splashStyle = const TextStyle(
    fontSize: FontSizes.FONT_28,
    color: xColorBlack,
  );

  static var titleGreyTextWithF12 = const TextStyle(
      color: xColorGrey,
      fontWeight: FontWeight.w400,
      fontSize: FontSizes.FONT_6);
  static var titleGreyTextWithF08 = const TextStyle(
      color: xColorGrey,
      fontWeight: FontWeight.w400,
      fontSize: FontSizes.FONT_10);

  static var titleGreyTextWithF8 = const TextStyle(
      color: xColorGrey,
      fontWeight: FontWeight.w400,
      fontSize: FontSizes.FONT_6);

  static var titleGreyTextWithF13 = const TextStyle(
      color: xColorGrey,
      fontWeight: FontWeight.w400,
      fontSize: FontSizes.FONT_10);

  static var titleTextWithF26 = const TextStyle(
      color: xColorGrey,
      fontWeight: FontWeight.w700,
      fontSize: FontSizes.FONT_14);

  static var titleGreyTextWithF12W700 = const TextStyle(
      color: xColorGrey,
      fontWeight: FontWeight.w700,
      fontSize: FontSizes.FONT_9);

  static var titleTextWithF11W700 = const TextStyle(
      color: xColorGrey,
      fontWeight: FontWeight.w700,
      fontSize: FontSizes.FONT_11);
  static var titleTextWithF12W700 = const TextStyle(
      color: xColorGrey,
      fontWeight: FontWeight.w700,
      fontSize: FontSizes.FONT_10);

  static var tabBarTextWithF12W700 = const TextStyle(
      color: xColor, fontWeight: FontWeight.w700, fontSize: FontSizes.FONT_10);

  static var errorTextFormFieldF12W500 = const TextStyle(
      color: kErrorColor,
      fontWeight: FontWeight.w500,
      fontSize: FontSizes.FONT_12);

  static var titleTextWithF20W700 = const TextStyle(
      color: xColorGrey,
      fontWeight: FontWeight.w700,
      fontSize: FontSizes.FONT_15);

  static var titleTextWithF15W400 = const TextStyle(
      color: xColorGrey,
      fontWeight: FontWeight.w500,
      fontSize: FontSizes.FONT_12);

  static var contentTextWithF30W300 = const TextStyle(
      color: xColorBlack,
      fontWeight: FontWeight.w300,
      fontSize: FontSizes.FONT_15);

  static var contentStatusW300 = const TextStyle(
      color: xColorBlack,
      fontWeight: FontWeight.w300,
      fontSize: FontSizes.FONT_20);

  static var contentTearmsConditionsW300 = const TextStyle(
      color: xColorBlack,
      fontWeight: FontWeight.w300,
      fontSize: FontSizes.FONT_10);

  static var titleTextWithF18W700 = const TextStyle(
      color: xColorGrey,
      fontWeight: FontWeight.w700,
      fontSize: FontSizes.FONT_12);

  static var titleWhiteWithF16 = const TextStyle(
      color: Colors.white,
      fontWeight: FontWeight.w400,
      fontSize: FontSizes.FONT_16);

  static var titleWhiteTextWithF10 = const TextStyle(
      color: Colors.white,
      fontWeight: FontWeight.w400,
      fontSize: FontSizes.FONT_10);
  static var titleWhiteTextWithF12W700 = const TextStyle(
      color: Colors.white,
      fontWeight: FontWeight.w700,
      fontSize: FontSizes.FONT_12);

  static var radioButtonTitle = const TextStyle(
      color: Colors.white,
      fontWeight: FontWeight.w400,
      fontSize: FontSizes.FONT_12);

  static var titleWhiteTextWithF18W700 = const TextStyle(
      color: Colors.white,
      fontWeight: FontWeight.w700,
      fontSize: FontSizes.FONT_18);
  static var titleWhiteTextWithF20W700 = const TextStyle(
      color: Colors.white,
      fontWeight: FontWeight.w700,
      fontSize: FontSizes.FONT_15);
  static var titleWhiteTextWithF26W700 = const TextStyle(
      color: Colors.white,
      fontWeight: FontWeight.w700,
      fontSize: FontSizes.FONT_26);

  static var titleBlackTextWithF13W700 = const TextStyle(
      color: xColorBlack,
      fontWeight: FontWeight.w700,
      fontSize: FontSizes.FONT_10);
  static var titleTextWithF24W700 = const TextStyle(
      color: xColorBlack,
      fontWeight: FontWeight.w700,
      fontSize: FontSizes.FONT_20);

  static var titleTextWithF14W700 = const TextStyle(
      color: xColorGrey,
      fontWeight: FontWeight.w700,
      fontSize: FontSizes.FONT_10);
  static var titleTextWithF10W400 = const TextStyle(
      color: xColorGrey,
      fontWeight: FontWeight.w700,
      fontSize: FontSizes.FONT_10);

  static var titleTextPrimaryF12W700 = const TextStyle(
    color: kPrimaryColor,
    fontWeight: FontWeight.w700,
    fontSize: FontSizes.FONT_6,
    //decoration: TextDecoration.underline
  );

  static var titleHelloF12W700 = const TextStyle(
    color: kPrimaryColor,
    fontWeight: FontWeight.w700,
    fontSize: FontSizes.FONT_20,
    //decoration: TextDecoration.underline
  );

  static var landingButtonF20W400 = const TextStyle(
    color: kBackgroundColor,
    fontWeight: FontWeight.w400,
    fontSize: FontSizes.FONT_12,
    //decoration: TextDecoration.underline
  );
  static var whiteTextButtonF16W400 = const TextStyle(
    color: xColor,
    fontWeight: FontWeight.w400,
    fontSize: FontSizes.FONT_12,
    //decoration: TextDecoration.underline
  );

  static var skipButtonF14W400 = const TextStyle(
      color: kBackgroundColor,
      fontWeight: FontWeight.w400,
      fontSize: FontSizes.FONT_14,
      decoration: TextDecoration.underline);

  static var titleTextWithF30W700 = const TextStyle(
      color: xColor,
      backgroundColor: Colors.white,
      fontWeight: FontWeight.w700,
      fontSize: FontSizes.FONT_26);

  static var timeLeftTextWithF20W700 = const TextStyle(
      color: xColor, fontWeight: FontWeight.w700, fontSize: FontSizes.FONT_15);
  static var kpiusDollarTestF10W700 = const TextStyle(
      color: xColor, fontWeight: FontWeight.w700, fontSize: FontSizes.FONT_12);
  static var textWithblackF15W700 = const TextStyle(
      color: xColorBlack,
      fontWeight: FontWeight.w700,
      fontSize: FontSizes.FONT_15);

  static var timeWithF10W400 = const TextStyle(
      color: xColorGrey,
      fontWeight: FontWeight.w400,
      fontSize: FontSizes.FONT_10);

  // static var titleTextWithF15W400 = const TextStyle(
  //     color: xColorGrey,
  //     fontWeight: FontWeight.w700,
  //     fontSize: FontSizes.FONT_13);

  // static var contentTextWithF30W300 = const TextStyle(
  //     color: xColorBlack,
  //     fontWeight: FontWeight.w300,
  //     fontSize: FontSizes.FONT_30);

  static var editTextBlueWithF14W700 = const TextStyle(
      color: xColorlightblue,
      fontWeight: FontWeight.w700,
      fontSize: FontSizes.FONT_12,
      decoration: TextDecoration.underline);

  static var edittextBlueWithF14W700 = const TextStyle(
      color: xColorLightBlues,
      fontWeight: FontWeight.w700,
      fontSize: FontSizes.FONT_12,
      decoration: TextDecoration.underline);

  static var commentTitletBlueWithF14W700 = const TextStyle(
      color: xColorLightBlues,
      fontWeight: FontWeight.w700,
      fontSize: FontSizes.FONT_10,
      decoration: TextDecoration.underline);

  static var editTextWithF20W700 = const TextStyle(
      color: xColorlightblue,
      fontWeight: FontWeight.w700,
      fontSize: FontSizes.FONT_12);
  static var editTextWithF14W700 = const TextStyle(
      color: xColorlightblue,
      fontWeight: FontWeight.w700,
      fontSize: FontSizes.FONT_14);
  static var buttonSubF20W700 = const TextStyle(
      color: kBackgroundColor,
      fontWeight: FontWeight.w400,
      fontSize: FontSizes.FONT_15);
  static var buttonCanF20W700 = const TextStyle(
      color: xColor, fontWeight: FontWeight.w400, fontSize: FontSizes.FONT_15);

  static var texUnderLinetWithF10W400 = const TextStyle(
      color: xColorlightblue,
      decoration: TextDecoration.underline,
      decorationColor: xColorlightblue,
      fontWeight: FontWeight.w700,
      fontSize: FontSizes.FONT_10);

  // static var blackText97WithF12 = TextStyle(
  //     color: black97, fontWeight: FontWeight.w400, fontSize: FontSizes.FONT_12);
  // static var blackText97WithF14 = TextStyle(
  //     color: black97, fontWeight: FontWeight.w400, fontSize: FontSizes.FONT_14);
  // static var blackText97WithF14W600 = TextStyle(
  //     color: black97, fontWeight: FontWeight.w600, fontSize: FontSizes.FONT_14);
  // static var blackText97WithF16 = TextStyle(
  //     color: black97, fontWeight: FontWeight.w400, fontSize: FontSizes.FONT_16);
  // static var blackText97WithF16W5 = TextStyle(
  //     color: black97, fontWeight: FontWeight.w500, fontSize: FontSizes.FONT_16);
  // static var blackText97WithF16W6LineThrough = TextStyle(
  //   color: black97,
  //   fontWeight: FontWeight.w600,
  //   fontSize: FontSizes.FONT_16,
  //   decoration: TextDecoration.lineThrough,
  // );
  // static var blackText97WithF18W5 = TextStyle(
  //     color: black97, fontWeight: FontWeight.w500, fontSize: FontSizes.FONT_18);
}

class FontSizes {
  static const double DEFAULT_FONT_SIZE = 16.0;
  static const double FONT_SIZE_HALF = DEFAULT_FONT_SIZE / 2;
  static const double FONT_SIZE_QUARTER = DEFAULT_FONT_SIZE / 4;
  static const double FONT_SIZE_DOUBLE = DEFAULT_FONT_SIZE * 2;
  static const double FONT_4 = 4.0;
  static const double FONT_6 = 6.0;
  static const double FONT_8 = 8.0;
  static const double FONT_9 = 9.0;
  static const double FONT_10 = 10.0;
  static const double FONT_11 = 11.0;
  static const double FONT_12 = 12.0;
  static const double FONT_13 = 13.0;
  static const double FONT_14 = 14.0;
  static const double FONT_15 = 15.0;
  static const double FONT_16 = 16.0;
  static const double FONT_18 = 18.0;
  static const double FONT_19 = 19.0;
  static const double FONT_20 = 20.0;
  static const double FONT_22 = 22.0;
  static const double FONT_24 = 24.0;
  static const double FONT_26 = 26.0;
  static const double FONT_28 = 28.0;
  static const double FONT_30 = 30.0;
  static const double FONT_32 = 32.0;
  static const double FONT_34 = 34.0;
  static const double FONT_36 = 36.0;
  static const double FONT_38 = 38.0;
  static const double FONT_40 = 40.0;
}
