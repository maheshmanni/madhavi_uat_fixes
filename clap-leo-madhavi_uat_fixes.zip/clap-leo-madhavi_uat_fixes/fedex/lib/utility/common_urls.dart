import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/cupertino.dart';

class CommonUrls {
  static const stationId = 'STATION ID';
}

String getCurrentDateTimeFormat(String dateFormat) {
  final dateTime = DateTime.now();
  //const dateFormat = "yyyy-MM-dd'T'HH:mm:ss.SSS";
  String currentDateStr = DateFormat(dateFormat).format(dateTime);
  debugPrint('currentDateStr: $currentDateStr');
  return currentDateStr;
}
