import 'package:flutter/material.dart';

class CommonProvider with ChangeNotifier {
  int totalNotificationCount = 1;

  set setTotalNotificationCount(int value) {
    totalNotificationCount = value;
    notifyListeners();
  }
}
