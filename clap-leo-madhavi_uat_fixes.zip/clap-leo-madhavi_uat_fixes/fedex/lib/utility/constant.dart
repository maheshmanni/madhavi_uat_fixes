class Constant {
  //assets
  static const landingBgIcon = 'assets/icons/login_bg.png';
  static const userProfileIcon = 'assets/icons/user_profile.svg';
  static const logoIcon = 'assets/icons/logo.png';
  //new_lead_icon
  static const iconOne = 'assets/icons/new_lead_icon.svg';
  static const tms =
      "In relation to any data provided by you, you represent that you have complied with all applicable laws, including obtaining necessary consent or other legal basis for the provision of such data to FedEx, and providing the relevant individuals with all necessary information in connection with the collection, transfer and processing of such information.";
  static const newLeadIC = 'assets/icons/new_lead_ic.svg';
  static const leadListIC = 'assets/icons/lead_list_ic.svg';
  static const newLeadOrngIC = 'assets/icons/new_lead_orng_ic.svg';
  static const existAcOrngIC = 'assets/icons/exist_ac_orng_ic.svg';

  static const iconTwo = 'assets/icons/icon_two.svg';
  static const iconThree = 'assets/icons/icon_three.svg';
  static const iconFour = 'assets/icons/icon_four.svg';
  static const iconFive = 'assets/icons/icon_five.svg';
  static const iconSix = 'assets/icons/icon_six.svg';
  static const newLeadIcon = 'assets/icons/new_lead_icon.svg';
  static const courierbg = 'assets/icons/courier_bg.png';
  static const landingFadeIcon = 'assets/icons/landing_fade.png';
  static const assetsEditIcon = 'assets/icons/edit_icon.png';
  static const logo114 = 'assets/icons/logo_white_114.png';
  static const notification = 'assets/icons/notification.png';
  static const downArrowOrange = 'assets/icons/down_arrow_orange.png';
  static const String assetsBackArrow = 'assets/icons/arrowback_icon.svg';
  static const changeIcon = 'assets/icons/change_icon.png';
  static const dropDownGreyIcon = 'assets/icons/grey_dropdown.png';
  static const calenderIcon = 'assets/icons/calender.png';
  static const leftArrowIcon = 'assets/icons/left_arrow.png';
  static const rightArrowIcon = 'assets/icons/right_arrow.png';
  static const firstArrowIcon = 'assets/icons/first_arrow.svg';
  static const lastArrowIcon = 'assets/icons/last_arrow.svg';
  static const salesLeadGenerated = 'assets/icons/sales_lead.svg';
  static const shipmentCount = 'assets/icons/shipment_count.svg';
  static const revenueGenerated = 'assets/icons/revenue_generated.svg';
  static const accountOpen = 'assets/icons/account_open.svg';
  static const packageCount = 'assets/icons/package_count.svg';
  static const completionRate = 'assets/icons/completion_rate.svg';
  static const accountsLeft = 'assets/icons/accounts_left.svg';
  static const timeLeft = 'assets/icons/time_left.svg';
  static const accountsVisited = 'assets/icons/accounts_visited.svg';

  static const String regex = r"^\S.*$";
// restrict special characters
  static const String patternChar = r"[a-zA-Z -^\S.*$ ]";
  static const String patternNameChar = r"[A-Z - ]";
  static const String patternStnId =
      "[abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789]";
  static const String patternRouteNum = r"[0-9STA]";
  static const String pattternPhone = r"[+0-9-() ]";
  static const String pattternPostal =
      "[abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789.-]";
  static const String pattternEmail =
      "[-abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789@#_., ]";
  static const String patternEmailAddress =
      r'^(([^<>()[\]\\.,;:\s@\"]+(\.[^<>()[\]\\.,;:\s@\"]+)*)|(\".+\"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$';

  // New Lead screen constant variables.
  static const String newLead = 'New Lead';
  static const String myPerformance = 'My Performance';
  static const String existingAccountsPenetration =
      'Existing Accounts Penetration';
  static const String stationId = 'Station ID: ';
  static const String routeNumber = 'Route No.: ';
  static const String stationIdTitle = 'STATION ID';
  static const String routeNumberTitle = 'ROUTE NUMBER';
  static const String edit = 'EDIT';
  static const String accountNumber = 'ACCOUNT NUMBER';
  static const String companyName = 'COMPANY NAME ';
  static const String pleaseProvideComanyName = 'Please Provide Company Name';
  static const String customerTitle = 'CUSTOMER TITLE';
  static const String customerFirstName = 'CUSTOMER FIRST NAME ';
  static const String pleaseProvideCustomerFirstName =
      'Please Provide Customer First Name';
  static const String customerLastName = 'CUSTOMER LAST NAME ';
  static const String pleaseProvideCustomerLastName =
      'Please Provide Customer Last Name';
  static const String telephoneNumber = 'TELEPHONE NUMBER ';
  static const String pleaseProvideTeleNumber =
      'Please Provide Telephone Number';
  static const String mobileNumber = 'MOBILE NUMBER';
  static const String pleaseProvideMobileNumber =
      'Please Provide Mobile Number';
  static const String addressOne = 'ADDRESS ONE ';
  static const String pleaseProvideAddress = 'Please Provide Address Line';
  static const String addressTwo = 'ADDRESS TWO';
  static const String city = 'CITY ';
  static const String pleaseProvideCity = 'Please Provide City';
  static const String postal = 'POSTAL ';
  static const String postalOptional = 'POSTAL ';
  static const String pleaseProvidePostal = 'Please Provide Postal Code';
  static const String email = 'EMAIL ';
  static const String pleaseProvideEmail = 'Please Provide Email';
  static const String remarks = 'REMARKS';
  static const String pleaseProvideRemarks = 'Please Provide Remarks';
  static const String attachements = 'ATTACHEMENTS';
  static const String fileUploaded = 'Upload Your Supporting Documents ';
  static const String lemitedTo3FilesForEachLead =
      '(Limited to 3 files for each lead)';
  static const String businessRegistration = 'BUSINESS REGISTRATION';
  static const String acOpeningForm = 'A/C OPENING FORM';
  static const String businessCard = 'BUSINESS CARD';
  static const String other = 'OTHERS';
  static const String pleaseUploadYourDocumentsWithTheFollowingCriteria =
      'Please upload your documents with the following criteria';
  static const String fileFormatHasToBeInJPG =
      '1. File format has to be in jpg(jpeg)';
  static const String maximumOfAFileSizeIs =
      '2.Maximum of a file size is 1MB(Maximum of 3MB for 3 files)';
  static const String limitedTo3FilesForEachLead =
      '3.Limited to 3 files for each lead';
  static const String readyForAccountsOpening = 'Ready for Accounts Opening?';
  static const String uploadedFiles = 'UPLOADED FILES:';
  static const String businesRegistrationFile = 'Business Registration';
  static const String cancel = 'NO';
  static const String submit = 'SUBMIT';
  static const String ok = 'YES';
  static const String okay = "OK";
  static const String back = 'Back';
  static const String leadSubmission = 'Lead Submission';
  static const String accountUpdate = 'Account Update';
  static const String areYouSubmitTheLeadDetails =
      'Are you sure you want to submit the LEAD ?';

  static const kStandardAppBarHeight = 50.0;
  // LeadSubmationScrren Status ------------------------------------------
  static const String toBeFollowedUpByInsideSalesDCR =
      'To be followed up by Inside Sales/DCR';
  static const String insideSalesDCRAssigned = 'Inside Sales/DCR assigned';
  static const String sucessfulAccountOpening = 'Successful Account Opening';
  static const String failedToOpenAccount = 'Failed to Open Account';
  static const String invalidLead = 'Invalid Lead';
  static const String moveToOpenAC = 'Move to Open A/C';
  static const String invalidLeadOrFailedToOpenAccount =
      'Invalid Lead or Failed to Open Account';

  //------------------------------------------------------------------
  //Check EndReson Status on New lead for Invalid Lead
  static const String personalAccount =
      'Personal account or without Business Registration document';
  static const String ineligibleToJoin =
      'Ineligible to join the program (e.g. forwarder)';
  static const String alreadHaveAFedexAccount = 'Already have a FedEx account';
  static const String locatedInNSARegion = 'Located in NSA region';
  static const String duplicateLeadSubmission = 'Duplicate lead submission';
  static const String customerWithOutIntrest =
      'Customers without interest or not willing to be promoted';
  static const String invalidContact = 'Invalid contact';
  static const String nonprofitOrganization = 'Nonprofit Organization';
  static const String industryAssociation = 'Industry Association';
  static const String others1 = 'Others';
//----------------------------------------------------------------------
  //Check EndReson Status on New lead for  invalidAndFaileToOpenEndReasons
  static const String alreadEngageWithCustomer =
      'Already engaged with Customer';
  static const String corporateDecisionAccountRestricition =
      'Corporate Decision/Account Restriction';
  static const String insuffecientIncorrectDetails =
      'Insufficient/ Incorrect Details';
  static const String noOportunityForAdditionalBusiness =
      'No Opportunity for Additional Business';
  static const String notDecisionMaker = 'Not Decision Maker';
  static const String notInterestedPricing = 'Not Intersted (Pricing)';
  static const String notInterestedServives = 'Not interested (Services)';
  static const String notInteerestedTransitTime =
      'Not Interested (Transit Time)';
  static const String notINterestedOthers = 'Not Interested (Others)';
  static const String outOfBusinessClosedBankruptcy =
      'Out of Business/Business Closed/ Bankruptcy';
  static const String notReachable = 'Not reachable';
  static const String others2 = 'Others';
  //--------------------------------------------------
  //Check EndReson Status on New lead for failedToOpenAccountEndReasons
  static const String discountIsNotGoodEnough = 'Discount is not good enough';
  static const String notYetDecided = 'Not yet decided';
  static const String notExpressUser = 'Not express user';
  static const String personalForwarderJeweller =
      'Personal / Forwarder / Jeweller';
  static const String decidedByConsignee = 'Decided by consignee';
  static const String incrrectContactInfo = 'Incorrect contact info';
  static const String othersCommentsAreMandatory =
      'Others (comments are mandatory)';
//-------------------------------

  static const String toBeVisited = 'To be visited';
  static const String rejectToEnrol = 'Reject to Enroll';
  static const String agreeToEnrol =
      'Agree to Enroll - Pending Sales Follow up';
  static const String salesFollowedRejected =
      'Sales followed up and reject to enroll';
  static const String salesDiscount = 'Sales followed up and discount loaded';

  // AccountEndReasonScrren
  static const String unreachable = 'Unreachable';
  static const String notInterested =
      'Not interested (Pricing issue, Program discount not attractive enough and etc.)';
  static const String notApplicable =
      'Not Applicable business (Re-seller/ Forwarder/ Jewelry and etc.)';
  static const String businessMoved = 'Business Moved';
  static const String noPackage = 'No Package to ship';
  static const String others =
      'Others (provide free-text entry for courier to enter reason, optional)';
}
