import 'package:easy_localization/easy_localization.dart';
import 'package:fedex_app/main.dart';
import 'package:flutter/services.dart';
import 'package:flutter_flavor/flutter_flavor.dart';
import 'package:flutter/material.dart';

//BaseURL
String baseUrl = "https://alpstest.dmz.apac.fedex.com/apt/";

//OKTA Configs
String oktaDomain = "purpleid-test.oktapreview.com";
String oktaAuthorizer = 'aus14jeflq47cJVW20h8';
String oktaClientId = '0oa14rsfrccHjQtHi0h8';

String oktaIssuerUrl = 'https://$oktaDomain/oauth2/$oktaAuthorizer';
String oktaDiscoveryUrl =
    'https://$oktaDomain/oauth2/$oktaAuthorizer/.well-known/oauth-authorization-server';

void main() async {
  FlavorConfig(
    name: "Clap-dev",
    variables: {
      "baseUrl": baseUrl,
      "okta_domain": oktaDomain,
      "oktaAuthorizer": oktaAuthorizer,
      "oktaClientId": oktaClientId,
      "oktaIssuerUrl": oktaIssuerUrl,
      "oktaDiscoveryUrl": oktaDiscoveryUrl
    },
  );
  SystemChrome.setSystemUIOverlayStyle(const SystemUiOverlayStyle(
    statusBarColor: Colors.transparent,
  ));
  //HttpOverrides.global = MyHttpOverrides();

  // var httpClient = new HttpClient();
  // httpClient.findProxy = (url) {
  //   return HttpClient.findProxyFromEnvironment(url, environment: {
  //     "HTTP_PROXY": 'http://sin-proxy.apac.fedex.com:3128',
  //     "HTTPS_PROXY": 'http://sin-proxy.apac.fedex.com:3128',
  //     "NO_PROXY":
  //         '*.apac.fedex.com,*.paas.fedex.com,10.44.39.*,localhost,127.0.0.1,::1'
  //   });
  // };

  WidgetsFlutterBinding.ensureInitialized();
  await init();
  runApp(EasyLocalization(
    path: 'assets/language',
    supportedLocales: const [
      Locale('en'),
      Locale('ja'),
      Locale('id'),
      Locale('ko'),
      Locale('my'),
      Locale('th'),
      Locale.fromSubtags(
          languageCode: "zh", scriptCode: "Hant", countryCode: "zh_Hans_CN"),
      Locale.fromSubtags(
          languageCode: "zh", scriptCode: "Hant", countryCode: "zh_Hans_HK"),
      Locale.fromSubtags(
          languageCode: "zh", scriptCode: "Hant", countryCode: "zh_Hans_TW"),
      Locale('vi')
    ],
    fallbackLocale: const Locale('en'),
    useOnlyLangCode: true,
    saveLocale: true,
    //assetLoader: const CodegenLoader(),
    child: const MyApp(),
  ));
}
