import 'package:fedex_app/view/home/home_page.dart';
import 'package:fedex_app/view/login_user/LoginScreen.dart';
import 'package:fedex_app/view/login_user/user_confirmation_page.dart';
import 'package:flutter/material.dart';

import 'view/accounts_penetration/existing_accounts_penetration.dart';
import 'view/accounts_penetration/individual_accounts_penetration.dart';
import 'view/lead_submitted/individual_lead_submited.dart';
import 'view/lead_submitted/lead_submitted_page.dart';
import 'view/new_lead/new_lead_page.dart';
import 'view/performance/my_performance.dart';

final Map<String, WidgetBuilder> routes = {
  MyPerformance.routeName: (ctx) => const MyPerformance(),
  LoginScreen.routeName: (ctx) => const LoginScreen(),
  UserConfirmationPage.routeName: (ctx) => const UserConfirmationPage(),
  NewLeadPage.routeName: (ctx) => const NewLeadPage(),
  HomePageNewPage.routeName: (ctx) => const HomePageNewPage(),
  LeadSubmittedPage.routeName: (ctx) => const LeadSubmittedPage(),
  AccountsPenetrationPage.routeName: (ctx) => const AccountsPenetrationPage(),
  IndividualAccountsPenetrationPage.routeName: (ctx) =>
      const IndividualAccountsPenetrationPage(),
  IndividualLeadSubmitedPage.routeName: (ctx) =>
      const IndividualLeadSubmitedPage(),
};
