class KPIReportNewLead {
  ServiceStatus? serviceStatus;
  ResponseData? responseData;

  KPIReportNewLead({this.serviceStatus, this.responseData});

  KPIReportNewLead.fromJson(Map<String, dynamic> json) {
    serviceStatus = json['serviceStatus'] != null
        ? ServiceStatus.fromJson(json['serviceStatus'])
        : null;
    responseData = json['responseData'] != null
        ? ResponseData.fromJson(json['responseData'])
        : null;
  }

  Map<String, dynamic> toJson() {
    // ignore: prefer_collection_literals
    final Map<String, dynamic> data = Map<String, dynamic>();
    // ignore: unnecessary_this
    if (this.serviceStatus != null) {
      // ignore: unnecessary_this
      data['serviceStatus'] = this.serviceStatus!.toJson();
    }
    // ignore: unnecessary_this
    if (this.responseData != null) {
      // ignore: unnecessary_this
      data['responseData'] = this.responseData!.toJson();
    }
    return data;
  }
}

class ServiceStatus {
  int? statusCode;
  bool? status;
  String? message;

  ServiceStatus({this.statusCode, this.status, this.message});

  ServiceStatus.fromJson(Map<String, dynamic> json) {
    statusCode = json['statusCode'];
    status = json['status'];
    message = json['message'];
  }

  Map<String, dynamic> toJson() {
    // ignore: prefer_collection_literals
    final Map<String, dynamic> data = Map<String, dynamic>();
    // ignore: unnecessary_this
    data['statusCode'] = this.statusCode;
    // ignore: unnecessary_this
    data['status'] = this.status;
    // ignore: unnecessary_this
    data['message'] = this.message;
    return data;
  }
}

class ResponseData {
  Data? data;

  ResponseData({this.data});

  ResponseData.fromJson(Map<String, dynamic> json) {
    data = json['data'] != null ? Data.fromJson(json['data']) : null;
  }

  Map<String, dynamic> toJson() {
    // ignore: prefer_collection_literals
    final Map<String, dynamic> data = Map<String, dynamic>();
    if (this.data != null) {
      data['data'] = this.data!.toJson();
    }
    return data;
  }
}

class Data {
  int? salesLeadGenrated;
  int? accountsOpened;
  int? shipmentCount;
  int? packagesCount;
  RevenueGenerated? revenueGenerated;

  Data(
      {this.salesLeadGenrated,
      this.accountsOpened,
      this.shipmentCount,
      this.packagesCount,
      this.revenueGenerated});

  Data.fromJson(Map<String, dynamic> json) {
    salesLeadGenrated = json['salesLeadGenrated'];
    accountsOpened = json['accountsOpened'];
    shipmentCount = json['shipmentCount'];
    packagesCount = json['packagesCount'];
    revenueGenerated = json['revenueGenerated'] != null
        ? RevenueGenerated.fromJson(json['revenueGenerated'])
        : null;
  }

  Map<String, dynamic> toJson() {
    // ignore: prefer_collection_literals
    final Map<String, dynamic> data = Map<String, dynamic>();
    // ignore: unnecessary_this
    data['salesLeadGenrated'] = this.salesLeadGenrated;
    // ignore: unnecessary_this
    data['accountsOpened'] = this.accountsOpened;
    // ignore: unnecessary_this
    data['shipmentCount'] = this.shipmentCount;
    // ignore: unnecessary_this
    data['packagesCount'] = this.packagesCount;
    // ignore: unnecessary_this
    if (this.revenueGenerated != null) {
      // ignore: unnecessary_this
      data['revenueGenerated'] = this.revenueGenerated!.toJson();
    }
    return data;
  }
}

class RevenueGenerated {
  double? sevenDays;
  double? twentyOneDays;
  double? thirtyDays;

  RevenueGenerated({this.sevenDays, this.twentyOneDays, this.thirtyDays});

  RevenueGenerated.fromJson(Map<String, dynamic> json) {
    sevenDays = json['sevenDays'];
    twentyOneDays = json['twentyOneDays'];
    thirtyDays = json['thirtyDays'];
  }

  Map<String, dynamic> toJson() {
    // ignore: prefer_collection_literals
    final Map<String, dynamic> data = Map<String, dynamic>();
    // ignore: unnecessary_this
    data['sevenDays'] = this.sevenDays;
    // ignore: unnecessary_this
    data['twentyOneDays'] = this.twentyOneDays;
    // ignore: unnecessary_this
    data['thirtyDays'] = this.thirtyDays;
    return data;
  }
}
