import 'dart:convert';

import 'package:fedex_app/model/file_download.dart';
import 'package:fedex_app/model/individual_account_model.dart';
import 'package:fedex_app/model/new_lead_model.dart';
import 'package:fedex_app/model/user_model.dart';
import 'package:fedex_app/utility/services/api_service.dart';
import 'package:fedex_app/utility/services/base_service.dart';
import 'package:flutter/cupertino.dart';

import 'account_existing_update.dart';
import 'add_comments.dart';
import 'delete_file.dart';
import 'individual_lead_model.dart';
import 'kpi_date_status.dart';
import 'kpi_report_newlead.dart';
import 'kpi_reports_accounts.dart';
import 'notification_response.dart';

class APiRepository {
  final BaseService _apiService = ApiService();

  Future<UserConfirmationModel> fetchUserConfirmationDetail(
      String url, requestBody, String token) async {
    dynamic response = await _apiService.postResponse(
        url,
        {
          'content-type': 'application/json',
          "Access-Control-Allow-Origin": "*",
          "Authorization": "Bearer $token"
        },
        jsonEncode(requestBody));
    debugPrint('json_encode: ${jsonEncode(response)}');

    UserConfirmationModel user = UserConfirmationModel.fromJson(response);

    return user;
  }

  Future<CommentsResponseModel> fetchAddComments(
      String url, requestBody, String token) async {
    dynamic response = await _apiService.postResponse(
        url,
        {'content-type': 'application/json', "Authorization": "Bearer $token"},
        jsonEncode(requestBody));
    CommentsResponseModel addComments =
        CommentsResponseModel.fromJson(response);
    return addComments;
  }

  Future<IndividualAccountModel> fetchIndividualAccountComments(
      String url, requestBody, String token) async {
    dynamic response = await _apiService.postResponse(
        url,
        {'content-type': 'application/json', "Authorization": "Bearer $token"},
        jsonEncode(requestBody));
    IndividualAccountModel addComments =
        IndividualAccountModel.fromJson(response);
    return addComments;
  }

  Future<AccountExistingUpdate> fetchExistingAccountStatusUpdate(
      String url, requestBody, String token) async {
    dynamic response = await _apiService.postResponse(
        url,
        {'content-type': 'application/json', "Authorization": "Bearer $token"},
        jsonEncode(requestBody),
        baseURL: BaseService.baseAccountUrl);
    AccountExistingUpdate addComments =
        AccountExistingUpdate.fromJson(response);
    return addComments;
  }

  Future<dynamic> fetchLeadListDetail(
      String url, requestBody, String token) async {
    dynamic response = await _apiService.postResponse(
        url,
        {'content-type': 'application/json', "Authorization": "Bearer $token"},
        jsonEncode(requestBody));
    return response;
  }

  Future<dynamic> fetchTimeFrameDetail(
      String url, requestBody, String token) async {
    dynamic response = await _apiService.postResponse(
        url,
        {'content-type': 'application/json', "Authorization": "Bearer $token"},
        jsonEncode(requestBody),
        baseURL: BaseService.baseAccountUrl);
    return response;
  }

  Future<dynamic> fetchAccountPenetrationDetail(
      String url, requestBody, String token) async {
    dynamic response = await _apiService.postResponse(
        url,
        {'content-type': 'application/json', "Authorization": "Bearer $token"},
        jsonEncode(requestBody),
        baseURL: BaseService.baseAccountUrl);
    return response;
  }

  Future<LeadResponseData> fetchNewLeadData(
      String url, Map<String, dynamic> jsonBody, String token) async {
    dynamic response = await _apiService.postResponse(
        url,
        {'content-type': 'application/json', "Authorization": "Bearer $token"},
        jsonEncode(jsonBody));
    LeadResponseData _lead = LeadResponseData.fromJson(response);
    return _lead;
  }

  Future<DeleteFile> deleteFileUploaded(
      String url, List<String> jsonBody, String token) async {
    //
    dynamic response = await _apiService.deleteResponse(
        url,
        {'content-type': 'application/json', "Authorization": "Bearer $token"},
        jsonEncode(jsonBody));
    DeleteFile file = DeleteFile.fromJson(response);
    return file;
  }

  Future<IndividualAccountModel> fetchAccountDetails(String token, String value,
      {String baseURL = ""}) async {
    dynamic response = await _apiService.getResponse(
        value, {"Authorization": "Bearer $token"},
        baseURL: baseURL);

    IndividualAccountModel indvidualLead =
        IndividualAccountModel.fromJson(response);
    return indvidualLead;
  }

  Future<AccountExistingUpdate> updateExistingAccountPenetration(
      String token, String url,
      {String baseURL = ""}) async {
    // ignore: unused_local_variable
    final body = [];
    dynamic response = await _apiService.postResponse(
        url,
        {'content-type': 'application/json', "Authorization": "Bearer $token"},
        null,
        baseURL: baseURL);
    AccountExistingUpdate existingUpdate =
        AccountExistingUpdate.fromJson(response);
    return existingUpdate;
  }

  Future<IndividualLeadResponse> fetchLeadDetails(String token, String value,
      {String baseURL = ""}) async {
    dynamic response = await _apiService.getResponse(
        value, {"Authorization": "Bearer $token"},
        baseURL: baseURL);

    IndividualLeadResponse indvidualLead =
        IndividualLeadResponse.fromJson(response);
    return indvidualLead;
  }

  Future<NotificationResponse> fetchNotificationDetails(
      String value, String token) async {
    dynamic response = await _apiService
        .getResponse(value, {"Authorization": "Bearer $token"});

    NotificationResponse indvidualLead =
        NotificationResponse.fromJson(response);
    return indvidualLead;
  }

  Future<NotificationResponse> readNotification(
      String url, List<Map<String, Object?>> jsonBody, String token) async {
    dynamic response = await _apiService.putResponse(
        url,
        {'content-type': 'application/json', "Authorization": "Bearer $token"},
        jsonEncode(jsonBody));

    NotificationResponse indvidualLead =
        NotificationResponse.fromJson(response);
    return indvidualLead;
  }

  Future<KPIReportNewLead> fetchKPIReportsNewLead(
      String url, requestBody, String token) async {
    dynamic response = await _apiService.postResponse(
        url,
        {
          'content-type': 'application/json',
          "Access-Control-Allow-Origin": "*",
          "Authorization": "Bearer $token"
        },
        jsonEncode(requestBody));

    KPIReportNewLead reportNewLead = KPIReportNewLead.fromJson(response);

    return reportNewLead;
  }

  Future<KpiAccountsData> fetchKPIReportsAccounts(
      String url, requestBody, String token) async {
    dynamic response = await _apiService.postResponse(
        url,
        {
          'content-type': 'application/json',
          "Access-Control-Allow-Origin": "*",
          "Authorization": "Bearer $token"
        },
        jsonEncode(requestBody),
        baseURL: BaseService.baseAccountUrl);

    KpiAccountsData reportNewLead = KpiAccountsData.fromJson(response);

    return reportNewLead;
  }

  Future<KpiDateStatusResponse> fetchKpiNewleadMonths(
      String url, String token) async {
    dynamic response = await _apiService.getResponse(
      url,
      {"Authorization": "Bearer $token"},
    );

    KpiDateStatusResponse reportNewLead =
        KpiDateStatusResponse.fromJson(response);

    return reportNewLead;
  }

  Future<KpiDateStatusResponse> fetchKpiAccountsMonths(
      String url, String token) async {
    dynamic response = await _apiService.getResponse(
        url, {"Authorization": "Bearer $token"},
        baseURL: BaseService.baseAccountUrl);

    KpiDateStatusResponse reportNewLead =
        KpiDateStatusResponse.fromJson(response);

    return reportNewLead;
  }

  Future<FileDownloadResponse> getFileDownload(
      String value, String token) async {
    dynamic response = await _apiService
        .getResponse(value, {"Authorization": "Bearer $token"});

    FileDownloadResponse downloadDocument =
        FileDownloadResponse.fromJson(response);
    return downloadDocument;
  }
}
