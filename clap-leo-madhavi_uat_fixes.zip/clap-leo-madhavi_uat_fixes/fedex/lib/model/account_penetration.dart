class AccountPenetration {
  ServiceStatus? serviceStatus;
  ResponseData? responseData;

  AccountPenetration({this.serviceStatus, this.responseData});

  AccountPenetration.fromJson(Map<String, dynamic> json) {
    serviceStatus = json['serviceStatus'] != null
        ? ServiceStatus.fromJson(json['serviceStatus'])
        : null;
    responseData = json['responseData'] != null
        ? ResponseData.fromJson(json['responseData'])
        : null;
  }

  Map<String, dynamic> toJson() {
    // ignore: prefer_collection_literals
    final Map<String, dynamic> data = Map<String, dynamic>();
    // ignore: unnecessary_this
    if (this.serviceStatus != null) {
      // ignore: unnecessary_this
      data['serviceStatus'] = this.serviceStatus!.toJson();
    }
    // ignore: unnecessary_this
    if (this.responseData != null) {
      // ignore: unnecessary_this
      data['responseData'] = this.responseData!.toJson();
    }
    return data;
  }
}

class ServiceStatus {
  int? statusCode;
  bool? status;
  String? message;

  ServiceStatus({this.statusCode, this.status, this.message});

  ServiceStatus.fromJson(Map<String, dynamic> json) {
    statusCode = json['statusCode'];
    status = json['status'];
    message = json['message'];
  }

  Map<String, dynamic> toJson() {
    // ignore: prefer_collection_literals
    final Map<String, dynamic> data = Map<String, dynamic>();
    // ignore: unnecessary_this
    data['statusCode'] = this.statusCode;
    // ignore: unnecessary_this
    data['status'] = this.status;
    // ignore: unnecessary_this
    data['message'] = this.message;
    return data;
  }
}

class ResponseData {
  Data? data;

  ResponseData({this.data});

  ResponseData.fromJson(Map<String, dynamic> json) {
    data = json['data'] != null ? Data.fromJson(json['data']) : null;
  }

  Map<String, dynamic> toJson() {
    // ignore: prefer_collection_literals
    final Map<String, dynamic> data = Map<String, dynamic>();
    if (this.data != null) {
      data['data'] = this.data!.toJson();
    }
    return data;
  }
}

class Data {
  List<ViewAccountList>? viewAccountList;
  ViewAccountPagination? viewAccountPagination;
  Object? assignFlag;

  Data({this.viewAccountList, this.viewAccountPagination, this.assignFlag});

  Data.fromJson(Map<String, dynamic> json) {
    if (json['viewAccountList'] != null) {
      viewAccountList = <ViewAccountList>[];
      json['viewAccountList'].forEach((v) {
        viewAccountList!.add(ViewAccountList.fromJson(v));
      });
    }
    viewAccountPagination = json['viewAccountPagination'] != null
        ? ViewAccountPagination.fromJson(json['viewAccountPagination'])
        : null;
    assignFlag = json['assignFlag'];
  }

  Map<String, dynamic> toJson() {
    // ignore: prefer_collection_literals
    final Map<String, dynamic> data = Map<String, dynamic>();
    // ignore: unnecessary_this
    if (this.viewAccountList != null) {
      data['viewAccountList'] =
          // ignore: unnecessary_this
          this.viewAccountList!.map((v) => v.toJson()).toList();
    }
    // ignore: unnecessary_this
    if (this.viewAccountPagination != null) {
      // ignore: unnecessary_this
      data['viewAccountPagination'] = this.viewAccountPagination!.toJson();
    }
    // ignore: unnecessary_this
    data['assignFlag'] = this.assignFlag;
    return data;
  }
}

class ViewAccountList {
  int? accountOID;
  String? accountId;
  Object? accountFileOID;
  String? accountNumber;
  String? companyName;
  String? customerFirstName;
  String? customerLastName;
  String? contactPhone;
  String? stationId;
  String? routeNumber;
  String? courierId;
  String? courierName;
  String? accountStatus;
  String? statusDate;
  String? month;
  String? countryCode;
  String? address1;
  String? address2;
  String? statusTimeStamp;
  String? invalidStatus;
  String? city;
  String? postalCode;
  String? lastFollowUpDate;

  ViewAccountList(
      {this.accountOID,
      this.accountId,
      this.accountFileOID,
      this.accountNumber,
      this.companyName,
      this.customerFirstName,
      this.customerLastName,
      this.contactPhone,
      this.stationId,
      this.routeNumber,
      this.courierId,
      this.courierName,
      this.accountStatus,
      this.statusDate,
      this.month,
      this.countryCode,
      this.address1,
      this.address2,
      this.statusTimeStamp,
      this.invalidStatus,
      this.city,
      this.postalCode,
      this.lastFollowUpDate});

  ViewAccountList.fromJson(Map<String, dynamic> json) {
    accountOID = json['accountOID'];
    accountId = json['accountId'];
    accountFileOID = json['accountFileOID'];
    accountNumber = json['accountNumber'];
    companyName = json['companyName'];
    customerFirstName = json['customerFirstName'];
    customerLastName = json['customerLastName'];
    contactPhone = json['contactPhone'];
    stationId = json['stationId'];
    routeNumber = json['routeNumber'];
    courierId = json['courierId'];
    courierName = json['courierName'];
    accountStatus = json['accountStatus'];
    statusDate = json['statusDate'];
    month = json['month'];
    countryCode = json['countryCode'];
    address1 = json['address1'];
    address2 = json['address2'];
    statusTimeStamp = json['statusTimeStamp'];
    invalidStatus = json['invalidStatus'];
    city = json['city'];
    postalCode = json['postalCode'];
    lastFollowUpDate = json['lastFollowUpDate'];
  }
  Map<String, dynamic> toJson() {
    // ignore: prefer_collection_literals
    final Map<String, dynamic> data = Map<String, dynamic>();
    // ignore: unnecessary_this
    data['accountOID'] = this.accountOID;
    // ignore: unnecessary_this
    data['accountId'] = this.accountId;
    // ignore: unnecessary_this
    data['accountFileOID'] = this.accountFileOID;
    // ignore: unnecessary_this
    data['accountNumber'] = this.accountNumber;
    // ignore: unnecessary_this
    data['companyName'] = this.companyName;
    // ignore: unnecessary_this
    data['customerFirstName'] = this.customerFirstName;
    // ignore: unnecessary_this
    data['customerLastName'] = this.customerLastName;
    // ignore: unnecessary_this
    data['contactPhone'] = this.contactPhone;
    // ignore: unnecessary_this
    data['stationId'] = this.stationId;
    // ignore: unnecessary_this
    data['routeNumber'] = this.routeNumber;
    // ignore: unnecessary_this
    data['courierId'] = this.courierId;
    // ignore: unnecessary_this
    data['courierName'] = this.courierName;
    // ignore: unnecessary_this
    data['accountStatus'] = this.accountStatus;
    // ignore: unnecessary_this
    data['statusDate'] = this.statusDate;
    // ignore: unnecessary_this
    data['month'] = this.month;
    // ignore: unnecessary_this
    data['countryCode'] = this.countryCode;
    // ignore: unnecessary_this
    data['address1'] = this.address1;
    // ignore: unnecessary_this
    data['address2'] = this.address2;
    // ignore: unnecessary_this
    data['statusTimeStamp'] = this.statusTimeStamp;
    // ignore: unnecessary_this
    data['invalidStatus'] = this.invalidStatus;
    // ignore: unnecessary_this
    data['city'] = this.city;
    // ignore: unnecessary_this
    data['postalCode'] = this.postalCode;
    // ignore: unnecessary_this
    data['lastFollowUpDate'] = this.lastFollowUpDate;
    return data;
  }
}

class ViewAccountPagination {
  int? totalRecords;
  int? pageNumber;
  int? pageSize;

  ViewAccountPagination({this.totalRecords, this.pageNumber, this.pageSize});

  ViewAccountPagination.fromJson(Map<String, dynamic> json) {
    totalRecords = json['totalRecords'];
    pageNumber = json['pageNumber'];
    pageSize = json['pageSize'];
  }

  Map<String, dynamic> toJson() {
    // ignore: prefer_collection_literals
    final Map<String, dynamic> data = Map<String, dynamic>();
    // ignore: unnecessary_this
    data['totalRecords'] = this.totalRecords;
    // ignore: unnecessary_this
    data['pageNumber'] = this.pageNumber;
    // ignore: unnecessary_this
    data['pageSize'] = this.pageSize;
    return data;
  }
}
