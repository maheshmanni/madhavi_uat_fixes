class NotificationResponse {
  ServiceStatus? serviceStatus;
  ResponseData? responseData;

  NotificationResponse({this.serviceStatus, this.responseData});

  NotificationResponse.fromJson(Map<String, dynamic> json) {
    serviceStatus = json['serviceStatus'] != null
        ? ServiceStatus.fromJson(json['serviceStatus'])
        : null;
    responseData = json['responseData'] != null
        ? ResponseData.fromJson(json['responseData'])
        : null;
  }

  Map<String, dynamic> toJson() {
    // ignore: prefer_collection_literals
    final Map<String, dynamic> data = Map<String, dynamic>();
    // ignore: unnecessary_this
    if (this.serviceStatus != null) {
      // ignore: unnecessary_this
      data['serviceStatus'] = this.serviceStatus!.toJson();
    }
    // ignore: unnecessary_this
    if (this.responseData != null) {
      // ignore: unnecessary_this
      data['responseData'] = this.responseData!.toJson();
    }
    return data;
  }
}

class ServiceStatus {
  int? statusCode;
  bool? status;
  String? message;

  ServiceStatus({this.statusCode, this.status, this.message});

  ServiceStatus.fromJson(Map<String, dynamic> json) {
    statusCode = json['statusCode'];
    status = json['status'];
    message = json['message'];
  }

  Map<String, dynamic> toJson() {
    // ignore: prefer_collection_literals
    final Map<String, dynamic> data = Map<String, dynamic>();
    // ignore: unnecessary_this
    data['statusCode'] = this.statusCode;
    // ignore: unnecessary_this
    data['status'] = this.status;
    // ignore: unnecessary_this
    data['message'] = this.message;
    return data;
  }
}

class ResponseData {
  List<NData>? data;

  ResponseData({this.data});

  ResponseData.fromJson(Map<String, dynamic> json) {
    if (json['data'] != null) {
      data = <NData>[];
      json['data'].forEach((v) {
        data!.add(NData.fromJson(v));
      });
    }
  }

  Map<String, dynamic> toJson() {
    // ignore: prefer_collection_literals
    final Map<String, dynamic> data = Map<String, dynamic>();
    if (this.data != null) {
      data['data'] = this.data!.map((v) => v.toJson()).toList();
    }
    return data;
  }
}

class NData {
  int? leadIOD;
  String? title;
  String? body;
  String? type;
  String? from;
  Object? leadNoteOID;

  NData(
      {this.leadIOD,
      this.title,
      this.body,
      this.type,
      this.from,
      this.leadNoteOID});

  NData.fromJson(Map<String, dynamic> json) {
    leadIOD = json['id'];
    title = json['title'];
    body = json['body'];
    type = json['type'];
    from = json['from'];
    leadNoteOID = json['noteOID'];
  }

  Map<String, dynamic> toJson() {
    // ignore: prefer_collection_literals
    final Map<String, dynamic> data = Map<String, dynamic>();
    // ignore: unnecessary_this
    data['id'] = this.leadIOD;
    // ignore: unnecessary_this
    data['title'] = this.title;
    // ignore: unnecessary_this
    data['body'] = this.body;
    // ignore: unnecessary_this
    data['type'] = this.type;
    // ignore: unnecessary_this
    data['from'] = this.from;
    // ignore: unnecessary_this
    data['noteOID'] = this.leadNoteOID;
    return data;
  }
}
