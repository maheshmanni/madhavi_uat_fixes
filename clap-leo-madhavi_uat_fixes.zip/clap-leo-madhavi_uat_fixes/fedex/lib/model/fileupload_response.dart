// ignore_for_file: prefer_const_constructors
class FileUploadResponse {
  ServiceStatus? serviceStatus;
  ResponseData? responseData;

  FileUploadResponse({this.serviceStatus, this.responseData});

  FileUploadResponse.fromJson(Map<String, dynamic> json) {
    serviceStatus = json['serviceStatus'] != null
        ? ServiceStatus.fromJson(json['serviceStatus'])
        : null;
    responseData = json['responseData'] != null
        ? ResponseData.fromJson(json['responseData'])
        : null;
  }

  Map<String, dynamic> toJson() {
    // ignore: prefer_collection_literals
    final Map<String, dynamic> data = Map<String, dynamic>();
    // ignore: unnecessary_this
    if (this.serviceStatus != null) {
      // ignore: unnecessary_this
      data['serviceStatus'] = this.serviceStatus!.toJson();
    }
    // ignore: unnecessary_this
    if (this.responseData != null) {
      // ignore: unnecessary_this
      data['responseData'] = this.responseData!.toJson();
    }
    return data;
  }
}

class ServiceStatus {
  int? statusCode;
  bool? status;
  String? message;

  ServiceStatus({this.statusCode, this.status, this.message});

  ServiceStatus.fromJson(Map<String, dynamic> json) {
    statusCode = json['statusCode'];
    status = json['status'];
    message = json['message'];
  }

  Map<String, dynamic> toJson() {
    // ignore: prefer_collection_literals
    final Map<String, dynamic> data = Map<String, dynamic>();
    // ignore: unnecessary_this
    data['statusCode'] = this.statusCode;
    // ignore: unnecessary_this
    data['status'] = this.status;
    // ignore: unnecessary_this
    data['message'] = this.message;
    return data;
  }
}

class ResponseData {
  Data? data;

  ResponseData({this.data});

  ResponseData.fromJson(Map<String, dynamic> json) {
    data = json['data'] != null ? Data.fromJson(json['data']) : null;
  }

  Map<String, dynamic> toJson() {
    // ignore: prefer_collection_literals
    final Map<String, dynamic> data = Map<String, dynamic>();
    if (this.data != null) {
      data['data'] = this.data!.toJson();
    }
    return data;
  }
}

class Data {
  String? key;
  String? fileName;
  int? size;
  bool? documentUploaded;

  Data({this.key, this.fileName, this.size, this.documentUploaded});

  Data.fromJson(Map<String, dynamic> json) {
    key = json['key'];
    fileName = json['fileName'];
    size = json['size'];
    documentUploaded = json['documentUploaded'];
  }

  Map<String, dynamic> toJson() {
    // ignore: prefer_collection_literals
    final Map<String, dynamic> data = Map<String, dynamic>();
    // ignore: unnecessary_this
    data['key'] = this.key;
    // ignore: unnecessary_this
    data['fileName'] = this.fileName;
    // ignore: unnecessary_this
    data['size'] = this.size;
    // ignore: unnecessary_this
    data['documentUploaded'] = this.documentUploaded;
    return data;
  }
}
