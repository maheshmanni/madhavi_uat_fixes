import 'individual_lead_model.dart';

class CommentsResponseModel {
  ServiceStatus? serviceStatus;
  ResponseData? responseData;

  CommentsResponseModel({this.serviceStatus, this.responseData});

  CommentsResponseModel.fromJson(Map<String, dynamic> json) {
    serviceStatus = json['serviceStatus'] != null
        ? ServiceStatus.fromJson(json['serviceStatus'])
        : null;
    responseData = json['responseData'] != null
        ? ResponseData.fromJson(json['responseData'])
        : null;
  }

  Map<String, dynamic> toJson() {
    // ignore: prefer_collection_literals
    final Map<String, dynamic> data = Map<String, dynamic>();
    // ignore: unnecessary_this
    if (this.serviceStatus != null) {
      // ignore: unnecessary_this
      data['serviceStatus'] = this.serviceStatus!.toJson();
    }
    // ignore: unnecessary_this
    if (this.responseData != null) {
      // ignore: unnecessary_this
      data['responseData'] = this.responseData!.toJson();
    }
    return data;
  }
}

class ServiceStatus {
  int? statusCode;
  bool? status;
  String? message;

  ServiceStatus({this.statusCode, this.status, this.message});

  ServiceStatus.fromJson(Map<String, dynamic> json) {
    statusCode = json['statusCode'];
    status = json['status'];
    message = json['message'];
  }

  Map<String, dynamic> toJson() {
    // ignore: prefer_collection_literals
    final Map<String, dynamic> data = Map<String, dynamic>();
    // ignore: unnecessary_this
    data['statusCode'] = this.statusCode;
    // ignore: unnecessary_this
    data['status'] = this.status;
    // ignore: unnecessary_this
    data['message'] = this.message;
    return data;
  }
}

class ResponseData {
  Data? data;

  ResponseData({this.data});

  ResponseData.fromJson(Map<String, dynamic> json) {
    data = json['data'] != null ? Data.fromJson(json['data']) : null;
  }

  Map<String, dynamic> toJson() {
    // ignore: prefer_collection_literals
    final Map<String, dynamic> data = Map<String, dynamic>();
    if (this.data != null) {
      data['data'] = this.data!.toJson();
    }
    return data;
  }
}

class Data {
  List<LeadComments>? leadComments;
  String? status;
  String? endReason;

  Data({this.leadComments, this.status, this.endReason});

  Data.fromJson(Map<String, dynamic> json) {
    if (json['leadComments'] != null) {
      leadComments = <LeadComments>[];
      json['leadComments'].forEach((v) {
        leadComments!.add(LeadComments.fromJson(v));
      });
    }
    status = json['status'];
    endReason = json['endReason'];
  }

  Map<String, dynamic> toJson() {
    // ignore: prefer_collection_literals
    final Map<String, dynamic> data = Map<String, dynamic>();
    // ignore: unnecessary_this
    if (this.leadComments != null) {
      // ignore: unnecessary_this
      data['leadComments'] = this.leadComments!.map((v) => v.toJson()).toList();
    }
    // ignore: unnecessary_this
    data['status'] = this.status;
    // ignore: unnecessary_this
    data['endReason'] = this.endReason;
    return data;
  }
}
