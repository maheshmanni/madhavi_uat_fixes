class LeadListModel {
  ServiceStatus? serviceStatus;
  ResponseData? responseData;

  LeadListModel({this.serviceStatus, this.responseData});

  LeadListModel.fromJson(Map<String, dynamic> json) {
    serviceStatus = json['serviceStatus'] != null
        ? ServiceStatus.fromJson(json['serviceStatus'])
        : null;
    responseData = json['responseData'] != null
        ? ResponseData.fromJson(json['responseData'])
        : null;
  }
  Map<String, dynamic> toJson() {
    final data = <String, dynamic>{};
    if (serviceStatus != null) {
      data['serviceStatus'] = serviceStatus?.toJson();
    }
    if (responseData != null) {
      data['responseData'] = responseData?.toJson();
    }
    return data;
  }
}

class ServiceStatus {
  int? statusCode;
  bool? status;
  String? message;
  ServiceStatus({this.statusCode, this.status, this.message});

  ServiceStatus.fromJson(Map<String, dynamic> json) {
    statusCode = json['statusCode'];
    status = json['status'];
    message = json['message'];
  }
  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['statusCode'] = statusCode;
    data['status'] = status;
    data['message'] = message;
    return data;
  }
}

class ResponseData {
  Data? data;
  ResponseData({this.data});

  ResponseData.fromJson(Map<String, dynamic> json) {
    data = json['data'] != null ? Data.fromJson(json['data']) : null;
  }
  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    if (this.data != null) {
      data['data'] = this.data!.toJson();
    }
    return data;
  }
}

class Data {
  List<ViewLeadList>? viewLeadList;
  ViewLeadPagination? viewLeadPagination;
  Data({this.viewLeadList, this.viewLeadPagination});

  Data.fromJson(Map<String, dynamic> json) {
    if (json['viewLeadList'] != null) {
      viewLeadList = <ViewLeadList>[];
      json['viewLeadList'].forEach((v) {
        viewLeadList?.add(ViewLeadList.fromJson(v));
      });
    }
    viewLeadPagination = json['viewLeadPagination'] != null
        ? ViewLeadPagination.fromJson(json['viewLeadPagination'])
        : null;
  }
  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    if (viewLeadList != null) {
      data['viewLeadList'] = viewLeadList?.map((v) => v.toJson()).toList();
    }
    if (viewLeadPagination != null) {
      data['viewLeadPagination'] = viewLeadPagination?.toJson();
    }
    return data;
  }
}

class ViewLeadList {
  int? leadOID;
  String? leadId;
  String? companyName;
  String? customerFirstName;
  String? customerLastName;
  String? contactPhone;
  String? courierId;
  String? courierName;
  String? stationId;
  String? routeNumber;
  String? leadStatus;
  String? assignStatus;
  String? createdDate;
  String? remark;
  ViewLeadList(
      {this.leadOID,
      this.leadId,
      this.companyName,
      this.customerFirstName,
      this.customerLastName,
      this.contactPhone,
      this.courierId,
      this.courierName,
      this.stationId,
      this.routeNumber,
      this.leadStatus,
      this.assignStatus,
      this.createdDate,
      this.remark});
  ViewLeadList.fromJson(Map<String, dynamic> json) {
    leadOID = json['leadOID'];
    leadId = json['leadId'];
    companyName = json['companyName'];
    customerFirstName = json['customerFirstName'];
    customerLastName = json['customerLastName'];
    contactPhone = json['contactPhone'];
    courierId = json['courierId'];
    courierName = json['courierName'];
    stationId = json['stationId'];
    routeNumber = json['routeNumber'];
    leadStatus = json['leadStatus'];
    assignStatus = json['assignStatus'];
    createdDate = json['createdDate'];
    remark = json['remark'];
  }
  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['leadOID'] = leadOID;
    data['leadId'] = leadId;
    data['companyName'] = companyName;
    data['customerFirstName'] = customerFirstName;
    data['customerLastName'] = customerLastName;
    data['contactPhone'] = contactPhone;
    data['courierId'] = courierId;
    data['courierName'] = courierName;
    data['stationId'] = stationId;
    data['routeNumber'] = routeNumber;
    data['leadStatus'] = leadStatus;
    data['assignStatus'] = assignStatus;
    data['createdDate'] = createdDate;
    data['remark'] = remark;
    return data;
  }
}

class ViewLeadPagination {
  int? totalRecords;
  int? pageNumber;
  int? pageSize;
  ViewLeadPagination({this.totalRecords, this.pageNumber, this.pageSize});

  ViewLeadPagination.fromJson(Map<String, dynamic> json) {
    totalRecords = json['totalRecords'];
    pageNumber = json['pageNumber'];
    pageSize = json['pageSize'];
  }
  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['totalRecords'] = totalRecords;
    data['pageNumber'] = pageNumber;
    data['pageSize'] = pageSize;
    return data;
  }
}

class BodyRequest {
  List<Filters>? filters;
  int? pageNumber;
  int? pageSize;
  String? sortBy;

  BodyRequest({this.filters, this.pageNumber, this.pageSize, this.sortBy});

  BodyRequest.fromJson(Map<String, dynamic> json) {
    if (json['filters'] != null) {
      // ignore: deprecated_member_use
      filters = <Filters>[];
      json['filters'].forEach((v) {
        filters!.add(Filters.fromJson(v));
      });
    }
    pageNumber = json['pageNumber'];
    pageSize = json['pageSize'];
    sortBy = json['sortBy'];
  }

  Map<String, dynamic> toJson() {
    // ignore: prefer_collection_literals
    final Map<String, dynamic> data = Map<String, dynamic>();
    // ignore: unnecessary_this
    if (this.filters != null) {
      // ignore: unnecessary_this
      data['filters'] = this.filters!.map((v) => v.toJson()).toList();
    }
    // ignore: unnecessary_this
    data['pageNumber'] = this.pageNumber;
    // ignore: unnecessary_this
    data['pageSize'] = this.pageSize;
    // ignore: unnecessary_this
    data['sortBy'] = this.sortBy;
    return data;
  }
}

class Filters {
  String? date;
  String? status;

  Filters({this.date, this.status});

  Filters.fromJson(Map<String, dynamic> json) {
    date = json['date'];
    status = json['status'];
  }

  Map<String, dynamic> toJson() {
    // ignore: prefer_collection_literals
    final Map<String, dynamic> data = Map<String, dynamic>();
    // ignore: unnecessary_this
    data['date'] = this.date;
    // ignore: unnecessary_this
    data['status'] = this.status;
    return data;
  }
}
