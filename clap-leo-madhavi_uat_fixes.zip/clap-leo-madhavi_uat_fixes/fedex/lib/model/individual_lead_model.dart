class IndividualLeadResponse {
  ServiceStatus? serviceStatus;
  ResponseData? responseData;

  IndividualLeadResponse({this.serviceStatus, this.responseData});

  IndividualLeadResponse.fromJson(Map<String, dynamic> json) {
    serviceStatus = json['serviceStatus'] != null
        ? ServiceStatus.fromJson(json['serviceStatus'])
        : null;
    responseData = json['responseData'] != null
        ? ResponseData.fromJson(json['responseData'])
        : null;
  }

  Map<String, dynamic> toJson() {
    // ignore: prefer_collection_literals
    final Map<String, dynamic> data = Map<String, dynamic>();
    // ignore: unnecessary_this
    if (this.serviceStatus != null) {
      // ignore: unnecessary_this
      data['serviceStatus'] = this.serviceStatus!.toJson();
    }
    // ignore: unnecessary_this
    if (this.responseData != null) {
      // ignore: unnecessary_this
      data['responseData'] = this.responseData!.toJson();
    }
    return data;
  }
}

class ServiceStatus {
  int? statusCode;
  bool? status;
  String? message;

  ServiceStatus({this.statusCode, this.status, this.message});

  ServiceStatus.fromJson(Map<String, dynamic> json) {
    statusCode = json['statusCode'];
    status = json['status'];
    message = json['message'];
  }

  Map<String, dynamic> toJson() {
    // ignore: prefer_collection_literals
    final Map<String, dynamic> data = Map<String, dynamic>();
    // ignore: unnecessary_this
    data['statusCode'] = this.statusCode;
    // ignore: unnecessary_this
    data['status'] = this.status;
    // ignore: unnecessary_this
    data['message'] = this.message;
    return data;
  }
}

class ResponseData {
  Data? data;

  ResponseData({this.data});

  ResponseData.fromJson(Map<String, dynamic> json) {
    data = json['data'] != null ? Data.fromJson(json['data']) : null;
  }

  Map<String, dynamic> toJson() {
    // ignore: prefer_collection_literals
    final Map<String, dynamic> data = Map<String, dynamic>();
    if (this.data != null) {
      data['data'] = this.data!.toJson();
    }
    return data;
  }
}

class Data {
  LeadDetails? leadDetails;
  List<LeadComments>? leadComments;
  List<LeadAttachments>? leadAttachments;

  Data({this.leadDetails, this.leadComments, this.leadAttachments});

  Data.fromJson(Map<String, dynamic> json) {
    leadDetails = json['leadDetails'] != null
        ? LeadDetails.fromJson(json['leadDetails'])
        : null;
    if (json['leadComments'] != null) {
      leadComments = <LeadComments>[];
      json['leadComments'].forEach((v) {
        leadComments!.add(LeadComments.fromJson(v));
      });
    }
    if (json['leadAttachments'] != null) {
      leadAttachments = <LeadAttachments>[];
      json['leadAttachments'].forEach((v) {
        leadAttachments!.add(LeadAttachments.fromJson(v));
      });
    }
  }

  Map<String, dynamic> toJson() {
    // ignore: prefer_collection_literals
    final Map<String, dynamic> data = Map<String, dynamic>();
    // ignore: unnecessary_this
    if (this.leadDetails != null) {
      // ignore: unnecessary_this
      data['leadDetails'] = this.leadDetails!.toJson();
    }
    // ignore: unnecessary_this
    if (this.leadComments != null) {
      // ignore: unnecessary_this
      data['leadComments'] = this.leadComments!.map((v) => v.toJson()).toList();
    }
    // ignore: unnecessary_this
    if (this.leadAttachments != null) {
      // ignore: unnecessary_this
      data['leadAttachments'] =
          // ignore: unnecessary_this
          this.leadAttachments!.map((v) => v.toJson()).toList();
    }
    return data;
  }
}

class LeadDetails {
  String? leadId;
  int? leadOID;
  String? companyName;
  String? firstName;
  String? lastName;
  String? contactPhone;
  String? contactMobile;
  String? email;
  String? customerTitle;
  String? city;
  String? address1;
  String? address2;
  String? postalCode;
  String? remark;
  String? submitterUserId;
  String? submitterUserName;
  String? submittedDate;
  String? locationCode;
  String? routerNumber;
  String? managerId;
  String? createdTimeStamp;
  String? status;
  String? endReason;
  String? statusTimeStamp;
  String? salesId;
  String? accountNumber;
  bool? dcrEnabled;

  LeadDetails(
      {this.leadId,
      this.leadOID,
      this.companyName,
      this.firstName,
      this.lastName,
      this.contactPhone,
      this.contactMobile,
      this.email,
      this.customerTitle,
      this.city,
      this.address1,
      this.address2,
      this.postalCode,
      this.remark,
      this.submitterUserId,
      this.submitterUserName,
      this.submittedDate,
      this.locationCode,
      this.routerNumber,
      this.managerId,
      this.createdTimeStamp,
      this.status,
      this.endReason,
      this.statusTimeStamp,
      this.salesId,
      this.accountNumber,
      this.dcrEnabled});

  LeadDetails.fromJson(Map<String, dynamic> json) {
    leadId = json['leadId'];
    leadOID = json['leadOID'];
    companyName = json['companyName'];
    firstName = json['firstName'];
    lastName = json['lastName'];
    contactPhone = json['contactPhone'];
    contactMobile = json['contactMobile'];
    email = json['email'];
    customerTitle = json['customerTitle'];
    city = json['city'];
    address1 = json['address1'];
    address2 = json['address2'];
    postalCode = json['postalCode'];
    remark = json['remark'];
    submitterUserId = json['submitterUserId'];
    submitterUserName = json['submitterUserName'];
    submittedDate = json['submittedDate'];
    locationCode = json['locationCode'];
    routerNumber = json['routerNumber'];
    managerId = json['managerId'];
    createdTimeStamp = json['createdTimeStamp'];
    status = json['status'];
    endReason = json['endReason'];
    statusTimeStamp = json['statusTimeStamp'];
    salesId = json['salesId'];
    accountNumber = json['accountNumber'];
    dcrEnabled = json['dcrEnabled'];
  }

  Map<String, dynamic> toJson() {
    // ignore: prefer_collection_literals
    final Map<String, dynamic> data = Map<String, dynamic>();
    // ignore: unnecessary_this
    data['leadId'] = this.leadId;
    // ignore: unnecessary_this
    data['leadOID'] = this.leadOID;
    // ignore: unnecessary_this
    data['companyName'] = this.companyName;
    // ignore: unnecessary_this
    data['firstName'] = this.firstName;
    // ignore: unnecessary_this
    data['lastName'] = this.lastName;
    // ignore: unnecessary_this
    data['contactPhone'] = this.contactPhone;
    // ignore: unnecessary_this
    data['contactMobile'] = this.contactMobile;
    // ignore: unnecessary_this
    data['email'] = this.email;
    // ignore: unnecessary_this
    data['customerTitle'] = this.customerTitle;
    // ignore: unnecessary_this
    data['city'] = this.city;
    // ignore: unnecessary_this
    data['address1'] = this.address1;
    // ignore: unnecessary_this
    data['address2'] = this.address2;
    // ignore: unnecessary_this
    data['postalCode'] = this.postalCode;
    // ignore: unnecessary_this
    data['remark'] = this.remark;
    // ignore: unnecessary_this
    data['submitterUserId'] = this.submitterUserId;
    // ignore: unnecessary_this
    data['submitterUserName'] = this.submitterUserName;
    // ignore: unnecessary_this
    data['submittedDate'] = this.submittedDate;
    // ignore: unnecessary_this
    data['locationCode'] = this.locationCode;
    // ignore: unnecessary_this
    data['routerNumber'] = this.routerNumber;
    // ignore: unnecessary_this
    data['managerId'] = this.managerId;
    // ignore: unnecessary_this
    data['createdTimeStamp'] = this.createdTimeStamp;
    // ignore: unnecessary_this
    data['status'] = this.status;
    // ignore: unnecessary_this
    data['endReason'] = this.endReason;
    // ignore: unnecessary_this
    data['statusTimeStamp'] = this.statusTimeStamp;
    // ignore: unnecessary_this
    data['salesId'] = this.salesId;
    // ignore: unnecessary_this
    data['accountNumber'] = this.accountNumber;
    // ignore: unnecessary_this
    data['dcrEnabled'] = this.dcrEnabled;
    return data;
  }
}

class LeadComments {
  int? leadNoteOID;
  String? comment;
  String? commentBy;
  String? commentDate;

  LeadComments(
      {this.leadNoteOID, this.comment, this.commentBy, this.commentDate});

  LeadComments.fromJson(Map<String, dynamic> json) {
    leadNoteOID = json['leadNoteOID'];
    comment = json['comment'];
    commentBy = json['commentBy'];
    commentDate = json['commentDate'];
  }

  Map<String, dynamic> toJson() {
    // ignore: prefer_collection_literals
    final Map<String, dynamic> data = Map<String, dynamic>();
    // ignore: unnecessary_this
    data['leadNoteOID'] = this.leadNoteOID;
    // ignore: unnecessary_this
    data['comment'] = this.comment;
    // ignore: unnecessary_this
    data['commentBy'] = this.commentBy;
    // ignore: unnecessary_this
    data['commentDate'] = this.commentDate;
    return data;
  }
}

class LeadAttachments {
  int? leadDocumentOID;
  String? docName;
  String? docType;
  String? docUrl;
  String? docSize;

  LeadAttachments(
      {this.leadDocumentOID,
      this.docName,
      this.docType,
      this.docUrl,
      this.docSize});

  LeadAttachments.fromJson(Map<String, dynamic> json) {
    leadDocumentOID = json['leadDocumentOID'];
    docName = json['docName'];
    docType = json['docType'];
    docUrl = json['docUrl'];
    docSize = json['docSize'];
  }

  Map<String, dynamic> toJson() {
    // ignore: prefer_collection_literals
    final Map<String, dynamic> data = Map<String, dynamic>();
    // ignore: unnecessary_this
    data['leadDocumentOID'] = this.leadDocumentOID;
    // ignore: unnecessary_this
    data['docName'] = this.docName;
    // ignore: unnecessary_this
    data['docType'] = this.docType;
    // ignore: unnecessary_this
    data['docUrl'] = this.docUrl;
    // ignore: unnecessary_this
    data['docSize'] = this.docSize;
    return data;
  }
}
