class AccountTimeFrame {
  ServiceStatus? serviceStatus;
  ResponseData? responseData;

  AccountTimeFrame({this.serviceStatus, this.responseData});

  AccountTimeFrame.fromJson(Map<String, dynamic> json) {
    serviceStatus = json['serviceStatus'] != null
        ? ServiceStatus.fromJson(json['serviceStatus'])
        : null;
    responseData = json['responseData'] != null
        ? ResponseData.fromJson(json['responseData'])
        : null;
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    if (serviceStatus != null) {
      data['serviceStatus'] = serviceStatus!.toJson();
    }
    if (responseData != null) {
      data['responseData'] = responseData!.toJson();
    }
    return data;
  }
}

class ServiceStatus {
  int? statusCode;
  bool? status;
  String? message;

  ServiceStatus({this.statusCode, this.status, this.message});

  ServiceStatus.fromJson(Map<String, dynamic> json) {
    statusCode = json['statusCode'];
    status = json['status'];
    message = json['message'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['statusCode'] = statusCode;
    data['status'] = status;
    data['message'] = message;
    return data;
  }
}

class ResponseData {
  Data? data;

  ResponseData({this.data});

  ResponseData.fromJson(Map<String, dynamic> json) {
    data = json['data'] != null ? Data.fromJson(json['data']) : null;
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    if (this.data != null) {
      data['data'] = this.data!.toJson();
    }
    return data;
  }
}

class Data {
  int? completion;
  int? accountsLeft;

  String? endDate;
  //String? currentDate;

  Data({
    this.completion,
    this.accountsLeft,
    this.endDate,
    // this.currentDate,
  });

  Data.fromJson(Map<String, dynamic> json) {
    completion = json['completion'] ?? 0;
    accountsLeft = json['accountsLeft'] ?? 0;
    endDate = json['endDate'] ?? "";
    // currentDate = json['currentDate'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['completion'] = completion;
    data['accountsLeft'] = accountsLeft;
    data['endDate'] = endDate;
    //data['currentDate'] = currentDate;

    return data;
  }
}
