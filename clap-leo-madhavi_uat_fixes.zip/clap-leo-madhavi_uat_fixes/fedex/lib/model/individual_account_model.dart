class IndividualAccountModel {
  ServiceStatus? serviceStatus;
  ResponseData? responseData;

  IndividualAccountModel({this.serviceStatus, this.responseData});

  IndividualAccountModel.fromJson(Map<String, dynamic> json) {
    serviceStatus = json['serviceStatus'] != null
        ? ServiceStatus.fromJson(json['serviceStatus'])
        : null;
    responseData = json['responseData'] != null
        ? ResponseData.fromJson(json['responseData'])
        : null;
  }

  Map<String, dynamic> toJson() {
    // ignore: unnecessary_thisxs, prefer_collection_literals
    final Map<String, dynamic> data = Map<String, dynamic>();
    // ignore: unnecessary_this
    if (this.serviceStatus != null) {
      // ignore: unnecessary_this
      data['serviceStatus'] = this.serviceStatus!.toJson();
    }
    // ignore: unnecessary_this
    if (this.responseData != null) {
      // ignore: unnecessary_this
      data['responseData'] = this.responseData!.toJson();
    }
    return data;
  }
}

class ServiceStatus {
  int? statusCode;
  bool? status;
  String? message;

  ServiceStatus({this.statusCode, this.status, this.message});

  ServiceStatus.fromJson(Map<String, dynamic> json) {
    statusCode = json['statusCode'];
    status = json['status'];
    message = json['message'];
  }

  Map<String, dynamic> toJson() {
    // ignore: prefer_collection_literals
    final Map<String, dynamic> data = Map<String, dynamic>();
    // ignore: unnecessary_this
    data['statusCode'] = this.statusCode;
    // ignore: unnecessary_this
    data['status'] = this.status;
    // ignore: unnecessary_this
    data['message'] = this.message;
    return data;
  }
}

class ResponseData {
  Data? data;

  ResponseData({this.data});

  ResponseData.fromJson(Map<String, dynamic> json) {
    data = json['data'] != null ? Data.fromJson(json['data']) : null;
  }

  Map<String, dynamic> toJson() {
    // ignore: prefer_collection_literals
    final Map<String, dynamic> data = Map<String, dynamic>();
    if (this.data != null) {
      data['data'] = this.data!.toJson();
    }
    return data;
  }
}

class Data {
  AccountDetails? accountDetails;
  List<AccountComments>? accountComments;

  Data({this.accountDetails, this.accountComments});

  Data.fromJson(Map<String, dynamic> json) {
    accountDetails = json['accountDetails'] != null
        ? AccountDetails.fromJson(json['accountDetails'])
        : null;
    if (json['accountComments'] != null) {
      accountComments = <AccountComments>[];
      json['accountComments'].forEach((v) {
        accountComments!.add(AccountComments.fromJson(v));
      });
    }
  }

  Map<String, dynamic> toJson() {
    // ignore: prefer_collection_literals
    final Map<String, dynamic> data = Map<String, dynamic>();
    // ignore: unnecessary_this
    if (this.accountDetails != null) {
      // ignore: unnecessary_this
      data['accountDetails'] = this.accountDetails!.toJson();
    }
    // ignore: unnecessary_this
    if (this.accountComments != null) {
      data['accountComments'] =
          // ignore: unnecessary_this
          this.accountComments!.map((v) => v.toJson()).toList();
    }
    return data;
  }
}

class AccountDetails {
  int? accountOID;
  Object? accountFileOID;
  Object? accountId;
  Object? accountNumber;
  String? companyName;
  String? firstName;
  String? lastName;
  String? contactPhone;
  Object? countryCode;
  String? postalCode;
  String? city;
  String? address1;
  String? address2;
  Object? entryReason;
  Object? locationCode;
  Object? routeNumber;
  Object? dispatchUID;
  Object? dispatchTimeStamp;
  Object? status;
  Object? stationId;
  Object? courierName;
  Object? courierId;
  Object? managerName;
  Object? managerUid;
  Object? seniorManagerName;
  Object? seniorManagerUid;
  Object? lmdName;
  Object? lmdId;
  Object? opsManagerName;
  Object? opsManagerId;
  Object? dispatchName;
  Object? dispatchId;
  Object? customerTitle;
  String? contactMobile;
  Object? isRepName;
  Object? isRepId;
  String? createdTimeStamp;
  Object? invalidStatus;
  String? lastFollowUpDate;

  AccountDetails(
      {this.accountOID,
      this.accountFileOID,
      this.accountId,
      this.accountNumber,
      this.companyName,
      this.firstName,
      this.lastName,
      this.contactPhone,
      this.countryCode,
      this.postalCode,
      this.city,
      this.address1,
      this.address2,
      this.entryReason,
      this.locationCode,
      this.routeNumber,
      this.dispatchUID,
      this.dispatchTimeStamp,
      this.status,
      this.stationId,
      this.courierName,
      this.courierId,
      this.managerName,
      this.managerUid,
      this.seniorManagerName,
      this.seniorManagerUid,
      this.lmdName,
      this.lmdId,
      this.opsManagerName,
      this.opsManagerId,
      this.dispatchName,
      this.dispatchId,
      this.customerTitle,
      this.contactMobile,
      this.isRepName,
      this.isRepId,
      this.createdTimeStamp,
      this.invalidStatus,
      this.lastFollowUpDate});

  AccountDetails.fromJson(Map<String, dynamic> json) {
    accountOID = json['accountOID'];
    accountFileOID = json['accountFileOID'];
    accountId = json['accountId'];
    accountNumber = json['accountNumber'];
    companyName = json['companyName'];
    firstName = json['firstName'];
    lastName = json['lastName'];
    contactPhone = json['contactPhone'];
    countryCode = json['countryCode'];
    postalCode = json['postalCode'];
    city = json['city'];
    address1 = json['address1'];
    address2 = json['address2'];
    entryReason = json['entryReason'];
    locationCode = json['locationCode'];
    routeNumber = json['routeNumber'];
    dispatchUID = json['dispatchUID'];
    dispatchTimeStamp = json['dispatchTimeStamp'];
    status = json['status'];
    stationId = json['stationId'];
    courierName = json['courierName'];
    courierId = json['courierId'];
    managerName = json['managerName'];
    managerUid = json['managerUid'];
    seniorManagerName = json['seniorManagerName'];
    seniorManagerUid = json['seniorManagerUid'];
    lmdName = json['lmdName'];
    lmdId = json['lmdId'];
    opsManagerName = json['opsManagerName'];
    opsManagerId = json['opsManagerId'];
    dispatchName = json['dispatchName'];
    dispatchId = json['dispatchId'];
    customerTitle = json['customerTitle'];
    contactMobile = json['contactMobile'];
    isRepName = json['isRepName'];
    isRepId = json['isRepId'];
    createdTimeStamp = json['createdTimeStamp'];
    invalidStatus = json['invalidStatus'];
    lastFollowUpDate = json['lastFollowUpDate'];
  }

  Map<String, dynamic> toJson() {
    // ignore: prefer_collection_literals
    final Map<String, dynamic> data = Map<String, dynamic>();
    // ignore: unnecessary_this
    data['accountOID'] = this.accountOID;
    // ignore: unnecessary_this
    data['accountFileOID'] = this.accountFileOID;
    // ignore: unnecessary_this
    data['accountId'] = this.accountId;
    // ignore: unnecessary_this
    data['accountNumber'] = this.accountNumber;
    // ignore: unnecessary_this
    data['companyName'] = this.companyName;
    // ignore: unnecessary_this
    data['firstName'] = this.firstName;
    // ignore: unnecessary_this
    data['lastName'] = this.lastName;
    // ignore: unnecessary_this
    data['contactPhone'] = this.contactPhone;
    // ignore: unnecessary_this
    data['countryCode'] = this.countryCode;
    // ignore: unnecessary_this
    data['postalCode'] = this.postalCode;
    // ignore: unnecessary_this
    data['city'] = this.city;
    // ignore: unnecessary_this
    data['address1'] = this.address1;
    // ignore: unnecessary_this
    data['address2'] = this.address2;
    // ignore: unnecessary_this
    data['entryReason'] = this.entryReason;
    // ignore: unnecessary_this
    data['locationCode'] = this.locationCode;
    // ignore: unnecessary_this
    data['routeNumber'] = this.routeNumber;
    // ignore: unnecessary_this
    data['dispatchUID'] = this.dispatchUID;
    // ignore: unnecessary_this
    data['dispatchTimeStamp'] = this.dispatchTimeStamp;
    // ignore: unnecessary_this
    data['status'] = this.status;
    // ignore: unnecessary_this
    data['stationId'] = this.stationId;
    // ignore: unnecessary_this
    data['courierName'] = this.courierName;
    // ignore: unnecessary_this
    data['courierId'] = this.courierId;
    // ignore: unnecessary_this
    data['managerName'] = this.managerName;
    // ignore: unnecessary_this
    data['managerUid'] = this.managerUid;
    // ignore: unnecessary_this
    data['seniorManagerName'] = this.seniorManagerName;
    // ignore: unnecessary_this
    data['seniorManagerUid'] = this.seniorManagerUid;
    // ignore: unnecessary_this
    data['lmdName'] = this.lmdName;
    // ignore: unnecessary_this
    data['lmdId'] = this.lmdId;
    // ignore: unnecessary_this
    data['opsManagerName'] = this.opsManagerName;
    // ignore: unnecessary_this
    data['opsManagerId'] = this.opsManagerId;
    // ignore: unnecessary_this
    data['dispatchName'] = this.dispatchName;
    // ignore: unnecessary_this
    data['dispatchId'] = this.dispatchId;
    // ignore: unnecessary_this
    data['customerTitle'] = this.customerTitle;
    // ignore: unnecessary_this
    data['contactMobile'] = this.contactMobile;
    // ignore: unnecessary_this
    data['isRepName'] = this.isRepName;
    // ignore: unnecessary_this
    data['isRepId'] = this.isRepId;
    // ignore: unnecessary_this
    data['createdTimeStamp'] = this.createdTimeStamp;
    // ignore: unnecessary_this
    data['invalidStatus'] = this.invalidStatus;
    // ignore: unnecessary_this
    data['lastFollowUpDate'] = this.lastFollowUpDate;
    return data;
  }
}

class AccountComments {
  int? accountNoteOID;
  String? comment;
  String? commentBy;
  String? commentDate;
  String? commentUserId;

  AccountComments(
      {this.accountNoteOID,
      this.comment,
      this.commentBy,
      this.commentDate,
      this.commentUserId});

  AccountComments.fromJson(Map<String, dynamic> json) {
    accountNoteOID = json['accountNoteOID'];
    comment = json['comment'];
    commentBy = json['commentBy'];
    commentDate = json['commentDate'];
    commentUserId = json['commentUserId'];
  }

  Map<String, dynamic> toJson() {
    // ignore: prefer_collection_literals
    final Map<String, dynamic> data = Map<String, dynamic>();
    // ignore: unnecessary_this
    data['accountNoteOID'] = this.accountNoteOID;
    // ignore: unnecessary_this
    data['comment'] = this.comment;
    // ignore: unnecessary_this
    data['commentBy'] = this.commentBy;
    // ignore: unnecessary_this
    data['commentDate'] = this.commentDate;
    // ignore: unnecessary_this
    data['commentUserId'] = this.commentUserId;
    return data;
  }
}
