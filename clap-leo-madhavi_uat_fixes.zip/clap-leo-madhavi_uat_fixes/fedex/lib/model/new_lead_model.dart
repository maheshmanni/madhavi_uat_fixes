class Lead {
  String? address1;
  String? address2;
  String? city;
  String? companyName;
  String? contactMobile;
  String? contactPhone;
  String? customerTitle;
  String? email;
  String? endReason;
  String? firstName;
  String? lastName;
  List<LeadDocuments>? leadDocuments;
  String? locationCode;
  String? managerId;
  String? postalCode;
  bool? readyForAccountOpening;
  String? remark;
  String? routerNumber;
  String? status;
  String? submitterUserId;
  String? submitterUserName;

  Lead(
      {this.address1,
      this.address2,
      this.city,
      this.companyName,
      this.contactMobile,
      this.contactPhone,
      this.customerTitle,
      this.email,
      this.endReason,
      this.firstName,
      this.lastName,
      this.leadDocuments,
      this.locationCode,
      this.managerId,
      this.postalCode,
      this.readyForAccountOpening,
      this.remark,
      this.routerNumber,
      this.status,
      this.submitterUserId,
      this.submitterUserName});

  Lead.fromJson(Map<String, dynamic> json) {
    address1 = json['address1'];
    address2 = json['address2'];
    city = json['city'];
    companyName = json['companyName'];
    contactMobile = json['contactMobile'];
    contactPhone = json['contactPhone'];
    customerTitle = json['customerTitle'];
    email = json['email'];
    endReason = json['endReason'];
    firstName = json['firstName'];
    lastName = json['lastName'];
    if (json['leadDocuments'] != null) {
      leadDocuments = <LeadDocuments>[];
      json['leadDocuments'].forEach((v) {
        leadDocuments!.add(LeadDocuments.fromJson(v));
      });
    }
    locationCode = json['locationCode'];
    managerId = json['managerId'];
    postalCode = json['postalCode'];
    readyForAccountOpening = json['readyForAccountOpening'];
    remark = json['remark'];
    routerNumber = json['routerNumber'];
    status = json['status'];
    submitterUserId = json['submitterUserId'];
    submitterUserName = json['submitterUserName'];
  }

  Map<String, dynamic> toJson() {
    // ignore: prefer_collection_literals
    final Map<String, dynamic> data = Map<String, dynamic>();
    // ignore: unnecessary_this
    data['address1'] = this.address1;
    // ignore: unnecessary_this
    data['address2'] = this.address2;
    // ignore: unnecessary_this
    data['city'] = this.city;
    // ignore: unnecessary_this
    data['companyName'] = this.companyName;
    // ignore: unnecessary_this
    data['contactMobile'] = this.contactMobile;
    // ignore: unnecessary_this
    data['contactPhone'] = this.contactPhone;
    // ignore: unnecessary_this
    data['customerTitle'] = this.customerTitle;
    // ignore: unnecessary_this
    data['email'] = this.email;
    // ignore: unnecessary_this
    data['endReason'] = this.endReason;
    // ignore: unnecessary_this
    data['firstName'] = this.firstName;
    // ignore: unnecessary_this
    data['lastName'] = this.lastName;
    // ignore: unnecessary_this
    if (this.leadDocuments != null) {
      data['leadDocuments'] =
          // ignore: unnecessary_this
          this.leadDocuments!.map((v) => v.toJson()).toList();
    }
    // ignore: unnecessary_this
    data['locationCode'] = this.locationCode;
    // ignore: unnecessary_this
    data['managerId'] = this.managerId;
    // ignore: unnecessary_this
    data['postalCode'] = this.postalCode;
    // ignore: unnecessary_this
    data['readyForAccountOpening'] = this.readyForAccountOpening;
    // ignore: unnecessary_this
    data['remark'] = this.remark;
    // ignore: unnecessary_this
    data['routerNumber'] = this.routerNumber;
    // ignore: unnecessary_this
    data['status'] = this.status;
    // ignore: unnecessary_this
    data['submitterUserId'] = this.submitterUserId;
    // ignore: unnecessary_this
    data['submitterUserName'] = this.submitterUserName;
    return data;
  }
}

class LeadDocuments {
  String? docKey;
  String? docName;
  String? docType;
  String? size;
  String? uploadUID;

  LeadDocuments(
      {this.docKey, this.docName, this.docType, this.size, this.uploadUID});

  LeadDocuments.fromJson(Map<String, dynamic> json) {
    docKey = json['docKey'];
    docName = json['docName'];
    docType = json['docType'];
    size = json['size'];
    uploadUID = json['uploadUID'];
  }

  Map<String, dynamic> toJson() {
    // ignore: prefer_collection_literals
    final Map<String, dynamic> data = Map<String, dynamic>();
    // ignore: unnecessary_this
    data['docKey'] = this.docKey;
    // ignore: unnecessary_this
    data['docName'] = this.docName;
    // ignore: unnecessary_this
    data['docType'] = this.docType;
    // ignore: unnecessary_this
    data['size'] = this.size;
    // ignore: unnecessary_this
    data['uploadUID'] = this.uploadUID;
    return data;
  }
}

class LeadResponseData {
  ServiceStatus? serviceStatus;
  ResponseData? responseData;

  LeadResponseData({required this.serviceStatus, required this.responseData});

  LeadResponseData.fromJson(Map<String, dynamic> json) {
    serviceStatus = json['serviceStatus'] != null
        ? ServiceStatus.fromJson(json['serviceStatus'])
        : null;
    responseData = json['responseData'] != null
        ? ResponseData.fromJson(json['responseData'])
        : null;
  }

  Map<String, dynamic> toJson() {
    // ignore: prefer_collection_literals
    final Map<String, dynamic> data = Map<String, dynamic>();
    // ignore: unnecessary_this
    if (this.serviceStatus != null) {
      // ignore: unnecessary_this
      data['serviceStatus'] = this.serviceStatus?.toJson();
    }
    // ignore: unnecessary_this
    if (this.responseData != null) {
      // ignore: unnecessary_this
      data['responseData'] = this.responseData?.toJson();
    }
    return data;
  }
}

class ServiceStatus {
  int? statusCode;
  bool? status;
  String? message;

  ServiceStatus({this.statusCode, this.status, this.message});

  ServiceStatus.fromJson(Map<String, dynamic> json) {
    statusCode = json['statusCode'];
    status = json['status'];
    message = json['message'];
  }

  Map<String, dynamic> toJson() {
    // ignore: prefer_collection_literals
    final Map<String, dynamic> data = Map<String, dynamic>();
    // ignore: unnecessary_this
    data['statusCode'] = this.statusCode;
    // ignore: unnecessary_this
    data['status'] = this.status;
    // ignore: unnecessary_this
    data['message'] = this.message;
    return data;
  }
}

class ResponseData {
  int? data;

  ResponseData({this.data});

  ResponseData.fromJson(Map<String, dynamic> json) {
    data = json['data'];
  }

  Map<String, dynamic> toJson() {
    // ignore: prefer_collection_literals
    final Map<String, dynamic> data = Map<String, dynamic>();
    data['data'] = this.data;
    return data;
  }
}
