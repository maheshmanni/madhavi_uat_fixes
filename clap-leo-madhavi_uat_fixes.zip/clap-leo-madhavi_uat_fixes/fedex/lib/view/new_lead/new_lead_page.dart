// ignore_for_file: implementation_imports, unused_field, prefer_is_empty, prefer_if_null_operators, non_constant_identifier_names, unused_local_variable

import 'package:auto_size_text/auto_size_text.dart';
import 'package:easy_localization/src/public_ext.dart';
import 'package:fedex_app/model/new_lead_model.dart';
import 'package:fedex_app/utility/apis/api_response.dart';
import 'package:fedex_app/utility/constant.dart';
import 'package:fedex_app/utility/services/base_service.dart';
import 'package:fedex_app/utility/styles.dart';
import 'package:fedex_app/utility/theme_colors.dart';
import 'package:fedex_app/view/widgets/custom_app_bar.dart';
import 'package:fedex_app/viewmodel/new_lead_viewmodel.dart';
import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:image_cropper/image_cropper.dart';
import 'package:provider/provider.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../widgets/rounded_text_formfield.dart';
import 'package:image_picker/image_picker.dart';
import 'dart:io';
import 'package:path/path.dart' as path;
// ignore: unused_import
import 'package:http/http.dart' as http;

class NewLeadPage extends StatefulWidget {
  static String routeName = '/NewLeadPage';
  const NewLeadPage({Key? key}) : super(key: key);

  @override
  _NewLeadPageState createState() => _NewLeadPageState();
}

class _NewLeadPageState extends State<NewLeadPage> {
  final _formKey = GlobalKey<FormState>();
  final GlobalKey<ScaffoldMessengerState> _scaffoldMessengerKey =
      GlobalKey<ScaffoldMessengerState>();

  final _companyNameController = TextEditingController();
  final _customerLastNameController = TextEditingController();
  final _customerFirstNameController = TextEditingController();
  final _customerTitleController = TextEditingController();
  final _contactPhoneController = TextEditingController();
  final _contactMobileController = TextEditingController();
  final _addressLineOneController = TextEditingController();
  final _addressLineTwoController = TextEditingController();
  final _cityController = TextEditingController();
  final _postalController = TextEditingController();
  final _emailController = TextEditingController();
  final _remarksController = TextEditingController();

  var _companyName = '';
  var _customerLastName = '';
  var _customerFirstName = '';
  // ignore: prefer_final_fields
  var _customerTitle = '';
  var _contactPhone = '';
  var _addressLineOne = '';
  var _addressLineTwo = '';
  var _city = '';
  var _postal = '';
  var _email = '';
  var _remarks = '';

  String? _radioValue; //Initial definition of radio button value
  String? choice;
  bool? isReadyForAccountOpening = false;
  bool? isTermsAndCondition = false;
  bool? isCheckedAttachement = false;
  String? _imageFilePath;
  String? _chosenValue;
  final List<UploadedFile> _imageFilePathList = [];
  bool isUploadedFiles = false;
  int count = 0;
  final bool _autovalidate = false;
  bool _isAttachementButtonDisabled = false;
  int businesAttachCount = 0,
      acOpenAttachCount = 0,
      businesCardAttachCount = 0,
      otherAttachCount = 0;
  bool _loading = false;
  List<String> tempList = [];
  String stationId = "";
  String employeeNum = "";
  String routeNo = "";
  String countryCode = "";
  int maxPostalCodeLength = 0;
  bool isHeaderError = false;
  bool? isPostalAwareMarket, isDcrEnabled;
  final newLeadViewModel = NewLeadViewModel();

  void radioButtonChanges(String? value) {
    setState(() {
      _radioValue = value;
      switch (value) {
        case 'YES':
          choice = value;
          break;
        case 'NO':
          choice = value;
          break;
        default:
          choice = null;
      }
      debugPrint(choice); //Debug the choice in console
    });
  }

  void checkboxnChanges(bool? value) {
    setState(() {
      isReadyForAccountOpening = value;
      debugPrint(choice); //Debug the choice in console
    });
  }

  @override
  void initState() {
    debugPrint("UploadImage");

    setState(() {
      updateAttachementfunctionality();
      count;
    });

    getCountryCode().then((value) {
      setState(() {
        if (value == 'CN') {
          countryCode = value;
          maxPostalCodeLength = 6;
        } else if (value == 'HK') {
          countryCode = value;
          maxPostalCodeLength = 7;
        } else if (value == 'JP') {
          countryCode = value;
          maxPostalCodeLength = 7;
        } else if (value == 'KR') {
          countryCode = value;
          maxPostalCodeLength = 5;
        } else if (value == 'TW') {
          countryCode = value;
          maxPostalCodeLength = 5;
        } else if (value == 'SG') {
          countryCode = value;
          maxPostalCodeLength = 6;
        } else if (value == 'PH') {
          countryCode = value;
          maxPostalCodeLength = 4;
        } else if (value == 'ID') {
          countryCode = value;
          maxPostalCodeLength = 5;
        } else if (value == 'TH') {
          countryCode = value;
          maxPostalCodeLength = 5;
        } else if (value == 'MY') {
          countryCode = value;
          maxPostalCodeLength = 5;
        } else if (value == 'VN') {
          countryCode = value;
          maxPostalCodeLength = 6;
        } else if (value == 'AU') {
          countryCode = value;
          maxPostalCodeLength = 4;
        } else if (value == 'NZ') {
          countryCode = value;
          maxPostalCodeLength = 4;
        } else {
          maxPostalCodeLength = 6;
        }

        //countryCode = value;
      });
    });

    getStationId().then((value) {
      setState(() {
        stationId = value;
      });
    });
    getEmpNumber().then((value) {
      setState(() {
        employeeNum = value;
      });
    });
    getRouteNumber().then((value) {
      setState(() {
        routeNo = value;
      });
    });
    getPostalAwareMarket().then((value) {
      setState(() {
        isPostalAwareMarket = value;
      });
    });
    getDcrEnabled().then((value) {
      setState(() {
        isDcrEnabled = value;
      });
    });
    super.initState();
  }

  Future<String> getStationId() async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.getString('stationId')!;
  }

  Future<String> getEmpNumber() async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.getString('employeeNumber')!;
  }

  Future<String> getRouteNumber() async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.getString('routeNumber')!;
  }

  Future<String> getCountryCode() async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.getString('countryCode')!;
  }

  Future<bool> getPostalAwareMarket() async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.getBool('postalAwareMarket')!;
  }

  Future<bool> getDcrEnabled() async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.getBool('dcrEnabled')!;
  }

  @override
  void didChangeDependencies() {
    updateAttachementfunctionality();
    super.didChangeDependencies();
  }

  @override
  void dispose() {
    _imageFilePathList.clear();
    _companyNameController.dispose();
    _customerLastNameController.dispose();
    _customerFirstNameController.dispose();
    _customerTitleController.dispose();
    _contactPhoneController.dispose();
    _contactMobileController.dispose();
    _addressLineOneController.dispose();
    _addressLineTwoController.dispose();
    _cityController.dispose();
    _postalController.dispose();
    _emailController.dispose();
    _remarksController.dispose();
    resetFileCounts();
    super.dispose();
  }

  void clearTextfield() {
    _companyNameController.clear();
    _customerLastNameController.clear();
    _customerFirstNameController.clear();
    _customerTitleController.clear();
    _contactPhoneController.clear();
    _contactMobileController.clear();
    _addressLineOneController.clear();
    _addressLineTwoController.clear();
    _cityController.clear();
    _postalController.clear();
    _emailController.clear();
    _remarksController.clear();
    //isReadyForAccountOpening = false;
  }

  void updateAttachementfunctionality() {
    setState(() {
      if (_imageFilePathList.length == 3) {
        _isAttachementButtonDisabled = true;
        isUploadedFiles = true;
        isCheckedAttachement = true;
      } else if (_imageFilePathList.length == 0) {
        _isAttachementButtonDisabled = false;
        isUploadedFiles = false;
        isCheckedAttachement = false;
      } else if (_imageFilePathList.length < 3 &&
          _imageFilePathList.length >= 1) {
        _isAttachementButtonDisabled = false;
        isUploadedFiles = true;
        isCheckedAttachement = true;
      } else {
        isUploadedFiles = false;
        isCheckedAttachement = false;
      }

      updatefileCounts();
    });
  }

  void resetFileCounts() {
    tempList.clear();
    businesAttachCount = 0;
    acOpenAttachCount = 0;
    businesCardAttachCount = 0;
    otherAttachCount = 0;
    isCheckedAttachement = false;
  }

  void updatefileCounts() {
    for (var item in _imageFilePathList) {
      var fileName = item.filePath.toString().split('/').last;

      if (item.fileType == Constant.businessRegistration) {
        if (!tempList.contains(fileName)) {
          tempList.add(fileName);
          setState(() => businesAttachCount++);
          debugPrint('busines $businesAttachCount Files');
        }
      } else if (item.fileType == Constant.acOpeningForm) {
        if (!tempList.contains(fileName)) {
          tempList.add(fileName);
          setState(() => acOpenAttachCount++);
          debugPrint('ac $acOpenAttachCount Files');
        }
      } else if (item.fileType == Constant.businessCard) {
        if (!tempList.contains(fileName)) {
          tempList.add(fileName);
          setState(() => businesCardAttachCount++);
          debugPrint('card $businesCardAttachCount Files');
        }
      } else if (item.fileType == Constant.other) {
        if (!tempList.contains(fileName)) {
          tempList.add(fileName);
          setState(() => otherAttachCount++);
          debugPrint('other $otherAttachCount Files');
        }
      }
    }
  }

  success(response) {
    getNewLeadResponse(response);
  }

  failure(response) {
    getNewLeadResponse(response);
  }

  void getNewLeadResponse(ApiResponse _apiResponse) {
    LeadResponseData? _newleadresponse = _apiResponse.data;
    switch (_apiResponse.status) {
      case Status.LOADING:
        _loading = true;
        Fluttertoast.showToast(
          msg: "Please wait...",
          gravity: ToastGravity.CENTER,
          toastLength: Toast.LENGTH_LONG,
        );
        newLeadViewModel.showLoadingDialog(
            context, 'Please wait...', Colors.transparent);
        return debugPrint('Loading ...');
      case Status.INITIAL:
        _loading = true;

        break;
      case Status.COMPLETED:
        {
          clearTextfield();
          _loading = false;

          final _message = _newleadresponse?.serviceStatus?.message;
          _newleadresponse?.serviceStatus?.status == true
              ? newLeadViewModel.showSucessfullyDialog(
                  context, _message.toString(), Colors.green)
              : newLeadViewModel.showSucessfullyDialog(
                  context, _message.toString(), Colors.red);

          return debugPrint(
              'Success... ${_newleadresponse?.responseData?.data}');
        }
      case Status.ERROR:
        _loading = false;
        String msg = 'Please try again latter!';
        if (_newleadresponse != null) {
          msg = _newleadresponse.serviceStatus!.message!;
        }
        Fluttertoast.showToast(
          msg: msg,
          gravity: ToastGravity.CENTER,
          toastLength: Toast.LENGTH_LONG,
        );
        return debugPrint('Error: Please try again latter!');
    }
  }

  Widget richText(String? name, String? name2) {
    return Container(
      margin: const EdgeInsets.only(
        left: 5,
        top: 5,
      ),
      child: RichText(
        text: TextSpan(
          style: const TextStyle(
            color: Colors.black,
          ),
          children: <TextSpan>[
            TextSpan(text: name.toString(), style: Styles.titleTextWithF12W700),
            TextSpan(
                text: name2.toString(),
                style: const TextStyle(color: Colors.red, fontSize: 15)),
          ],
        ),
      ),
    );
  }

  bool? isCountryCodeOptional(String countryCode) {
    if (countryCode == 'HK' || countryCode == 'VN') {
      return true;
    } else {
      return false;
    }
  }

  @override
  Widget build(BuildContext context) {
    return ScaffoldMessenger(
      key: _scaffoldMessengerKey,
      child: Scaffold(
        appBar: PreferredSize(
            preferredSize:
                const Size.fromHeight(Constant.kStandardAppBarHeight),
            child: CustomHomeAppbar(
              isCheckAppBarButtom: false,
              selectedContext: context,
              checkCurrentPage: 'NEW_LEAD',
            )),
        body: bodyViewWidget(),
      ),
    );
  }

  Container bodyViewWidget() {
    return Container(
      color: kBackgroundColor,
      margin: const EdgeInsets.all(15),
      child: SingleChildScrollView(
        child: Form(
          key: _formKey,
          child: Padding(
            padding: const EdgeInsets.symmetric(vertical: 0, horizontal: 0),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                const SizedBox(height: 15),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    // SvgPicture.asset('assets/icons/user_profile.svg'),
                    Text(
                      'newLead'.tr(),
                      textAlign: TextAlign.start,
                      style: Styles.titleTextWithF26,
                    ),
                    GestureDetector(
                      onTap: () => Navigator.of(context).pop(),
                      child: Row(
                        children: [
                          SvgPicture.asset(
                            Constant.assetsBackArrow,
                            height: 20,
                            width: 20,
                          ),
                          const SizedBox(width: 5),
                          Text(
                            'back'.tr(),
                            textAlign: TextAlign.start,
                            style: Styles.titleTextWithF26,
                          ),
                        ],
                      ),
                    )
                  ],
                ),
                const SizedBox(height: 10),
                //RegExp regExp =  RegExp("[a-zA-Z -]");
                Container(
                  alignment: Alignment.centerLeft,
                  color: xColorlightGrey,
                  child: Column(
                    children: [
                      richText('companyName'.tr(), '*'),
                      const SizedBox(height: 1),
                    ],
                  ),
                ),

                RoundedTextFormField(
                  controller: _companyNameController,
                  maxLines: 1,
                  maxLength: 85,
                  regExp: RegExp(Constant.patternChar),
                  textInputType: TextInputType.text,
                  hintText: 'companyName'.tr(),
                  prefixIcon: const Icon(Icons.home_work_outlined),
                  validator: (value) {
                    if (value.toString().length < 2) {
                      return 'pleaseProvideComanyName'.tr();
                    } else if (value.toString().length > 80) {
                      return "Max80CharactersAreAllowed".tr();
                    }

                    return null;
                  },
                  onSaved: (value) {
                    _companyName = value!;
                  },
                ),
                const SizedBox(height: 10),
                Container(
                  padding: const EdgeInsets.all(05.0),
                  decoration: BoxDecoration(
                    color: const Color(0xFFF2F2F2),
                    borderRadius: const BorderRadius.all(Radius.circular(0.0)),
                    border: Border.all(color: Colors.white),
                  ), //
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.stretch,
                    children: [
                      richText('customerTitle'.tr(), ''),
                      DropdownButton<String>(
                        alignment: AlignmentDirectional.centerStart,
                        isExpanded: true,
                        underline: const SizedBox(),
                        icon: const Visibility(
                          visible: true,
                          child: Icon(
                            Icons.arrow_drop_down_sharp,
                            color: xColor,
                          ),
                          replacement: SizedBox.shrink(),
                        ),
                        iconSize: 25.55,
                        value: _chosenValue == null ? null : _chosenValue,
                        style: Styles.titleTextWithF14W700,
                        items: newLeadViewModel.customerTitleList
                            .map<DropdownMenuItem<String>>(
                                (CustometTitle value) {
                          return DropdownMenuItem<String>(
                            value: value.id,
                            child: Container(
                              margin: const EdgeInsets.only(left: 2),
                              child: Text(value.name,
                                  style: Styles.contentTextWithF30W300),
                            ),
                          );
                        }).toList(),
                        hint: null,
                        onChanged: (value) {
                          setState(() {
                            _chosenValue = value!;
                          });
                        },
                      ),
                    ],
                  ),
                ),
                const SizedBox(height: 10),
                Container(
                  alignment: Alignment.centerLeft,
                  color: xColorlightGrey,
                  child: Column(
                    children: [
                      richText('customerFirstName'.tr(), '*'),
                      const SizedBox(height: 1),
                    ],
                  ),
                ),
                RoundedTextFormField(
                  controller: _customerFirstNameController,
                  maxLines: 1,
                  maxLength: 62,
                  regExp: RegExp(Constant.patternChar),
                  textInputType: TextInputType.name,
                  hintText: Constant.customerFirstName,
                  prefixIcon: const Icon(Icons.supervised_user_circle),
                  validator: (value) {
                    if (value.toString().length < 2) {
                      return 'pleaseProvideCustomerFirstName'.tr();
                    } else if (value.toString().length > 60) {
                      return "Max60CharactersAreAllowed".tr();
                    }
                    return null;
                  },
                  onSaved: (value) {
                    _customerFirstName = value!;
                  },
                ),
                const SizedBox(height: 10),
                Container(
                  alignment: Alignment.centerLeft,
                  color: xColorlightGrey,
                  child: Column(
                    children: [
                      richText('customerLastName'.tr(), '*'),
                      const SizedBox(height: 1),
                    ],
                  ),
                ),
                RoundedTextFormField(
                  controller: _customerLastNameController,
                  textInputType: TextInputType.name,
                  maxLines: 1,
                  maxLength: 62,
                  regExp: RegExp(Constant.patternChar),
                  hintText: Constant.customerLastName,
                  prefixIcon: const Icon(Icons.phone),
                  validator: (value) {
                    if (value.toString().length < 2) {
                      return 'pleaseProvideCustomerLastName'.tr();
                    } else if (value.toString().length > 60) {
                      return "Max60CharactersAreAllowed".tr();
                    }
                    return null;
                  },
                  onSaved: (value) {
                    _customerLastName = value!;
                  },
                ),
                const SizedBox(height: 5),
                richText('pleaseEnterValidphoneNumberORMobileNumber'.tr(), '*'),
                const SizedBox(height: 5),
                Container(
                  alignment: Alignment.centerLeft,
                  color: xColorlightGrey,
                  child: Column(
                    children: [
                      richText('telephoneNumber'.tr(), ' '),
                      const SizedBox(height: 1),
                    ],
                  ),
                ),
                RoundedTextFormField(
                  controller: _contactPhoneController,
                  textInputType: TextInputType.phone,
                  maxLines: 1,
                  maxLength: 15,
                  regExp: RegExp(Constant.pattternPhone),
                  hintText: Constant.telephoneNumber,
                  prefixIcon: const Icon(Icons.email_rounded),
                  validator: (value) {
                    if (_contactPhoneController.text.isNotEmpty) {
                      if (newLeadViewModel.validateMobile(value) != null) {
                        return 'pleaseProvideTeleNumber'.tr();
                      } else if (value.toString().length > 12) {
                        return "pleaseProvideValidPhoneNumber".tr();
                      }
                    } else {
                      return null;
                    }
                    return null;
                  },
                  onSaved: (value) {
                    _contactPhone = value!;
                  },
                ),
                const SizedBox(height: 10),
                Container(
                  alignment: Alignment.centerLeft,
                  color: xColorlightGrey,
                  child: Column(
                    children: [
                      richText('mobileNumber'.tr(), ''),
                      const SizedBox(height: 1),
                    ],
                  ),
                ),
                RoundedTextFormField(
                  controller: _contactMobileController,
                  maxLines: 1,
                  maxLength: 15,
                  regExp: RegExp(Constant.pattternPhone),
                  textInputType: TextInputType.phone,
                  hintText: Constant.mobileNumber,
                  prefixIcon: const Icon(Icons.email_rounded),
                  validator: (value) {
                    if (_contactMobileController.text.isNotEmpty) {
                      if (newLeadViewModel.validateMobile(value) != null) {
                        return 'pleaseProvideTeleNumber'.tr();
                      } else if (value.toString().length > 12) {
                        return "pleaseProvideValidPhoneNumber".tr();
                      }
                    } else {
                      return null;
                    }
                  },
                  onSaved: (value) {
                    _contactPhone = value!;
                  },
                ),
                const SizedBox(height: 10),
                Container(
                  alignment: Alignment.centerLeft,
                  color: xColorlightGrey,
                  child: Column(
                    children: [
                      richText('addressOne'.tr(), '*'),
                      const SizedBox(height: 1),
                    ],
                  ),
                ),
                RoundedTextFormField(
                  controller: _addressLineOneController,
                  textInputType: TextInputType.streetAddress,
                  maxLines: 1,
                  maxLength: 75,
                  regExp: RegExp(Constant.pattternEmail),
                  hintText: Constant.addressOne,
                  prefixIcon: const Icon(Icons.remember_me_outlined),
                  validator: (value) {
                    if (value.toString().length < 2) {
                      return 'pleaseProvideAddress'.tr();
                    } else if (value.toString().length > 70) {
                      return "Max70CharactersAreAllowed".tr();
                    }
                    return null;
                  },
                  onSaved: (value) {
                    _addressLineOne = value!;
                  },
                ),
                const SizedBox(height: 10),
                Container(
                  alignment: Alignment.centerLeft,
                  color: xColorlightGrey,
                  child: Column(
                    children: [
                      richText('addressTwo'.tr(), ''),
                      const SizedBox(height: 1),
                    ],
                  ),
                ),
                RoundedTextFormField(
                  controller: _addressLineTwoController,
                  textInputType: TextInputType.streetAddress,
                  maxLines: 1,
                  maxLength: 70,
                  regExp: RegExp(Constant.pattternEmail),
                  hintText: Constant.addressTwo,
                  prefixIcon: const Icon(Icons.remember_me_outlined),
                  validator: null,
                  // validator: (value) {
                  //   if (value.toString().length < 2) {
                  //     return Constant.pleaseProvideAddress;
                  //   }
                  //   return null;
                  // },
                  onSaved: (value) {
                    _addressLineTwo = value!;
                  },
                ),
                const SizedBox(height: 10),
                Container(
                  alignment: Alignment.centerLeft,
                  color: xColorlightGrey,
                  child: Column(
                    children: [
                      richText('city'.tr(), '*'),
                      const SizedBox(height: 1),
                    ],
                  ),
                ),
                RoundedTextFormField(
                  controller: _cityController,
                  textInputType: TextInputType.name,
                  maxLines: 1,
                  maxLength: 40,
                  hintText: Constant.city,
                  regExp: RegExp(Constant.patternChar),
                  prefixIcon: const Icon(Icons.remember_me_outlined),
                  validator: (value) {
                    if (value.toString().length < 2) {
                      return 'pleaseProvideCity'.tr();
                    } else if (value.toString().length > 35) {
                      return "Max35CharactersAreAllowed".tr();
                    }
                    return null;
                  },
                  onSaved: (value) {
                    _city = value!;
                  },
                ),
                const SizedBox(height: 10),
                Container(
                  alignment: Alignment.centerLeft,
                  color: xColorlightGrey,
                  child: Column(
                    children: [
                      richText('postal'.tr(),
                          isPostalAwareMarket == true ? '*' : ''),
                      const SizedBox(height: 1),
                    ],
                  ),
                ),
                //maxPostalCodeLength + 2
                RoundedTextFormField(
                  controller: _postalController,
                  textInputType: TextInputType.name,
                  maxLines: 1,
                  maxLength: maxPostalCodeLength + 2,
                  regExp: RegExp(Constant.pattternPhone),
                  hintText: isPostalAwareMarket == true
                      ? Constant.postal
                      : Constant.postalOptional,
                  prefixIcon: const Icon(Icons.remember_me_outlined),
                  validator: isCountryCodeOptional(countryCode) == true
                      ? null
                      : (value) {
                          if (value.toString().length < 2) {
                            return 'pleaseProvidePostal'.tr();
                          } else if (value.toString().length >
                              maxPostalCodeLength) {
                            return "Max $maxPostalCodeLength Characters Are Allowed";
                          }
                          return null;
                        },
                  onSaved: (value) {
                    _postal = value!;
                  },
                ),
                const SizedBox(height: 10),
                Container(
                  alignment: Alignment.centerLeft,
                  color: xColorlightGrey,
                  child: Column(
                    children: [
                      richText('email'.tr(), '*'),
                      const SizedBox(height: 1),
                    ],
                  ),
                ),
                RoundedTextFormField(
                  controller: _emailController,
                  textInputType: TextInputType.emailAddress,
                  maxLines: 1,
                  maxLength: 60,
                  regExp: RegExp(Constant.pattternEmail),
                  hintText: Constant.email,
                  prefixIcon: const Icon(Icons.remember_me_outlined),
                  validator: (value) {
                    if (newLeadViewModel.validateEmail(value) != null) {
                      return 'pleaseProvideEmail'.tr();
                    }
                    return null;
                  },
                  onSaved: (value) {
                    _email = value!;
                  },
                ),
                const SizedBox(height: 10),
                Container(
                  alignment: Alignment.centerLeft,
                  color: xColorlightGrey,
                  child: Column(
                    children: [
                      richText('remarks'.tr(), ''),
                      const SizedBox(height: 1),
                    ],
                  ),
                ),
                RoundedTextFormField(
                  controller: _remarksController,
                  textInputType: TextInputType.text,
                  maxLines: 3,
                  maxLength: 500,
                  regExp: RegExp(Constant.patternChar),
                  hintText: Constant.remarks,
                  prefixIcon: const Icon(Icons.remember_me_outlined),
                  validator: null,
                  // validator: (value) {
                  //   if (value.toString().length < 2) {
                  //     return Constant.pleaseProvideRemarks;
                  //   }
                  //   return null;
                  // },
                  onSaved: (value) {
                    _remarks = value!;
                  },
                ),

                const SizedBox(height: 25),

                Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const SizedBox(width: 5),
                    Text(
                      'attachements'.tr(),
                      style: Styles.titleTextWithF14W700,
                    ),
                    Column(
                      crossAxisAlignment: CrossAxisAlignment.stretch,
                      mainAxisAlignment: MainAxisAlignment.end,
                      children: [
                        Text(
                          'fileUploaded'.tr(),
                          style: Styles.titleTextWithF14W700,
                          textAlign: TextAlign.end,
                        ),
                        const SizedBox(height: 10),
                        Text(
                          'lemitedTo3FilesForEachLead'.tr(),
                          style: Styles.titleTextWithF10W400,
                          textAlign: TextAlign.end,
                        ),
                      ],
                    ),
                  ],
                ),
                const SizedBox(height: 20),
                _attachementWidget(
                  click: (value) {
                    debugPrint('$value');
                    _attachementAleartDialog(context, 'business_registration',
                        'businessRegistration'.tr());
                  },
                  name: 'businessRegistration'.tr(),
                  valueItem: 0,
                  fileCount: businesAttachCount,
                ),
                _attachementWidget(
                  click: (value) {
                    // ignore: todo
                    //TODO: A/C Opening Form
                    debugPrint('$value');
                    _attachementAleartDialog(
                        context, 'ac_opening', 'acOpeningForm'.tr());
                  },
                  name: 'acOpeningForm'.tr(),
                  valueItem: 1,
                  fileCount: acOpenAttachCount,
                ),
                _attachementWidget(
                  click: (value) {
                    // ignore: todo
                    //TODO: Business Card
                    debugPrint('$value');
                    _attachementAleartDialog(
                        context, 'business_card', 'businessCard'.tr());
                  },
                  name: 'businessCard'.tr(),
                  valueItem: 2,
                  fileCount: businesCardAttachCount,
                ),
                _attachementWidget(
                  click: (value) {
                    // ignore: todo
                    //TODO: Other
                    debugPrint('$value');
                    _attachementAleartDialog(context, 'other', 'other'.tr());
                  },
                  name: 'other'.tr(),
                  valueItem: 3,
                  fileCount: otherAttachCount,
                ),
                const SizedBox(height: 10),
                //Uploaded Files for dynamically
                Visibility(
                  visible: isUploadedFiles,
                  child: Container(
                    color: xColorlightGrey,
                    padding: const EdgeInsets.all(2.0),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          'uploadedFiles'.tr(),
                          style: Styles.titleTextWithF14W700,
                        ),
                        const SizedBox(height: 10),
                        GridView.builder(
                          padding: const EdgeInsets.all(2.0),
                          shrinkWrap: true,
                          gridDelegate:
                              const SliverGridDelegateWithFixedCrossAxisCount(
                            crossAxisCount: 2,
                            crossAxisSpacing: 0.1,
                            mainAxisSpacing: 0.1,
                            childAspectRatio: (2 / 1),
                            mainAxisExtent: 50,
                          ),
                          // ignore: unnecessary_null_comparison
                          itemCount: _imageFilePathList == null
                              ? 0
                              : _imageFilePathList.length,
                          itemBuilder: (context, int index) {
                            return Column(
                              mainAxisAlignment: MainAxisAlignment.start,
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Row(
                                  mainAxisAlignment: MainAxisAlignment.start,
                                  children: [
                                    Text(
                                      _imageFilePathList[index]
                                          .fileType
                                          .toString(),
                                      style: Styles.titleTextWithF10W400,
                                    ),
                                    const SizedBox(width: 5.0),
                                    GestureDetector(
                                      onTap: () {
                                        setState(() {
                                          String strDocKey =
                                              newLeadViewModel.getDocKey(
                                                  _imageFilePathList[index]
                                                      .fileName
                                                      .toString());

                                          Provider.of<NewLeadViewModel>(context,
                                                  listen: false)
                                              .deleteFile(strDocKey);
                                          _imageFilePathList.removeAt(index);
                                          newLeadViewModel
                                              .removeFileListItem(index);
                                          resetFileCounts();
                                          updateAttachementfunctionality();
                                        });
                                      },
                                      child: const Icon(
                                          Icons.highlight_remove_sharp,
                                          size: 15),
                                    ),
                                  ],
                                ),
                                Text(
                                  _imageFilePathList[index]
                                      .filePath
                                      .toString()
                                      .split('/')
                                      .last,
                                  style: Styles.texUnderLinetWithF10W400,
                                ),
                                Text(
                                  _imageFilePathList[index].size.toString() +
                                      "KB",
                                  style: Styles.timeWithF10W400,
                                ),
                              ],
                            );
                          },
                        ),
                      ],
                    ),
                  ),
                ),

                const SizedBox(height: 10),

                Visibility(
                  visible: isDcrEnabled == true ? true : false,
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.start,
                    children: [
                      Checkbox(
                        value: isReadyForAccountOpening,
                        checkColor: Colors.white,
                        activeColor: Colors.redAccent,
                        onChanged: (value) {
                          setState(() {
                            checkboxnChanges(value);
                          });
                        },
                      ),
                      Text(
                        'readyForAccountsOpening'.tr(),
                        style: Styles.titleTextWithF15W400,
                      ),
                    ],
                  ),
                ),
                Visibility(
                  visible: true,
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.start,
                    children: [
                      Checkbox(
                        value: isTermsAndCondition,
                        checkColor: Colors.white,
                        activeColor: Colors.redAccent,
                        onChanged: (value) {
                          setState(() {
                            isTermsAndCondition = value;
                          });
                        },
                      ),
                      // I agree to the terms and conditions
                      GestureDetector(
                        onTap: () {},
                        child: Expanded(
                          child: AutoSizeText(
                            'tearms_Condition'.tr(),
                            maxLines: 10,
                            minFontSize: 10,
                            textAlign: TextAlign.center,
                            overflow: TextOverflow.ellipsis,
                            style: Styles.editTextBlueWithF14W700,
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
                const SizedBox(height: 10),
                Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    FittedBox(
                      child: SizedBox(
                        width: 150,
                        height: 30,
                        child: ElevatedButton(
                          style: ButtonStyle(
                            padding: MaterialStateProperty.all<EdgeInsets>(
                                const EdgeInsets.all(10)),
                            foregroundColor:
                                MaterialStateProperty.all<Color>(Colors.white),
                            backgroundColor:
                                MaterialStateProperty.all<Color>(Colors.white),
                            shape: MaterialStateProperty.all<
                                RoundedRectangleBorder>(
                              RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(2.0),
                                side: const BorderSide(color: xColor, width: 1),
                              ),
                            ),
                          ),
                          child: Text(
                            'cancel'.tr(),
                            style: const TextStyle(
                              color: xColor,
                              fontSize: 10,
                              fontWeight: FontWeight.w700,
                            ),
                          ),
                          onPressed: () => Navigator.of(context).pop(),
                        ),
                      ),
                    ),
                    const SizedBox(width: 5),
                    FittedBox(
                      child: SizedBox(
                        width: 150,
                        height: 30,
                        child: ElevatedButton(
                          style: ButtonStyle(
                            foregroundColor:
                                MaterialStateProperty.all<Color>(Colors.white),
                            backgroundColor:
                                MaterialStateProperty.all<Color>(xColor),
                            shape: MaterialStateProperty.all<
                                RoundedRectangleBorder>(
                              RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(2.0),
                                side: const BorderSide(color: xColor, width: 1),
                              ),
                            ),
                          ),
                          child: Text(
                            'submit'.tr(),
                            style: const TextStyle(
                              fontSize: 10,
                              color: kBackgroundColor,
                              fontWeight: FontWeight.w700,
                            ),
                          ),
                          onPressed: () {
                            final isValid = _formKey.currentState!.validate();
                            if (isValid) {
                              if (_contactMobileController.text.isNotEmpty ||
                                  _contactPhoneController.text.isNotEmpty) {
                                isTermsAndCondition == true
                                    ? _showMyDialog(context)
                                    : showSnackBar(context,
                                        "Please accept termes and conditions");
                              } else {
                                showSnackBar(
                                    context,
                                    "pleaseEnterValidphoneNumberORMobileNumber"
                                        .tr());
                              }
                            }
                          },
                        ),
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  void showSnackBar(BuildContext context, String text) {
    _scaffoldMessengerKey.currentState!.showSnackBar(
      SnackBar(
        behavior: SnackBarBehavior.floating,
        backgroundColor: Colors.red,
        content: Text(text, style: Styles.titleWhiteTextWithF12W700),
      ),
    );
  }

  Future<void> _showMyDialog(BuildContext ctx) async {
    return showDialog<void>(
      context: ctx,
      barrierDismissible: false, // user must tap button!
      builder: (BuildContext context) {
        return AlertDialog(
          title: Text('NewLeadSubmission'.tr(),
              style: Styles.titleTextWithF20W700),
          content: SingleChildScrollView(
            child: ListBody(
              children: <Widget>[
                const Text(''),
                Text('are_you_sure_you_want_submit_lead'.tr(),
                    style: Styles.titleTextWithF20W700),
              ],
            ),
          ),
          actions: <Widget>[
            ElevatedButton(
              style: ElevatedButton.styleFrom(primary: xColor),
              onPressed: () => Navigator.pop(context, Constant.cancel),
              child: Text(
                'cancel'.tr(),
                style: const TextStyle(
                  fontSize: 12,
                  color: kBackgroundColor,
                  fontWeight: FontWeight.w700,
                ),
              ),
            ),
            ElevatedButton(
              style: ElevatedButton.styleFrom(primary: xColor),
              onPressed: () {
                leadSubmit();
              },
              child: Text(
                'submit'.tr(),
                style: const TextStyle(
                  fontSize: 12,
                  color: kBackgroundColor,
                  fontWeight: FontWeight.w700,
                ),
              ),
            ),
          ],
        );
      },
    );
  }

  _attachementWidget(
      {required Function(int) click,
      required String name,
      required int valueItem,
      required int fileCount}) {
    return Column(children: [
      Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text(
            name,
            style: Styles.titleTextWithF14W700,
          ),
          IconButton(
              disabledColor: _isAttachementButtonDisabled
                  ? xColorNormalGrey
                  : xColorNormalGrey,
              onPressed:
                  _isAttachementButtonDisabled ? null : () => click(valueItem),
              icon: const Icon(Icons.camera_alt_outlined),
              color: xColor),
        ],
      ),
      Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Divider(
            height: 0,
            thickness: 2,
            color: fileCount == 0 ? xColorNormalGrey : xColor,
          ),
          const SizedBox(height: 5),
          Text(fileCount == 0 ? '' : 'Uploaded $fileCount Files',
              style: Styles.titleTextWithF10W400),
        ],
      ),
    ]);
  }

  _attachementAleartDialog(
      BuildContext ctx, String selectedFileName, String headerName) {
    return showDialog(
      context: ctx,
      builder: (context) => AlertDialog(
        title: Text(
          'please_chose_image'.tr(),
          style: const TextStyle(fontFamily: 'Roboto'),
        ),
        content: Text('get_image_from_camera'.tr()),
        elevation: 10,
        actions: [
          TextButton(
            onPressed: () {
              Navigator.pop(context, true);
              onImageButttonPressed(
                ImageSource.camera,
                context: ctx,
                name: selectedFileName,
                header: headerName,
                capturedImageFile: (str) async {
                  setState(() {
                    _imageFilePath = str;
                    isUploadedFiles = true;
                    if (_imageFilePathList.length == 3) {
                      _isAttachementButtonDisabled = true;
                      updateAttachementfunctionality();
                    }
                    updateAttachementfunctionality();
                  });
                  await newLeadViewModel.uploadImageFile(str, headerName);
                },
              );
            },
            child: Text(
              'camera'.tr(),
              style:
                  const TextStyle(color: Colors.black, fontFamily: 'Poppins'),
            ),
          ),
          TextButton(
            onPressed: () {
              Navigator.pop(context, true);
              //newLeadViewModel.uploadImage();
            },
            child: Text(
              'cancel'.tr(),
              style:
                  const TextStyle(color: Colors.black, fontFamily: 'Poppins'),
            ),
          ),
        ],
      ),
    );
  }

  leadSubmit() {
    final isValid = _formKey.currentState!.validate();
    Fluttertoast.showToast(
      msg: "Please wait...",
      gravity: ToastGravity.CENTER,
      toastLength: Toast.LENGTH_LONG,
    );
    if (isValid) {
      //Add integration API
      var newlead = Lead(
        address1: _addressLineOneController.text.toString().trimLeft(),
        address2: _addressLineTwoController.text.toString().trimLeft(),
        city: _cityController.text,
        companyName: _companyNameController.text.toString().trim(),
        contactMobile: _contactMobileController.text.toString().trimLeft(),
        contactPhone: _contactPhoneController.text.toString().trimLeft(),
        customerTitle: _chosenValue,
        email: _emailController.text,
        endReason: "",
        firstName: _customerFirstNameController.text.toString().trim(),
        lastName: _customerLastNameController.text.toString().trim(),
        leadDocuments: newLeadViewModel.leadUploaddoclist,
        locationCode: stationId,
        managerId: "",
        postalCode: _postalController.text,
        readyForAccountOpening: isReadyForAccountOpening,
        remark: _remarksController.text,
        routerNumber: routeNo,
        status: isReadyForAccountOpening == true ? '6' : '1',
        // submitterUserId: '',
        // submitterUserName: "",
      );
      //- employeeNum // 4391667 // Ashish Patil (OSV)
      debugPrint("Request-Data: ${newlead.companyName} ");
      debugPrint("Request-Data: ${newlead.address1} ");
      debugPrint("Request-Data: ${newlead.postalCode} ");
      debugPrint("Request-Data: ${newlead.email} ");
      debugPrint("Request-Data: ${newlead.locationCode} ");
      debugPrint("Request-Data: ${newlead.routerNumber} ");
      debugPrint(
          "Request-FileUploaded: ${newLeadViewModel.leadUploaddoclist!.length} ");

      Provider.of<NewLeadViewModel>(context, listen: false).postLeadGenerate(
          newlead, BaseService.lead,
          successCallback: success, failureCallback: failure);

      setState(() {
        _loading = true;
      });

      Navigator.pop(context, Constant.ok);
      return;
    } else {
      _formKey.currentState!.save();
      Navigator.pop(context, Constant.ok);
      debugPrint('integration API call');
    }
  }

  showLoadingIndicator([String? text]) {
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (BuildContext context) {
        return WillPopScope(
            onWillPop: () async => false,
            child: AlertDialog(
              shape: const RoundedRectangleBorder(
                  borderRadius: BorderRadius.all(Radius.circular(8.0))),
              backgroundColor: Colors.black87,
              content: LoadingIndicator(text: text),
            ));
      },
    );
  }

  LoadingIndicator({String? text}) {}

  onImageButttonPressed(ImageSource source,
      {required BuildContext context,
      capturedImageFile,
      required String name,
      required String header}) async {
    final ImagePicker _picker = ImagePicker();
    File file;
    count++;
    final pickedFile = await _picker.pickImage(
      source: source,
    );
    //print('pickedFile: ${pickedFile!.path}');

    file = (await ImageCropper.cropImage(
      sourcePath: pickedFile!.path,
      aspectRatio: const CropAspectRatio(ratioX: 1, ratioY: 1),
      compressQuality: 100,
      maxHeight: 700,
      maxWidth: 700,
      compressFormat: ImageCompressFormat.jpg,
      androidUiSettings: const AndroidUiSettings(
        toolbarColor: Colors.white,
        toolbarTitle: "Image",
      ),
    )) as File;

    String fileName = file.path.split('/').last;

    // Save and Rename file to App directory
    String dir = path.dirname(file.path);

    var strCount = "_0" + count.toString();
    String newPath = path.join(dir, name + strCount + '.jpg');
    debugPrint('NewPath: $newPath');
    debugPrint('FileName: ${newPath.toString().split('/').last}');
    File xFile = file.renameSync(newPath);
    final bytes = xFile.readAsBytesSync().lengthInBytes;
    final sizeKb = (bytes / 1024);
    int fileSize = int.parse(sizeKb.toString().split('.')[0]);

    _imageFilePathList.add(UploadedFile(
      filePath: xFile,
      fileName: newPath.toString().split('/').last,
      fileType: header,
      size: fileSize,
    ));

    debugPrint('Image_path_count: ${_imageFilePathList.length}');
    setState(() {});

    capturedImageFile(xFile.path);
  }
}

class UploadedFile {
  String? fileType;
  String? fileName;
  File? filePath;
  int? size;

  UploadedFile({
    this.fileType,
    this.fileName,
    this.filePath,
    this.size,
  });
}
