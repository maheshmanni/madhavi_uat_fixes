// ignore_for_file: implementation_imports, unused_field, prefer_typing_uninitialized_variables

import 'package:easy_localization/src/public_ext.dart';
import 'package:fedex_app/model/kpi_date_status.dart';
import 'package:fedex_app/model/kpi_report_newlead.dart';
import 'package:fedex_app/model/kpi_reports_accounts.dart';
import 'package:fedex_app/utility/apis/api_response.dart';
import 'package:fedex_app/utility/constant.dart';
import 'package:fedex_app/utility/styles.dart';
import 'package:fedex_app/utility/theme_colors.dart';
import 'package:fedex_app/view/widgets/count_down_timer.dart';
import 'package:fedex_app/view/widgets/custom_app_bar.dart';
import 'package:fedex_app/viewmodel/kpi_reports_viewmodel.dart';
import 'package:flutter/material.dart';
import 'package:flutter_svg/svg.dart';
import 'package:shared_preferences/shared_preferences.dart';

class MyPerformance extends StatefulWidget {
  //
  static String routeName = '/MyPerformance';
  const MyPerformance({Key? key}) : super(key: key);

  @override
  _MyPerformanceState createState() => _MyPerformanceState();
}

class _MyPerformanceState extends State<MyPerformance>
    with TickerProviderStateMixin {
  //
  final kpiReportsViewModel = KPIReportsViewModel();
  final ScrollController _scrollController = ScrollController();
  final GlobalKey<ScaffoldMessengerState> _scaffoldMessengerKey =
      GlobalKey<ScaffoldMessengerState>();
  TabController? tabController;
  int? tabID;
  String? _statusFilterValue = '';
  //String? salesLeadGenrated;
  List<String>? monthlist = [];
  AnimationController? _controller;
  bool isSelected = false;
  @override
  void initState() {
    tabController = TabController(length: 2, vsync: this);
    //_statusFilterValue = 'February 2022';
    _controller =
        AnimationController(vsync: this, duration: const Duration(seconds: 0));
    super.initState();
  }

  @override
  void dispose() {
    tabController!.dispose();
    _scrollController.dispose();
    _controller?.dispose();
    super.dispose();
  }

  failureNewLeadMonths(response) {
    getKpiNewLeadMonths(response);
  }

  successNewLeadMonths(response) {
    getKpiNewLeadMonths(response);
  }

  getEmpNumber() async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.getString('employeeNumber')!;
  }

  void getKpiNewLeadMonths(ApiResponse _apiResponse) {
    KpiDateStatusResponse? newLeadMonths = _apiResponse.data;
    switch (_apiResponse.status) {
      case Status.LOADING:
        return debugPrint('Loading ...');
      case Status.INITIAL:
        break;
      case Status.COMPLETED:
        {
          // ignore: unused_local_variable
          String userId = "";
          //monthlist = [];
          getEmpNumber().then((value) {
            userId = value;
          });
          if (tabID == 0) {
            debugPrint('KPI REPORTS NEW LEAD  COMPLETED...');
            if (newLeadMonths?.serviceStatus?.status == true) {
              monthlist = newLeadMonths!.responseData!.data!.months;
              if (isSelected) {
                _statusFilterValue = _statusFilterValue;
              } else {
                _statusFilterValue = monthlist![0].toString();
              }
              kpiReportsViewModel.readNewLeadData(
                _statusFilterValue!,
              );
            }
          } else {
            debugPrint('KPI REPORTS ACCOUNTS  COMPLETED...');
            if (newLeadMonths?.serviceStatus?.status == true) {
              //monthlist = [];
              monthlist = newLeadMonths!.responseData!.data!.months;
              if (isSelected) {
                _statusFilterValue = _statusFilterValue;
              } else {
                _statusFilterValue = monthlist![0].toString();
              }

              kpiReportsViewModel.fetchKPIReportsAccountsData(
                _statusFilterValue!,
              );
            }
          }
          return debugPrint(
              'Success... ${newLeadMonths?.serviceStatus?.statusCode}');
        }
      case Status.ERROR:
        // ignore: unused_local_variable
        String msg = 'Please try again latter!';
        if (newLeadMonths != null) {
          msg = newLeadMonths.serviceStatus!.message!;
        }
        return debugPrint('Error: Please try again latter!');
    }
  }

  @override
  Widget build(BuildContext context) {
    if (tabID == null) {
      final Map<String, Object?> arg =
          ModalRoute.of(context)!.settings.arguments as Map<String, Object?>;
      tabID = arg['tabID'] as int?;
      debugPrint('Selected_Buttom: $tabID');
      tabController =
          TabController(length: 2, vsync: this, initialIndex: tabID!);
    }
    if (tabID == 0) {
      debugPrint('tabID: $tabID');
      kpiReportsViewModel.fetchKpiNewleadMonths(
          successCallback: successNewLeadMonths,
          failureCallback: failureNewLeadMonths);
    } else if (tabID == 1) {
      debugPrint('tabID: $tabID');
      kpiReportsViewModel.fetchKpiAccountsMonths(
          successCallback: failureNewLeadMonths,
          failureCallback: successNewLeadMonths);
    }

    return Scaffold(
      resizeToAvoidBottomInset: false,
      appBar: PreferredSize(
          preferredSize: const Size.fromHeight(Constant.kStandardAppBarHeight),
          child: CustomHomeAppbar(
            isCheckAppBarButtom: false,
            selectedContext: context,
            rightMenuSelectedIndex: 0,
          )),
      body: tabID == 0
          ? kpiNewLeadMonthResponse()
          : kpiNewLeadAccountsMonthsResponse(),
    );
  }

  kpiNewLeadMonthResponse() {
    return StreamBuilder(
        stream: kpiReportsViewModel.kpiReportsMonthResponse,
        builder: (context, AsyncSnapshot<KpiDateStatusResponse> snapshot) {
          if (snapshot.hasData) {
            final response = snapshot.data;
            if (response?.serviceStatus?.statusCode == 200) {
              return defaultUI(response);
            } else {
              return Center(child: Text(response!.serviceStatus!.message!));
            }
          } else if (snapshot.hasError) {
            return Center(child: Text(snapshot.error.toString()));
          }
          return const Center(
            child: CircularProgressIndicator(),
          );
        });
  }

  kpiNewLeadAccountsMonthsResponse() {
    return StreamBuilder(
        stream: kpiReportsViewModel.kpiReportsMonthResponse,
        builder: (context, AsyncSnapshot<KpiDateStatusResponse> snapshot) {
          if (snapshot.hasData) {
            final response = snapshot.data;
            if (response?.serviceStatus?.statusCode == 200) {
              return defaultUI(response);
            } else {
              return Center(child: Text(response!.serviceStatus!.message!));
            }
          } else if (snapshot.hasError) {
            return Center(child: Text(snapshot.error.toString()));
          }
          return const Center(
            child: CircularProgressIndicator(),
          );
        });
  }

  defaultUI(KpiDateStatusResponse? kpiNewLeadResponse) {
    return Container(
        constraints: const BoxConstraints.expand(),
        decoration: const BoxDecoration(
          image: DecorationImage(
              image: AssetImage(Constant.landingBgIcon), fit: BoxFit.fill),
          //color: Colors.amber,
        ),
        child: Container(
          padding: const EdgeInsets.all(10.0),
          constraints: const BoxConstraints.expand(),
          decoration: const BoxDecoration(
            gradient: LinearGradient(
                begin: FractionalOffset.topCenter,
                end: FractionalOffset.bottomCenter,
                colors: [Color(0xFF000000), Colors.transparent]),
          ),
          child: ListView(
            children: [
              Text(
                'My Performance',
                style: Styles.titleTextWithF18W700,
              ),
              filterStatusDateWidget(kpiNewLeadResponse),
              tabBarWidget(),
              tabID == 0
                  ? kpiNewLeadDataResponse()
                  : kpiReportsAccountResponse()
            ],
          ),
        ));
  }

  Widget filterStatusDateWidget(KpiDateStatusResponse? kpiNewLeadResponse) {
    final monthlist = kpiNewLeadResponse!.responseData!.data!.months!;
    return Container(
      margin: const EdgeInsets.only(left: 30, right: 30),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            'date'.tr(),
            style: Styles.titleWhiteTextWithF12W700,
          ),
          const SizedBox(
            height: 2,
          ),
          Container(
            height: 30.0,
            margin: const EdgeInsets.all(0.0),
            padding: const EdgeInsets.all(5.0),
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: const BorderRadius.all(Radius.circular(0.0)),
              border: Border.all(color: Colors.white),
            ), //
            child: DropdownButton<String>(
              alignment: AlignmentDirectional.centerStart,
              isExpanded: true,
              underline: const SizedBox(),
              icon: Visibility(
                visible: true,
                child: Image.asset(
                  Constant.dropDownGreyIcon,
                  fit: BoxFit.contain,
                  width: 11.0,
                  height: 6.0,
                ),
                replacement: const SizedBox.shrink(),
              ),
              //iconSize: 25.55,
              value: _statusFilterValue ?? "",
              style: Styles.titleTextWithF12W700,
              items: monthlist.map<DropdownMenuItem<String>>((String item) {
                return DropdownMenuItem<String>(
                  value: item.toString(),
                  child: Text(item.toString(),
                      style: Styles.contentTearmsConditionsW300),
                );
              }).toList(),

              onChanged: (value) {
                setState(() {
                  isSelected = true;
                  _statusFilterValue = value;
                });
                debugPrint('selected_value $_statusFilterValue');
                if (tabID == 0) {
                  kpiReportsViewModel.readNewLeadData(
                    _statusFilterValue!,
                  );
                } else if (tabID == 1) {
                  kpiReportsViewModel.readExistingAccountData(
                    _statusFilterValue!,
                  );
                }
              },
            ),
          ),
        ],
      ),
    );
  }

  kpiReportsAccountResponse() {
    return StreamBuilder(
        stream: kpiReportsViewModel.kpiAccountsdata,
        builder: (context, AsyncSnapshot<KpiAccountsData> snapshot) {
          if (snapshot.hasData) {
            final response = snapshot.data;
            if (response?.serviceStatus?.statusCode == 200) {
              return existingAccountPenetration(response);
            } else {
              return Center(child: Text(response!.serviceStatus!.message!));
            }
          } else if (snapshot.hasError) {
            return Center(child: Text(snapshot.error.toString()));
          }
          return const Center(
            child: CircularProgressIndicator(),
          );
        });
  }

  kpiNewLeadDataResponse() {
    return StreamBuilder(
        stream: kpiReportsViewModel.kpiReportsResponse,
        builder: (context, AsyncSnapshot<KPIReportNewLead> snapshot) {
          if (snapshot.hasData) {
            final response = snapshot.data;
            if (response?.serviceStatus?.statusCode == 200) {
              return newLeadSubmission(response);
            } else {
              return Center(child: Text(response!.serviceStatus!.message!));
            }
          } else if (snapshot.hasError) {
            return Center(child: Text(snapshot.error.toString()));
          }
          return const Center(
            child: CircularProgressIndicator(),
          );
        });
  }

  TabBar tabBarWidget() {
    return TabBar(
      padding: const EdgeInsets.all(5.0),
      automaticIndicatorColorAdjustment: true,
      labelColor: xColor,
      indicatorColor: xColor,
      indicatorSize: TabBarIndicatorSize.tab,
      unselectedLabelColor: xColorlightGrey,
      isScrollable: false,
      controller: tabController,
      labelStyle: Styles.tabBarTextWithF12W700,
      tabs: const [
        Tab(
          text: 'New Lead\nSubmission',
        ),
        Tab(
          text: 'Existing Account\nPenetration',
        )
      ],
      onTap: (value) {
        setState(() {
          isSelected = false;
          debugPrint('$value');
          tabID = value;
        });
      },
    );
  }

  existingAccountPenetration(KpiAccountsData? kpiAccountResponse) {
    final sevenDays, twentyOneDays, thirtyDays;
    final accAssigned = kpiAccountResponse!
        .responseData!.data!.completionRate!.accAssigned
        .toString();
    final accVisited = kpiAccountResponse
        .responseData!.data!.completionRate!.accVisited
        .toString();
    final percentage = kpiAccountResponse
        .responseData!.data!.completionRate!.percentage
        .toString();

    String? accountsLeft =
        kpiAccountResponse.responseData!.data!.accountsLeft.toString();
    String? accountsVisited =
        kpiAccountResponse.responseData!.data!.accountsVisited.toString();
    String? packagesCount =
        kpiAccountResponse.responseData!.data!.packagesCount.toString();
    String? shipmentCount =
        kpiAccountResponse.responseData!.data!.shipmentCount.toString();

    if (kpiAccountResponse.responseData?.data?.revenueGenerated != null) {
      sevenDays =
          kpiAccountResponse.responseData!.data!.revenueGenerated!.sevenDays;
      twentyOneDays = kpiAccountResponse
          .responseData!.data!.revenueGenerated!.twentyOneDays;
      thirtyDays =
          kpiAccountResponse.responseData!.data!.revenueGenerated!.thirtyDays;
    } else {
      sevenDays = '0';
      twentyOneDays = '0';
      thirtyDays = '0';
    }

    final timeDifference = kpiReportsViewModel.getTimeDifference(
        kpiAccountResponse.responseData?.data?.lastfollowupdate.toString());
    _controller?.duration = Duration(seconds: timeDifference);
    _controller?.forward();

    return Expanded(
      child: Column(
        children: [
          Container(
            padding: const EdgeInsets.all(10.0),
            decoration: const BoxDecoration(
              color: xColorThinlightGrey,
            ),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Expanded(
                  flex: 3,
                  child: Column(
                    children: [
                      //COMPLETION RATE
                      Container(
                        decoration: const BoxDecoration(
                          color: xColorlightGreyX,
                        ),
                        child: Column(
                          children: [
                            Container(
                              width: MediaQuery.of(context).size.width,
                              decoration: const BoxDecoration(
                                gradient: LinearGradient(colors: [
                                  Color(0xFF4D148C),
                                  Color(0xFFF36717)
                                ]),
                              ),
                              child: Padding(
                                padding: const EdgeInsets.all(8.0),
                                child: Row(children: [
                                  SvgPicture.asset(
                                    Constant.completionRate,
                                    height: 20,
                                    width: 20,
                                  ),
                                  const SizedBox(width: 5),
                                  Text(
                                    'COMPLETION_RATE'.tr(),
                                    overflow: TextOverflow.ellipsis,
                                    softWrap: false,
                                    maxLines: 1,
                                    style: Styles.titleWhiteTextWithF10,
                                  ),
                                ]),
                              ),
                            ),
                            Container(
                              width: MediaQuery.of(context).size.width,
                              margin: const EdgeInsets.all(10),
                              padding: const EdgeInsets.all(10),
                              decoration: const BoxDecoration(
                                color: xColorWhite,
                              ),
                              child: Row(
                                children: [
                                  Expanded(
                                    child: Text(
                                      percentage + "%",
                                      textAlign: TextAlign.center,
                                      style: Styles.timeLeftTextWithF20W700,
                                    ),
                                  ),
                                  Expanded(
                                    child: Column(
                                      children: [
                                        Text(
                                          accVisited,
                                          textAlign: TextAlign.center,
                                          style: Styles.editTextWithF14W700,
                                        ),
                                        Text(
                                          'Acc_Visited'.tr(),
                                          textAlign: TextAlign.center,
                                          style: Styles.titleGreyTextWithF8,
                                        ),
                                      ],
                                    ),
                                  ),
                                  Expanded(
                                    child: Column(
                                      children: [
                                        Text(
                                          accAssigned,
                                          textAlign: TextAlign.center,
                                          style: Styles.editTextWithF14W700,
                                        ),
                                        Text(
                                          'Acc_Assigned'.tr(),
                                          textAlign: TextAlign.center,
                                          style: Styles.titleGreyTextWithF8,
                                        ),
                                      ],
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ],
                        ),
                      ),
                      const SizedBox(height: 10),
                      //TIME LEFT
                      Container(
                        decoration: const BoxDecoration(
                          color: xColorlightGreyX,
                        ),
                        child: Column(
                          children: [
                            Container(
                              width: MediaQuery.of(context).size.width,
                              decoration: const BoxDecoration(
                                gradient: LinearGradient(colors: [
                                  Color(0xFF4D148C),
                                  Color(0xFFF36717)
                                ]),
                              ),
                              child: Padding(
                                padding: const EdgeInsets.all(8.0),
                                child: Row(children: [
                                  SvgPicture.asset(
                                    Constant.timeLeft,
                                    height: 20,
                                    width: 20,
                                  ),
                                  const SizedBox(width: 5),
                                  Text(
                                    'TIME_LEFT'.tr(),
                                    style: Styles.titleWhiteTextWithF10,
                                  ),
                                ]),
                              ),
                            ),
                            Countdown(
                              animation: StepTween(
                                begin: timeDifference,
                                end: 0,
                              ).animate(_controller!),
                            ),
                            // Row(
                            //   children: [
                            //     Expanded(
                            //       child: Column(
                            //         children: [
                            //           const SizedBox(height: 3),
                            //           Text(
                            //             'DAYS'.tr(),
                            //             textAlign: TextAlign.start,
                            //             style: Styles.timeWithF10W400,
                            //           ),
                            //           Container(
                            //             width:
                            //                 MediaQuery.of(context).size.width,
                            //             margin: const EdgeInsets.only(
                            //                 left: 5,
                            //                 bottom: 10,
                            //                 right: 5,
                            //                 top: 5),
                            //             padding: const EdgeInsets.all(5),
                            //             decoration: const BoxDecoration(
                            //               color: xColorWhite,
                            //             ),
                            //             child: Text(
                            //               '30',
                            //               textAlign: TextAlign.center,
                            //               style: Styles.timeLeftTextWithF20W700,
                            //             ),
                            //           ),
                            //         ],
                            //       ),
                            //     ),
                            //     Expanded(
                            //       child: Column(
                            //         children: [
                            //           const SizedBox(height: 3),
                            //           Text(
                            //             'HRS'.tr(),
                            //             textAlign: TextAlign.start,
                            //             style: Styles.timeWithF10W400,
                            //           ),
                            //           Container(
                            //             width:
                            //                 MediaQuery.of(context).size.width,
                            //             margin: const EdgeInsets.only(
                            //                 left: 5,
                            //                 bottom: 10,
                            //                 right: 5,
                            //                 top: 5),
                            //             padding: const EdgeInsets.all(5),
                            //             decoration: const BoxDecoration(
                            //               color: xColorWhite,
                            //             ),
                            //             child: Text(
                            //               '30',
                            //               textAlign: TextAlign.center,
                            //               style: Styles.timeLeftTextWithF20W700,
                            //             ),
                            //           ),
                            //         ],
                            //       ),
                            //     ),
                            //     Expanded(
                            //       child: Column(
                            //         children: [
                            //           const SizedBox(height: 3),
                            //           Text(
                            //             'MINS'.tr(),
                            //             textAlign: TextAlign.start,
                            //             style: Styles.timeWithF10W400,
                            //           ),
                            //           Container(
                            //             width:
                            //                 MediaQuery.of(context).size.width,
                            //             margin: const EdgeInsets.only(
                            //                 left: 5,
                            //                 bottom: 10,
                            //                 right: 5,
                            //                 top: 5),
                            //             padding: const EdgeInsets.all(5),
                            //             decoration: const BoxDecoration(
                            //               color: xColorWhite,
                            //             ),
                            //             child: Text(
                            //               '59',
                            //               textAlign: TextAlign.center,
                            //               style: Styles.timeLeftTextWithF20W700,
                            //             ),
                            //           ),
                            //         ],
                            //       ),
                            //     ),
                            //   ],
                            // ),
                          ],
                        ),
                      ),
                    ],
                  ),
                ),
                const SizedBox(width: 10),
                Expanded(
                  flex: 2,
                  child: Column(
                    children: [
                      //ACCOUNTS LEFT
                      Container(
                        decoration: const BoxDecoration(
                          color: xColorlightGreyX,
                        ),
                        child: Column(
                          children: [
                            Container(
                              width: MediaQuery.of(context).size.width,
                              decoration: const BoxDecoration(
                                gradient: LinearGradient(colors: [
                                  Color(0xFF4D148C),
                                  Color(0xFFF36717)
                                ]),
                              ),
                              child: Padding(
                                padding: const EdgeInsets.all(8.0),
                                child: Row(children: [
                                  SvgPicture.asset(
                                    Constant.accountsLeft,
                                    height: 20,
                                    width: 20,
                                  ),
                                  const SizedBox(width: 5),
                                  Expanded(
                                    child: FittedBox(
                                      child: Text(
                                        'ACCOUNTS_LEFT'.tr(),
                                        overflow: TextOverflow.ellipsis,
                                        softWrap: false,
                                        maxLines: 2,
                                        style: Styles.titleWhiteTextWithF10,
                                      ),
                                    ),
                                  ),
                                ]),
                              ),
                            ),
                            Container(
                              width: MediaQuery.of(context).size.width,
                              margin: const EdgeInsets.all(10),
                              padding: const EdgeInsets.all(10),
                              decoration: const BoxDecoration(
                                color: xColorWhite,
                              ),
                              child: Text(
                                accountsLeft,
                                textAlign: TextAlign.center,
                                style: Styles.timeLeftTextWithF20W700,
                              ),
                            ),
                          ],
                        ),
                      ),
                      const SizedBox(height: 10),
                      //ACCOUNTS VISITED
                      Container(
                        decoration: const BoxDecoration(
                          color: xColorlightGreyX,
                        ),
                        child: Column(
                          children: [
                            Container(
                              width: MediaQuery.of(context).size.width,
                              decoration: const BoxDecoration(
                                gradient: LinearGradient(colors: [
                                  Color(0xFF4D148C),
                                  Color(0xFFF36717)
                                ]),
                              ),
                              child: Padding(
                                padding: const EdgeInsets.all(8.0),
                                child: Row(children: [
                                  SvgPicture.asset(
                                    Constant.accountsVisited,
                                    height: 20,
                                    width: 20,
                                  ),
                                  const SizedBox(width: 5),
                                  Expanded(
                                    child: FittedBox(
                                      child: Text(
                                        'ACCOUNTS_VISITED'.tr(),
                                        overflow: TextOverflow.clip,
                                        softWrap: false,
                                        maxLines: 2,
                                        style: Styles.titleWhiteTextWithF10,
                                      ),
                                    ),
                                  ),
                                ]),
                              ),
                            ),
                            Container(
                              width: MediaQuery.of(context).size.width,
                              margin: const EdgeInsets.all(10),
                              padding: const EdgeInsets.all(10),
                              decoration: const BoxDecoration(
                                color: xColorWhite,
                              ),
                              child: Text(
                                accountsVisited,
                                textAlign: TextAlign.center,
                                style: Styles.timeLeftTextWithF20W700,
                              ),
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                )
              ],
            ),
          ),
          //
          const Divider(color: xColorlightGrey, thickness: 2),
          //
          Container(
            padding: const EdgeInsets.all(10.0),
            decoration: const BoxDecoration(
              color: xColorThinlightGrey,
            ),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Expanded(
                  child: Column(
                    children: [
                      //SHIPMENT COUNT
                      Container(
                        decoration: const BoxDecoration(
                          color: xColorlightGreyX,
                        ),
                        child: Column(
                          children: [
                            Container(
                              width: MediaQuery.of(context).size.width,
                              decoration: const BoxDecoration(
                                gradient: LinearGradient(colors: [
                                  Color(0xFF4D148C),
                                  Color(0xFFF36717)
                                ]),
                              ),
                              child: Padding(
                                padding: const EdgeInsets.all(8.0),
                                child: Row(children: [
                                  SvgPicture.asset(
                                    Constant.shipmentCount,
                                    height: 20,
                                    width: 20,
                                  ),
                                  const SizedBox(width: 5),
                                  Text(
                                    'SHIPMENT_COUNT'.tr(),
                                    overflow: TextOverflow.ellipsis,
                                    softWrap: false,
                                    maxLines: 1,
                                    style: Styles.titleWhiteTextWithF10,
                                  ),
                                ]),
                              ),
                            ),
                            Container(
                              width: MediaQuery.of(context).size.width,
                              margin: const EdgeInsets.all(10),
                              padding: const EdgeInsets.all(10),
                              decoration: const BoxDecoration(
                                color: xColorWhite,
                              ),
                              child: Text(
                                shipmentCount,
                                textAlign: TextAlign.center,
                                style: Styles.timeLeftTextWithF20W700,
                              ),
                            ),
                          ],
                        ),
                      ),
                      const SizedBox(height: 10),
                      //ACCOUNTS OPENED
                      Container(
                        decoration: const BoxDecoration(
                          color: xColorlightGreyX,
                        ),
                        child: Column(
                          children: [
                            Container(
                              width: MediaQuery.of(context).size.width,
                              decoration: const BoxDecoration(
                                gradient: LinearGradient(colors: [
                                  Color(0xFF4D148C),
                                  Color(0xFFF36717)
                                ]),
                              ),
                              child: Padding(
                                padding: const EdgeInsets.all(8.0),
                                child: Row(children: [
                                  SvgPicture.asset(
                                    Constant.packageCount,
                                    height: 20,
                                    width: 20,
                                  ),
                                  const SizedBox(width: 5),
                                  Text(
                                    'PACKAGE_COUNT'.tr(),
                                    style: Styles.titleWhiteTextWithF10,
                                  ),
                                ]),
                              ),
                            ),
                            Container(
                              width: MediaQuery.of(context).size.width,
                              margin: const EdgeInsets.all(10),
                              padding: const EdgeInsets.all(10),
                              decoration: const BoxDecoration(
                                color: xColorWhite,
                              ),
                              child: Text(
                                packagesCount,
                                textAlign: TextAlign.center,
                                style: Styles.timeLeftTextWithF20W700,
                              ),
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                ),
                const SizedBox(width: 10),
                Expanded(
                  child: Column(
                    children: [
                      Container(
                        decoration: const BoxDecoration(
                          color: xColorlightGreyX,
                        ),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.stretch,
                          children: [
                            Container(
                              width: MediaQuery.of(context).size.width,
                              decoration: const BoxDecoration(
                                gradient: LinearGradient(colors: [
                                  Color(0xFF4D148C),
                                  Color(0xFFF36717)
                                ]),
                              ),
                              child: Padding(
                                padding: const EdgeInsets.all(8.0),
                                child: Row(children: [
                                  SvgPicture.asset(
                                    Constant.revenueGenerated,
                                    height: 20,
                                    width: 20,
                                  ),
                                  Expanded(
                                    child: FittedBox(
                                      child: Text(
                                        'REVENUE_GENERATED'.tr(),
                                        style: Styles.titleWhiteTextWithF10,
                                      ),
                                    ),
                                  ),
                                ]),
                              ),
                            ),
                            const SizedBox(height: 8),
                            Row(
                              children: [
                                const SizedBox(width: 10),
                                Text(
                                  '7_DAYS'.tr(),
                                  textAlign: TextAlign.center,
                                  style: Styles.titleTextWithF10W400,
                                ),
                              ],
                            ),
                            Container(
                              width: MediaQuery.of(context).size.width,
                              margin: const EdgeInsets.only(
                                  left: 10, right: 10, top: 4, bottom: 4),
                              padding: const EdgeInsets.all(5),
                              decoration: const BoxDecoration(
                                color: xColorWhite,
                              ),
                              child: Row(
                                crossAxisAlignment: CrossAxisAlignment.center,
                                mainAxisAlignment: MainAxisAlignment.center,
                                children: [
                                  Text(
                                    sevenDays.toString(),
                                    textAlign: TextAlign.center,
                                    style: Styles.timeLeftTextWithF20W700,
                                  ),
                                  const SizedBox(width: 2),
                                  Text(
                                    'US\$',
                                    textAlign: TextAlign.start,
                                    style: Styles.kpiusDollarTestF10W700,
                                  )
                                ],
                              ),
                            ),
                            Row(
                              children: [
                                const SizedBox(width: 10),
                                Text(
                                  '21_DAYS'.tr(),
                                  textAlign: TextAlign.center,
                                  style: Styles.titleTextWithF10W400,
                                ),
                              ],
                            ),
                            Container(
                              width: MediaQuery.of(context).size.width,
                              margin: const EdgeInsets.only(
                                  left: 10, right: 10, top: 4, bottom: 4),
                              padding: const EdgeInsets.all(5),
                              decoration: const BoxDecoration(
                                color: xColorWhite,
                              ),
                              child: Row(
                                crossAxisAlignment: CrossAxisAlignment.center,
                                mainAxisAlignment: MainAxisAlignment.center,
                                children: [
                                  Text(
                                    twentyOneDays.toString(),
                                    textAlign: TextAlign.center,
                                    style: Styles.timeLeftTextWithF20W700,
                                  ),
                                  const SizedBox(width: 2),
                                  Text(
                                    'US\$',
                                    textAlign: TextAlign.start,
                                    style: Styles.kpiusDollarTestF10W700,
                                  )
                                ],
                              ),
                            ),
                            Row(
                              children: [
                                const SizedBox(width: 10),
                                Text(
                                  '30_DAYS'.tr(),
                                  textAlign: TextAlign.center,
                                  style: Styles.titleTextWithF10W400,
                                ),
                              ],
                            ),
                            Container(
                              width: MediaQuery.of(context).size.width,
                              margin: const EdgeInsets.only(
                                  left: 10, right: 10, bottom: 10, top: 4),
                              padding: const EdgeInsets.all(5),
                              decoration: const BoxDecoration(
                                color: xColorWhite,
                              ),
                              child: Row(
                                crossAxisAlignment: CrossAxisAlignment.center,
                                mainAxisAlignment: MainAxisAlignment.center,
                                children: [
                                  Text(
                                    thirtyDays.toString(),
                                    textAlign: TextAlign.center,
                                    style: Styles.timeLeftTextWithF20W700,
                                  ),
                                  const SizedBox(width: 2),
                                  Text(
                                    'US\$',
                                    textAlign: TextAlign.start,
                                    style: Styles.kpiusDollarTestF10W700,
                                  )
                                ],
                              ),
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  newLeadSubmission(KPIReportNewLead? kpiReportNewLead) {
    final sevenDays, twentyOneDays, thirtyDays;
    String salesLeadGenrated =
        kpiReportNewLead!.responseData!.data!.salesLeadGenrated.toString();
    String accountsOpened =
        kpiReportNewLead.responseData!.data!.accountsOpened.toString();
    String shipmentCount =
        kpiReportNewLead.responseData!.data!.shipmentCount.toString();
    String packagesCount =
        kpiReportNewLead.responseData!.data!.packagesCount.toString();
    if (kpiReportNewLead.responseData?.data?.revenueGenerated != null) {
      sevenDays =
          kpiReportNewLead.responseData!.data!.revenueGenerated!.sevenDays;
      twentyOneDays =
          kpiReportNewLead.responseData!.data!.revenueGenerated!.twentyOneDays;
      thirtyDays =
          kpiReportNewLead.responseData!.data!.revenueGenerated!.thirtyDays;
    } else {
      sevenDays = '0';
      twentyOneDays = '0';
      thirtyDays = '0';
    }

    return Expanded(
      child: Container(
        padding: const EdgeInsets.all(10.0),
        decoration: const BoxDecoration(
          color: xColorThinlightGrey,
        ),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Expanded(
              child: Column(
                children: [
                  //SALES LEAD GENERATED
                  Container(
                    decoration: const BoxDecoration(
                      color: xColorlightGreyX,
                    ),
                    child: Column(
                      children: [
                        Container(
                          width: MediaQuery.of(context).size.width,
                          decoration: const BoxDecoration(
                            gradient: LinearGradient(
                                colors: [Color(0xFF4D148C), Color(0xFFF36717)]),
                          ),
                          child: Padding(
                            padding: const EdgeInsets.all(8.0),
                            child: Row(children: [
                              SvgPicture.asset(
                                Constant.salesLeadGenerated,
                                height: 20,
                                width: 20,
                              ),
                              const SizedBox(width: 5),
                              Expanded(
                                child: FittedBox(
                                  child: Text(
                                    'sales_lead_gen'.tr(),
                                    maxLines: 1,
                                    style: Styles.titleWhiteTextWithF10,
                                  ),
                                ),
                              ),
                            ]),
                          ),
                        ),
                        Container(
                          width: MediaQuery.of(context).size.width,
                          margin: const EdgeInsets.all(10),
                          padding: const EdgeInsets.all(10),
                          decoration: const BoxDecoration(
                            color: xColorWhite,
                          ),
                          child: Text(
                            salesLeadGenrated,
                            textAlign: TextAlign.center,
                            style: Styles.timeLeftTextWithF20W700,
                          ),
                        ),
                      ],
                    ),
                  ),
                  const SizedBox(height: 10),
                  //ACCOUNTS OPENED
                  Container(
                    decoration: const BoxDecoration(
                      color: xColorlightGreyX,
                    ),
                    child: Column(
                      children: [
                        Container(
                          width: MediaQuery.of(context).size.width,
                          decoration: const BoxDecoration(
                            gradient: LinearGradient(
                                colors: [Color(0xFF4D148C), Color(0xFFF36717)]),
                          ),
                          child: Padding(
                            padding: const EdgeInsets.all(8.0),
                            child: Row(children: [
                              SvgPicture.asset(
                                Constant.accountOpen,
                                height: 20,
                                width: 20,
                              ),
                              const SizedBox(width: 5),
                              Expanded(
                                child: FittedBox(
                                  child: Text(
                                    'ACCOUNTS_OPENED'.tr(),
                                    style: Styles.titleWhiteTextWithF10,
                                  ),
                                ),
                              ),
                            ]),
                          ),
                        ),
                        Container(
                          width: MediaQuery.of(context).size.width,
                          margin: const EdgeInsets.all(10),
                          padding: const EdgeInsets.all(10),
                          decoration: const BoxDecoration(
                            color: xColorWhite,
                          ),
                          child: Text(
                            accountsOpened,
                            textAlign: TextAlign.center,
                            style: Styles.timeLeftTextWithF20W700,
                          ),
                        ),
                      ],
                    ),
                  ),
                  const SizedBox(height: 10),
                  //SHIPMENT COUNT
                  Container(
                    decoration: const BoxDecoration(
                      color: xColorlightGreyX,
                    ),
                    child: Column(
                      children: [
                        Container(
                          width: MediaQuery.of(context).size.width,
                          decoration: const BoxDecoration(
                            gradient: LinearGradient(
                                colors: [Color(0xFF4D148C), Color(0xFFF36717)]),
                          ),
                          child: Padding(
                            padding: const EdgeInsets.all(8.0),
                            child: Row(children: [
                              SvgPicture.asset(
                                Constant.shipmentCount,
                                height: 20,
                                width: 20,
                              ),
                              const SizedBox(width: 5),
                              Text(
                                'SHIPMENT_COUNT'.tr(),
                                style: Styles.titleWhiteTextWithF10,
                              ),
                            ]),
                          ),
                        ),
                        Container(
                          width: MediaQuery.of(context).size.width,
                          margin: const EdgeInsets.all(10),
                          padding: const EdgeInsets.all(10),
                          decoration: const BoxDecoration(
                            color: xColorWhite,
                          ),
                          child: Text(
                            shipmentCount,
                            textAlign: TextAlign.center,
                            style: Styles.timeLeftTextWithF20W700,
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
            const SizedBox(width: 10),
            Expanded(
              child: Column(
                children: [
                  Container(
                    decoration: const BoxDecoration(
                      color: xColorlightGreyX,
                    ),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.stretch,
                      children: [
                        Container(
                          width: MediaQuery.of(context).size.width,
                          decoration: const BoxDecoration(
                            gradient: LinearGradient(
                                colors: [Color(0xFF4D148C), Color(0xFFF36717)]),
                          ),
                          child: Padding(
                            padding: const EdgeInsets.all(8.0),
                            child: Row(children: [
                              SvgPicture.asset(
                                Constant.revenueGenerated,
                                height: 20,
                                width: 20,
                              ),
                              Expanded(
                                child: FittedBox(
                                  child: Text(
                                    'REVENUE_GENERATED'.tr(),
                                    style: Styles.titleWhiteTextWithF10,
                                  ),
                                ),
                              ),
                            ]),
                          ),
                        ),
                        const SizedBox(height: 8),
                        Row(
                          children: [
                            const SizedBox(width: 10),
                            Text(
                              '7_DAYS'.tr(),
                              textAlign: TextAlign.center,
                              style: Styles.titleTextWithF10W400,
                            ),
                          ],
                        ),
                        Container(
                          width: MediaQuery.of(context).size.width,
                          margin: const EdgeInsets.only(
                              left: 10, right: 10, top: 4, bottom: 4),
                          padding: const EdgeInsets.all(5),
                          decoration: const BoxDecoration(
                            color: xColorWhite,
                          ),
                          child: Row(
                            crossAxisAlignment: CrossAxisAlignment.center,
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              Text(
                                sevenDays.toString(),
                                textAlign: TextAlign.center,
                                style: Styles.timeLeftTextWithF20W700,
                              ),
                              const SizedBox(width: 2),
                              Text(
                                'US\$',
                                textAlign: TextAlign.start,
                                style: Styles.kpiusDollarTestF10W700,
                              )
                            ],
                          ),
                        ),
                        Row(
                          children: [
                            const SizedBox(width: 10),
                            Text(
                              '21_DAYS'.tr(),
                              textAlign: TextAlign.center,
                              style: Styles.titleTextWithF10W400,
                            ),
                          ],
                        ),
                        Container(
                          width: MediaQuery.of(context).size.width,
                          margin: const EdgeInsets.only(
                              left: 10, right: 10, top: 4, bottom: 4),
                          padding: const EdgeInsets.all(5),
                          decoration: const BoxDecoration(
                            color: xColorWhite,
                          ),
                          child: Row(
                            crossAxisAlignment: CrossAxisAlignment.center,
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              Text(
                                twentyOneDays.toString(),
                                textAlign: TextAlign.center,
                                style: Styles.timeLeftTextWithF20W700,
                              ),
                              const SizedBox(width: 2),
                              Text(
                                'US\$',
                                textAlign: TextAlign.start,
                                style: Styles.kpiusDollarTestF10W700,
                              )
                            ],
                          ),
                        ),
                        Row(
                          children: [
                            const SizedBox(width: 10),
                            Text(
                              '30_DAYS'.tr(),
                              textAlign: TextAlign.center,
                              style: Styles.titleTextWithF10W400,
                            ),
                          ],
                        ),
                        Container(
                          width: MediaQuery.of(context).size.width,
                          margin: const EdgeInsets.only(
                              left: 10, right: 10, bottom: 10, top: 4),
                          padding: const EdgeInsets.all(5),
                          decoration: const BoxDecoration(
                            color: xColorWhite,
                          ),
                          child: Row(
                            crossAxisAlignment: CrossAxisAlignment.center,
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              Text(
                                thirtyDays.toString(),
                                textAlign: TextAlign.center,
                                style: Styles.timeLeftTextWithF20W700,
                              ),
                              const SizedBox(width: 2),
                              Text(
                                'US\$',
                                textAlign: TextAlign.start,
                                style: Styles.kpiusDollarTestF10W700,
                              )
                            ],
                          ),
                        ),
                      ],
                    ),
                  ),
                  const SizedBox(height: 10),
                  Container(
                    decoration: const BoxDecoration(
                      color: xColorlightGreyX,
                    ),
                    child: Column(
                      children: [
                        Container(
                          width: MediaQuery.of(context).size.width,
                          decoration: const BoxDecoration(
                            gradient: LinearGradient(
                                colors: [Color(0xFF4D148C), Color(0xFFF36717)]),
                          ),
                          child: Padding(
                            padding: const EdgeInsets.all(8.0),
                            child: Row(children: [
                              SvgPicture.asset(
                                Constant.packageCount,
                                height: 20,
                                width: 20,
                              ),
                              const SizedBox(width: 5),
                              Text(
                                'PACKAGES_COUNT'.tr(),
                                style: Styles.titleWhiteTextWithF10,
                              ),
                            ]),
                          ),
                        ),
                        Container(
                          width: MediaQuery.of(context).size.width,
                          margin: const EdgeInsets.all(10),
                          padding: const EdgeInsets.all(10),
                          decoration: const BoxDecoration(
                            color: xColorWhite,
                          ),
                          child: Text(
                            packagesCount,
                            textAlign: TextAlign.center,
                            style: Styles.timeLeftTextWithF20W700,
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
