// ignore_for_file: unused_field, implementation_imports

import 'package:easy_localization/src/public_ext.dart';
import 'package:fedex_app/model/account_existing_update.dart';
import 'package:fedex_app/model/add_comments.dart';
import 'package:fedex_app/model/individual_account_model.dart';
import 'package:fedex_app/utility/apis/api_response.dart';
import 'package:fedex_app/utility/constant.dart';
import 'package:fedex_app/utility/styles.dart';
import 'package:fedex_app/utility/theme_colors.dart';
import 'package:fedex_app/view/widgets/count_down_timer.dart';
import 'package:fedex_app/view/widgets/custom_app_bar.dart';
import 'package:fedex_app/viewmodel/account_penetration_view_model.dart';
import 'package:fedex_app/viewmodel/individual_lead_viewmodel.dart';
import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:provider/provider.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../widgets/rounded_text_formfield.dart';
import 'dart:io';

import 'existing_accounts_penetration.dart';

class IndividualAccountsPenetrationPage extends StatefulWidget {
  static String routeName = '/IndividualAccountsPenetrationPage';
  const IndividualAccountsPenetrationPage({Key? key}) : super(key: key);

  @override
  _IndividualAccountsPenetrationPageState createState() =>
      _IndividualAccountsPenetrationPageState();
}

class _IndividualAccountsPenetrationPageState
    extends State<IndividualAccountsPenetrationPage>
    with SingleTickerProviderStateMixin {
  final newLeadViewModel = IndividualLeadSubmitedViewmodel();
  final _accountPenetrationViewModel = AccountsPenetrationViewModel();
  final _formKey = GlobalKey<FormState>();
  final GlobalKey<ScaffoldMessengerState> _scaffoldMessengerKey =
      GlobalKey<ScaffoldMessengerState>();

  AccountDetails? accountDetailsData;
  AnimationController? _controller;

  final _accountNumberController = TextEditingController();
  final _companyNameController = TextEditingController();
  final _customerLastNameController = TextEditingController();
  final _customerFirstNameController = TextEditingController();
  final _customerTitleController = TextEditingController();
  final _contactPhoneController = TextEditingController();
  final _contactMobileController = TextEditingController();
  final _addressLineOneController = TextEditingController();
  final _addressLineTwoController = TextEditingController();
  final _cityController = TextEditingController();
  final _postalController = TextEditingController();
  final _emailController = TextEditingController();
  final _remarksController = TextEditingController();
  final _addCommentsController = TextEditingController();

  var _accountNumber = '';
  var _companyName = '';
  var _customerLastName = '';
  var _customerFirstName = '';
  // ignore: prefer_final_fields
  var _customerTitle = '';
  var _contactPhone = '';
  var _addressLineOne = '';
  var _addressLineTwo = '';
  var _city = '';
  var _postal = '';
  var _email = '';
  var _remarks = '';
  var _addComments = '';
  final ScrollController _scrollController = ScrollController();
  String? _radioValue; //Initial definition of radio button value
  String? choice;
  bool? isReadyForAccountOpening = false;
  bool? isCheckedAttachement = false;
  String? _imageFilePath;
  String? _chosenValue = 'select'.tr();
  bool isReasonUIVisible = false;
  String chosenReason = 'Select';
  bool isViewComments = true;
  bool isAddComments = false;
  final List<UploadedFile> _imageFilePathList = [];

  bool isUploadedFiles = false;
  int count = 0;
  final bool _autovalidate = false;
  final bool _isAttachementButtonDisabled = false;
  int businesAttachCount = 0,
      acOpenAttachCount = 0,
      businesCardAttachCount = 0,
      otherAttachCount = 0;
  bool _loading = false;
  List<String> tempList = [];
  String stationId = "";
  String routeNo = "";
  String countryCode = "";
  int maxPostalCodeLength = 0;
  bool isHeaderError = false;
  final String? _statusFilterValue = 'Select';

  dynamic selectedLeadOID;
  // String _LeadId = '';

  List<AccountComments>? accountComments = [];

  void radioButtonChanges(String? value) {
    setState(() {
      _radioValue = value;
      switch (value) {
        case 'YES':
          choice = value;
          break;
        case 'NO':
          choice = value;
          break;
        default:
          choice = null;
      }
    });
  }

  void checkboxnChanges(bool? value) {
    setState(() {
      isReadyForAccountOpening = value;
    });
  }

  @override
  void initState() {
    _controller =
        AnimationController(vsync: this, duration: const Duration(seconds: 0));
    getCountryCode().then((value) {
      setState(() {
        if (value == 'HK') {
          countryCode = value;
          maxPostalCodeLength = 6;
        } else if (value == 'JP') {
          countryCode = value;
          maxPostalCodeLength = 7;
        } else if (value == 'CN') {
          countryCode = value;
          maxPostalCodeLength = 6;
        } else if (value == 'TW') {
          countryCode = value;
          maxPostalCodeLength = 6;
        } else if (value == 'TH') {
          countryCode = value;
          maxPostalCodeLength = 5;
        } else if (value == 'KR') {
          countryCode = value;
          maxPostalCodeLength = 5;
        } else if (value == 'SG') {
          countryCode = value;
          maxPostalCodeLength = 6;
        } else if (value == 'MY') {
          countryCode = value;
          maxPostalCodeLength = 6;
        } else if (value == 'PH') {
          countryCode = value;
          maxPostalCodeLength = 6;
        } else if (value == 'VN') {
          countryCode = value;
          maxPostalCodeLength = 6;
        } else if (value == 'ID') {
          countryCode = value;
          maxPostalCodeLength = 6;
        } else if (value == 'AU') {
          countryCode = value;
          maxPostalCodeLength = 6;
        } else if (value == 'NG') {
          countryCode = value;
          maxPostalCodeLength = 6;
        } else {
          maxPostalCodeLength = 6;
        }

        //countryCode = value;
      });
    });

    getStationId().then((value) {
      setState(() {
        stationId = value;
      });
    });
    getRouteNumber().then((value) {
      setState(() {
        routeNo = value;
      });
    });

    super.initState();
  }

  void showSnackBar(BuildContext context, String text) {
    _scaffoldMessengerKey.currentState!.showSnackBar(
      SnackBar(
        behavior: SnackBarBehavior.floating,
        backgroundColor: Colors.red,
        content: Text(text, style: Styles.titleWhiteTextWithF12W700),
      ),
    );
  }

  Future<String> getStationId() async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.getString('stationId')!;
  }

  Future<String> getRouteNumber() async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.getString('routeNumber')!;
  }

  Future<String> getCountryCode() async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.getString('countryCode')!;
  }

  @override
  void didChangeDependencies() {
    // updateAttachementfunctionality();
    super.didChangeDependencies();
  }

  String? checkStatus(String? str) {
    if (str == '0') {
      return 'Select';
    } else if (str == '2') {
      return Constant.rejectToEnrol;
    } else if (str == '3') {
      return Constant.agreeToEnrol;
    }
    return 'Select';
  }

  String? getStatusCode(String? str) {
    if (str == 'Select') {
      return '0';
    } else if (str == Constant.rejectToEnrol) {
      return '2';
    } else if (str == Constant.agreeToEnrol) {
      return '3';
    }
    return '0';
  }

  String? checkReason(String? str) {
    if (str == '1') {
      return Constant.unreachable;
    } else if (str == '2') {
      return Constant.notInterested;
    } else if (str == '3') {
      return Constant.notApplicable;
    } else if (str == '4') {
      return Constant.businessMoved;
    } else if (str == '5') {
      return Constant.noPackage;
    } else if (str == '6') {
      return Constant.others;
    }
    return '';
  }

  String? getResonCode(String? str) {
    if (str == Constant.unreachable) {
      return '1';
    } else if (str == Constant.notInterested) {
      return '2';
    } else if (str == Constant.notApplicable) {
      return '3';
    } else if (str == Constant.businessMoved) {
      return '4';
    } else if (str == Constant.noPackage) {
      return '5';
    } else if (str == Constant.others) {
      return '6';
    }

    return '1';
  }

  @override
  void dispose() {
    _imageFilePathList.clear();
    _accountNumberController.dispose();
    _companyNameController.dispose();
    _customerLastNameController.dispose();
    _customerFirstNameController.dispose();
    _customerTitleController.dispose();
    _contactPhoneController.dispose();
    _contactMobileController.dispose();
    _addressLineOneController.dispose();
    _addressLineTwoController.dispose();
    _cityController.dispose();
    _postalController.dispose();
    _emailController.dispose();
    _remarksController.dispose();
    //resetFileCounts();
    super.dispose();
  }

  void clearTextfield() {
    _accountNumberController.clear();
    _companyNameController.clear();
    _customerLastNameController.clear();
    _customerFirstNameController.clear();
    _customerTitleController.clear();
    _contactPhoneController.clear();
    _contactMobileController.clear();
    _addressLineOneController.clear();
    _addressLineTwoController.clear();
    _cityController.clear();
    _postalController.clear();
    _emailController.clear();
    _remarksController.clear();
    isReadyForAccountOpening = false;
  }

  successComments(response) {
    getCommentsResponse(response);
  }

  successUpdateExisting(response) {
    getUpdateExistingResponse(response);
  }

  failureUpdateExisting(response) {
    getUpdateExistingResponse(response);
  }

  failureComments(response) {
    getCommentsResponse(response);
  }

  success(response) {
    getNewLeadResponse(response);
  }

  failure(response) {
    getNewLeadResponse(response);
  }

  void getUpdateExistingResponse(ApiResponse _apiResponse) {
    AccountExistingUpdate? _newleadresponse = _apiResponse.data;
    switch (_apiResponse.status) {
      case Status.LOADING:
        _loading = true;
        return debugPrint('Loading ...');
      case Status.INITIAL:
        _loading = true;
        break;
      case Status.COMPLETED:
        {
          _loading = false;
          final _message = _newleadresponse?.serviceStatus?.message;
          if (_newleadresponse?.serviceStatus?.status == true) {
            _addCommentsController.clear();
            isAddComments = false;
            final dataMessage = _newleadresponse?.responseData?.data;
            _showUpdateMessageDialog(context, _message, dataMessage);
            newLeadViewModel.fetchExistingAccountLeadDetailsData(
                selectedLeadOID,
                successCallback: success,
                failureCallback: failure);
          }
          return debugPrint(
              'Success... ${_newleadresponse?.serviceStatus?.statusCode}');
        }
      case Status.ERROR:
        _loading = false;
        // ignore: unused_local_variable
        String msg = 'Please try again latter!';
        if (_newleadresponse != null) {
          msg = _newleadresponse.serviceStatus!.message!;
        }
        return debugPrint('Error: Please try again latter!');
    }
  }

  void getNewLeadResponse(ApiResponse _apiResponse) {
    IndividualAccountModel? _newleadresponse = _apiResponse.data;
    switch (_apiResponse.status) {
      case Status.LOADING:
        _loading = true;
        //showLoadingIndicator('Please wait ...');
        return debugPrint('Loading ...');
      case Status.INITIAL:
        _loading = true;

        break;
      case Status.COMPLETED:
        {
          _loading = false;
          // ignore: unused_local_variable
          final _message = _newleadresponse?.serviceStatus?.message;
          if (_newleadresponse?.serviceStatus?.status == true) {
            //
            accountDetailsData =
                _newleadresponse?.responseData?.data?.accountDetails;
            accountComments =
                _newleadresponse?.responseData?.data?.accountComments;
            // Future.delayed(
            //   const Duration(milliseconds: 20),
            //   () {
            getLeadIndividualDetails(accountDetailsData);
            //   },
            // );
          }

          return debugPrint(
              'Success... ${_newleadresponse?.serviceStatus?.statusCode}');
        }
      case Status.ERROR:
        _loading = false;
        // ignore: unused_local_variable
        String msg = 'Please try again latter!';
        if (_newleadresponse != null) {
          msg = _newleadresponse.serviceStatus!.message!;
        }
        return debugPrint('Error: Please try again latter!');
    }
  }

  void getCommentsResponse(ApiResponse _apiResponse) {
    CommentsResponseModel? _newleadresponse = _apiResponse.data;
    switch (_apiResponse.status) {
      case Status.LOADING:
        _loading = true;
        return debugPrint('Loading ...');
      case Status.INITIAL:
        _loading = true;
        break;
      case Status.COMPLETED:
        {
          _loading = false;
          // ignore: unused_local_variable
          final _message = _newleadresponse?.serviceStatus?.message;
          if (_newleadresponse?.serviceStatus?.status == true) {
            _addCommentsController.clear();

            setState(() {
              isViewComments = true;
            });
          }
          return debugPrint(
              'Success... ${_newleadresponse?.serviceStatus?.statusCode}');
        }
      case Status.ERROR:
        _loading = false;
        // ignore: unused_local_variable
        String msg = 'Please try again latter!';
        if (_newleadresponse != null) {
          msg = _newleadresponse.serviceStatus!.message!;
        }
        return debugPrint('Error: Please try again latter!');
    }
  }

  getLeadIndividualDetails(AccountDetails? accountDetails) {
    setState(() {
      _accountNumberController.text = (accountDetails?.accountNumber == 'null'
              ? ' '
              : accountDetails?.accountNumber)!
          .toString();
      _companyNameController.text = (accountDetails?.companyName == 'null'
              ? ''
              : accountDetails?.companyName)!
          .toString();
      _customerLastNameController.text =
          (accountDetails?.lastName == 'null' ? '' : accountDetails?.lastName)!
              .toString();
      _customerFirstNameController.text = (accountDetails?.firstName == 'null'
              ? ''
              : accountDetails?.firstName)!
          .toString();

      _contactPhoneController.text = (accountDetails?.contactPhone == 'null'
              ? ''
              : accountDetails?.contactPhone)!
          .toString();

      _addressLineOneController.text =
          (accountDetails?.address1 == 'null' ? '' : accountDetails?.address1)!
              .toString();

      _addressLineTwoController.text =
          (accountDetails?.address2 == 'null' ? '' : accountDetails?.address2)!
              .toString();

      _cityController.text =
          (accountDetails?.city == 'null' ? '' : accountDetails?.city)!
              .toString();

      _postalController.text = (accountDetails?.postalCode == 'null'
              ? ''
              : accountDetails?.postalCode)!
          .toString();
      _contactMobileController.text = (accountDetails?.contactMobile == 'null'
              ? ''
              : accountDetails?.contactMobile)!
          .toString();

      _chosenValue = (accountDetails?.status != null
          ? getResonCode(accountDetails?.status.toString())
          : 'select'.tr())!;
    });
  }

  Widget richText(String? name, String? name2) {
    return Container(
      margin: const EdgeInsets.only(
        left: 5,
        top: 5,
      ),
      child: RichText(
        text: TextSpan(
          style: const TextStyle(
            color: Colors.black,
          ),
          children: <TextSpan>[
            TextSpan(text: name.toString(), style: Styles.titleTextWithF12W700),
            TextSpan(
                text: name2.toString(),
                style: const TextStyle(color: Colors.red, fontSize: 15)),
          ],
        ),
      ),
    );
  }

  bool? isCountryCodeOptional(String countryCode) {
    if (countryCode == 'HK' || countryCode == 'VN') {
      return true;
    } else {
      return false;
    }
  }

  Future<void> _showUpdateMessageDialog(
      BuildContext ctx, String? message, String? dataMessage) async {
    return showDialog<void>(
      context: ctx,
      barrierDismissible: false, // user must tap button!
      builder: (BuildContext context) {
        return AlertDialog(
          title: Text(Constant.existingAccountsPenetration,
              style: Styles.titleTextWithF20W700),
          content: SingleChildScrollView(
            child: ListBody(
              children: <Widget>[
                // Text(message.toString()),
                Text(dataMessage.toString(),
                    style: Styles.titleTextWithF20W700),
              ],
            ),
          ),
          actions: <Widget>[
            // ElevatedButton(
            //   style: ElevatedButton.styleFrom(primary: xColor),
            //   onPressed: () => Navigator.pop(context, Constant.cancel),
            //   child: const Text(
            //     Constant.cancel,
            //     style: TextStyle(
            //       fontSize: 12,
            //       color: kBackgroundColor,
            //       fontWeight: FontWeight.w700,
            //     ),
            //   ),
            // ),
            ElevatedButton(
              style: ElevatedButton.styleFrom(primary: xColor),
              onPressed: () {
                Navigator.pop(context, Constant.cancel);
              },
              child: const Text(
                Constant.okay,
                style: TextStyle(
                  fontSize: 12,
                  color: kBackgroundColor,
                  fontWeight: FontWeight.w700,
                ),
              ),
            ),
          ],
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    final Map<String, Object?> arg =
        ModalRoute.of(context)!.settings.arguments as Map<String, Object?>;
    selectedLeadOID = arg['leadOID'];
    newLeadViewModel.fetchExistingAccountLeadDetailsData(selectedLeadOID,
        successCallback: success, failureCallback: failure);
    return ScaffoldMessenger(
      key: _scaffoldMessengerKey,
      child: Scaffold(
        appBar: PreferredSize(
            preferredSize:
                const Size.fromHeight(Constant.kStandardAppBarHeight),
            child: CustomHomeAppbar(
              isCheckAppBarButtom: false,
              selectedContext: context,
              checkCurrentPage: 'IndividualAccounts',
            )),
        body: _detailUI(),
      ),
    );
  }

  _detailUI() {
    return StreamBuilder(
        stream: newLeadViewModel.accountDetail,
        builder: (context, AsyncSnapshot<IndividualAccountModel> snapshot) {
          if (snapshot.hasData) {
            final response = snapshot.data;
            if (response?.serviceStatus?.statusCode == 200) {
              return bodyViewWidget(response!);
            } else {
              return Center(child: Text(response!.serviceStatus!.message!));
            }
          } else if (snapshot.hasError) {
            return Center(child: Text(snapshot.error.toString()));
          }
          return const Center(
            child: CircularProgressIndicator(),
          );
        });
  }

  Container bodyViewWidget(IndividualAccountModel accountResponse) {
    String? dateStr =
        accountResponse.responseData?.data?.accountDetails?.lastFollowUpDate;
    final timeDifference =
        _accountPenetrationViewModel.getTimeDifference(dateStr);
    _controller?.duration = Duration(seconds: timeDifference);
    _controller?.forward();
    return Container(
      color: kBackgroundColor,
      margin: const EdgeInsets.all(15),
      child: SingleChildScrollView(
        child: Form(
          key: _formKey,
          child: Padding(
            padding: const EdgeInsets.symmetric(vertical: 0, horizontal: 0),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                const SizedBox(height: 0),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    // SvgPicture.asset('assets/icons/user_profile.svg'),
                    Text(
                      'existing_account_penetration'.tr(),
                      textAlign: TextAlign.start,
                      style: Styles.titleTextWithF26,
                    ),
                    GestureDetector(
                      onTap: () => Navigator.pushNamed(
                          context, AccountsPenetrationPage.routeName),
                      child: Row(
                        children: [
                          SvgPicture.asset(
                            Constant.assetsBackArrow,
                            height: 20,
                            width: 20,
                          ),
                          const SizedBox(width: 5),
                          Text(
                            'back'.tr(),
                            textAlign: TextAlign.start,
                            style: Styles.titleTextWithF26,
                          ),
                        ],
                      ),
                    )
                  ],
                ),
                const SizedBox(height: 15),
                Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Expanded(
                          child: Column(
                        crossAxisAlignment: CrossAxisAlignment.stretch,
                        children: [
                          Text(
                            '${accountResponse.responseData?.data?.accountDetails?.accountId.toString()}',
                            textAlign: TextAlign.start,
                            style: const TextStyle(
                                fontSize: 18, color: kPrimaryColor),
                          ),
                          Text(
                            accountResponse.responseData?.data?.accountDetails
                                    ?.createdTimeStamp!
                                    .toString() ??
                                "",
                            textAlign: TextAlign.start,
                            style: Styles.titleGreyTextWithF12W700,
                          ),
                        ],
                      )),
                    ]),
                const SizedBox(height: 15),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Expanded(
                        child: Column(
                      crossAxisAlignment: CrossAxisAlignment.stretch,
                      children: [
                        Text(
                          'time_left'.tr(),
                          textAlign: TextAlign.start,
                          style: Styles.titleGreyTextWithF12W700,
                        ),
                        Countdown(
                            animation: StepTween(
                              begin: timeDifference,
                              end: 0,
                            ).animate(_controller!),
                            isFromExistingPage: false),
                      ],
                    )),
                    Expanded(
                        child: Column(
                      crossAxisAlignment: CrossAxisAlignment.end,
                      children: [
                        Text(
                          'status'.tr(),
                          textAlign: TextAlign.right,
                          style: Styles.titleGreyTextWithF12W700,
                        ),
                        Text(
                          _accountPenetrationViewModel.checkViewStatus(
                              accountResponse
                                  .responseData?.data?.accountDetails?.status!
                                  .toString()) as String,
                          textAlign: TextAlign.right,
                          style: Styles.titleGreyTextWithF12W700,
                        ),
                      ],
                    )),
                  ],
                ),

                const SizedBox(height: 15),
                //RegExp regExp =  RegExp("[a-zA-Z -]");
                Container(
                  alignment: Alignment.centerLeft,
                  color: xColorlightGrey,
                  child: Column(
                    children: [
                      richText('accountNumber'.tr(), ''),
                      const SizedBox(height: 1),
                    ],
                  ),
                ),

                RoundedTextFormField(
                  readOnly: true,
                  controller: _accountNumberController,
                  maxLines: 1,
                  maxLength: 85,
                  regExp: RegExp(Constant.pattternPostal),
                  textInputType: TextInputType.text,
                  hintText: Constant.accountNumber,
                  prefixIcon: const Icon(Icons.home_work_outlined),
                  // validator: (value) {
                  //   if (value.toString().length < 2) {
                  //     return Constant.pleaseProvideComanyName;
                  //   } else if (value.toString().length > 80) {
                  //     return "Max 80 Characters Are Allowed";
                  //   }

                  //   return null;
                  // },
                  onSaved: (value) {
                    _accountNumber = value!;
                  },
                ),
                Container(
                  alignment: Alignment.centerLeft,
                  color: xColorlightGrey,
                  child: Column(
                    children: [
                      richText('companyName'.tr(), ''),
                      const SizedBox(height: 1),
                    ],
                  ),
                ),

                RoundedTextFormField(
                  readOnly: true,
                  controller: _companyNameController,
                  maxLines: 2,
                  maxLength: 85,
                  regExp: RegExp(Constant.patternChar),
                  textInputType: TextInputType.text,
                  hintText: Constant.companyName,
                  prefixIcon: const Icon(Icons.home_work_outlined),
                  // validator: (value) {
                  //   if (value.toString().length < 2) {
                  //     return Constant.pleaseProvideComanyName;
                  //   } else if (value.toString().length > 80) {
                  //     return "Max 80 Characters Are Allowed";
                  //   }

                  //   return null;
                  // },
                  onSaved: (value) {
                    _companyName = value!;
                  },
                ),
                // const SizedBox(height: 10),
                // Container(
                //   alignment: Alignment.centerLeft,
                //   color: xColorlightGrey,
                //   child: Column(
                //     children: [
                //       richText(Constant.customerTitle, ''),
                //       const SizedBox(height: 1),
                //     ],
                //   ),
                // ),

                // RoundedTextFormField(
                //   readOnly: true,
                //   controller: _customerTitleController,
                //   maxLines: 1,
                //   maxLength: 85,
                //   regExp: RegExp(Constant.patternChar),
                //   textInputType: TextInputType.text,
                //   hintText: Constant.companyName,
                //   prefixIcon: const Icon(Icons.home_work_outlined),
                //   // validator: (value) {
                //   //   if (value.toString().length < 2) {
                //   //     return Constant.pleaseProvideComanyName;
                //   //   } else if (value.toString().length > 80) {
                //   //     return "Max 80 Characters Are Allowed";
                //   //   }

                //   //   return null;
                //   // },
                //   onSaved: (value) {
                //     _companyName = value!;
                //   },
                // ),
                // const SizedBox(height: 10),

                Container(
                  alignment: Alignment.centerLeft,
                  color: xColorlightGrey,
                  child: Column(
                    children: [
                      richText('customerFirstName'.tr(), ''),
                      const SizedBox(height: 1),
                    ],
                  ),
                ),
                RoundedTextFormField(
                  readOnly: true,
                  controller: _customerFirstNameController,
                  maxLines: 1,
                  maxLength: 100,
                  regExp: RegExp(Constant.patternChar),
                  textInputType: TextInputType.name,
                  hintText: Constant.customerFirstName,
                  prefixIcon: const Icon(Icons.supervised_user_circle),
                  // validator: (value) {
                  //   if (value.toString().length < 2) {
                  //     return Constant.pleaseProvideCustomerFirstName;
                  //   } else if (value.toString().length > 60) {
                  //     return "Max 60 Characters Are Allowed";
                  //   }
                  //   return null;
                  // },
                  onSaved: (value) {
                    _customerFirstName = value!;
                  },
                ),
                // const SizedBox(height: 10),
                Container(
                  alignment: Alignment.centerLeft,
                  color: xColorlightGrey,
                  child: Column(
                    children: [
                      richText('customerLastName'.tr(), ''),
                      const SizedBox(height: 1),
                    ],
                  ),
                ),
                RoundedTextFormField(
                  readOnly: true,
                  controller: _customerLastNameController,
                  textInputType: TextInputType.name,
                  maxLines: 1,
                  maxLength: 100,
                  regExp: RegExp(Constant.patternChar),
                  hintText: Constant.customerLastName,
                  prefixIcon: const Icon(Icons.phone),
                  // validator: (value) {
                  //   if (value.toString().length < 2) {
                  //     return Constant.pleaseProvideCustomerLastName;
                  //   } else if (value.toString().length > 60) {
                  //     return "Max 60 Characters Are Allowed";
                  //   }
                  //   return null;
                  // },
                  onSaved: (value) {
                    _customerLastName = value!;
                  },
                ),
                //  const SizedBox(height: 10),

                Container(
                  alignment: Alignment.centerLeft,
                  color: xColorlightGrey,
                  child: Column(
                    children: [
                      richText('telephoneNumber'.tr(), ''),
                      const SizedBox(height: 1),
                    ],
                  ),
                ),
                RoundedTextFormField(
                  readOnly: true,
                  controller: _contactPhoneController,
                  textInputType: TextInputType.phone,
                  maxLines: 1,
                  maxLength: 30,
                  regExp: RegExp(Constant.pattternPhone),
                  hintText: Constant.telephoneNumber,
                  prefixIcon: const Icon(Icons.email_rounded),
                  // validator: (value) {
                  //   // if (newLeadViewModel.validateMobile(value) != null) {
                  //   //   return Constant.pleaseProvideTeleNumber;
                  //   // }
                  //   return null;
                  // },
                  onSaved: (value) {
                    _contactPhone = value!;
                  },
                ),
                //  const SizedBox(height: 10),
                Container(
                  alignment: Alignment.centerLeft,
                  color: xColorlightGrey,
                  child: Column(
                    children: [
                      richText('mobileNumber'.tr(), ''),
                      const SizedBox(height: 1),
                    ],
                  ),
                ),
                RoundedTextFormField(
                  readOnly: true,
                  controller: _contactMobileController,
                  maxLines: 1,
                  maxLength: 15,
                  regExp: RegExp(Constant.pattternPhone),
                  textInputType: TextInputType.phone,
                  hintText: Constant.mobileNumber,
                  prefixIcon: const Icon(Icons.email_rounded),
                  //  validator: null,
                  onSaved: (value) {
                    _contactPhone = value!;
                  },
                ),
                // const SizedBox(height: 10),
                Container(
                  alignment: Alignment.centerLeft,
                  color: xColorlightGrey,
                  child: Column(
                    children: [
                      richText('addressOne'.tr(), ''),
                      const SizedBox(height: 1),
                    ],
                  ),
                ),
                RoundedTextFormField(
                  readOnly: true,
                  controller: _addressLineOneController,
                  textInputType: TextInputType.streetAddress,
                  maxLines: 2,
                  maxLength: 75,
                  regExp: RegExp(Constant.pattternEmail),
                  hintText: Constant.addressOne,
                  prefixIcon: const Icon(Icons.remember_me_outlined),
                  // validator: (value) {
                  //   if (value.toString().length < 2) {
                  //     return Constant.pleaseProvideAddress;
                  //   } else if (value.toString().length > 70) {
                  //     return "Max 70 Characters Are Allowed";
                  //   }
                  //   return null;
                  // },
                  onSaved: (value) {
                    _addressLineOne = value!;
                  },
                ),
                // const SizedBox(height: 10),
                Container(
                  alignment: Alignment.centerLeft,
                  color: xColorlightGrey,
                  child: Column(
                    children: [
                      richText('addressTwo'.tr(), ''),
                      const SizedBox(height: 1),
                    ],
                  ),
                ),
                RoundedTextFormField(
                  readOnly: true,
                  controller: _addressLineTwoController,
                  textInputType: TextInputType.streetAddress,
                  maxLines: 2,
                  maxLength: 70,
                  regExp: RegExp(Constant.pattternEmail),
                  hintText: Constant.addressTwo,
                  prefixIcon: const Icon(Icons.remember_me_outlined),
                  // validator: null,
                  // validator: (value) {
                  //   if (value.toString().length < 2) {
                  //     return Constant.pleaseProvideAddress;
                  //   }
                  //   return null;
                  // },
                  onSaved: (value) {
                    _addressLineTwo = value!;
                  },
                ),
                // const SizedBox(height: 10),
                Container(
                  alignment: Alignment.centerLeft,
                  color: xColorlightGrey,
                  child: Column(
                    children: [
                      richText('city'.tr(), ''),
                      const SizedBox(height: 1),
                    ],
                  ),
                ),
                RoundedTextFormField(
                  readOnly: true,
                  controller: _cityController,
                  textInputType: TextInputType.name,
                  maxLines: 1,
                  maxLength: 100,
                  hintText: Constant.city,
                  regExp: RegExp(Constant.patternChar),
                  prefixIcon: const Icon(Icons.remember_me_outlined),
                  validator: null,
                  onSaved: (value) {
                    _city = value!;
                  },
                ),
                //  const SizedBox(height: 10),

                Container(
                  alignment: Alignment.centerLeft,
                  color: xColorlightGrey,
                  child: Column(
                    children: [
                      richText(
                          'postal'.tr(),
                          isCountryCodeOptional(countryCode) == true
                              ? ''
                              : '*'),
                      const SizedBox(height: 1),
                    ],
                  ),
                ),
                RoundedTextFormField(
                  readOnly: true,
                  controller: _postalController,
                  textInputType: TextInputType.name,
                  maxLines: 1,
                  maxLength: 10,
                  regExp: RegExp(Constant.pattternPostal),
                  hintText: Constant.postal,
                  prefixIcon: const Icon(Icons.remember_me_outlined),
                  // validator: null,
                  onSaved: (value) {
                    _postal = value!;
                  },
                ),

                //  const SizedBox(height: 10),
                Container(
                  alignment: Alignment.centerLeft,
                  color: xColorlightGrey,
                  child: Column(
                    children: [
                      richText('email'.tr(), ''),
                      const SizedBox(height: 1),
                    ],
                  ),
                ),
                RoundedTextFormField(
                  readOnly: true,
                  controller: _emailController,
                  textInputType: TextInputType.emailAddress,
                  maxLines: 1,
                  maxLength: 60,
                  regExp: RegExp(Constant.pattternEmail),
                  hintText: Constant.email,
                  prefixIcon: const Icon(Icons.remember_me_outlined),
                  // validator: (value) {
                  //   // if (newLeadViewModel.validateEmail(value) != null) {
                  //   //   return Constant.pleaseProvideEmail;
                  //   // }
                  //   return null;
                  // },
                  onSaved: (value) {
                    _email = value!;
                  },
                ),
                //   const SizedBox(height: 10),
                Container(
                  alignment: Alignment.centerLeft,
                  color: xColorlightGrey,
                  child: Column(
                    children: [
                      richText('remarks'.tr(), ''),
                      const SizedBox(height: 1),
                    ],
                  ),
                ),
                RoundedTextFormField(
                  readOnly: true,
                  controller: _remarksController,
                  textInputType: TextInputType.multiline,
                  maxLines: 1,
                  maxLength: 500,
                  regExp: RegExp(Constant.pattternEmail),
                  hintText: Constant.remarks,
                  prefixIcon: const Icon(Icons.remember_me_outlined),
                  // validator: null,
                  // validator: (value) {
                  //   if (value.toString().length < 2) {
                  //     return Constant.pleaseProvideRemarks;
                  //   }
                  //   return null;
                  // },
                  onSaved: (value) {
                    _remarks = value!;
                  },
                ),
                const SizedBox(height: 10),
                Visibility(
                  visible: isAddComments ? true : false,
                  child: Column(
                    children: [
                      Container(
                        alignment: Alignment.centerLeft,
                        color: xColorlightGrey,
                        child: Column(
                          children: [
                            richText('add_comments'.tr(), ''),
                            const SizedBox(height: 1),
                          ],
                        ),
                      ),
                      RoundedTextFormField(
                        controller: _addCommentsController,
                        textInputType: TextInputType.multiline,
                        maxLines: 2,
                        maxLength: 500,
                        regExp: RegExp(Constant.pattternEmail),
                        hintText: 'add_comments'.tr(),
                        prefixIcon: const Icon(Icons.remember_me_outlined),
                        validator: (value) {
                          if (value.toString().length < 2) {
                            return 'please_provide_comment'.tr();
                          } else {
                            _addComments = value;
                          }
                          return null;
                        },
                        onSaved: null,
                      ),
                    ],
                  ),
                ),

                const SizedBox(height: 25),
                //Add Comments and View comments

                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    GestureDetector(
                      onTap: () {
                        setState(() {
                          isViewComments = !isViewComments;
                        });
                      },
                      child: Text(
                        'view_all_comments'.tr(),
                        style: Styles.commentTitletBlueWithF14W700,
                      ),
                    ),
                    GestureDetector(
                      onTap: () {
                        setState(() {
                          isAddComments = !isAddComments;
                        });
                      },
                      child: Text(
                        'add_comments'.tr(),
                        style: Styles.commentTitletBlueWithF14W700,
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 10),
                Visibility(
                    visible: isViewComments ? true : false,
                    child: (accountComments == [] || accountComments == null)
                        ? SizedBox(
                            height: 20,
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.center,
                              children: [
                                Text(
                                  'no_comments_available'.tr(),
                                  textAlign: TextAlign.center,
                                  style: Styles.titleBlackTextWithF13W700,
                                )
                              ],
                            ),
                          )
                        : viewAllComments(accountComments)),

                const SizedBox(height: 10),

                Container(
                  padding: const EdgeInsets.all(05.0),
                  decoration: BoxDecoration(
                    color: const Color(0xFFF2F2F2),
                    borderRadius: const BorderRadius.all(Radius.circular(0.0)),
                    border: Border.all(color: Colors.white),
                  ), //
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.stretch,
                    children: [
                      richText('status'.tr(), ''),
                      DropdownButton(
                        alignment: AlignmentDirectional.centerStart,
                        isExpanded: true,
                        underline: const SizedBox(),
                        icon: const Visibility(
                          visible: true,
                          child: Icon(
                            Icons.arrow_drop_down_sharp,
                            color: xColor,
                          ),
                          replacement: SizedBox.shrink(),
                        ),
                        iconSize: 25.55,
                        value: _chosenValue,
                        style: Styles.titleTextWithF14W700,
                        items: newLeadViewModel.statusUpdateList.map((item) {
                          return DropdownMenuItem(
                            value: item.name,
                            child: Container(
                              margin: const EdgeInsets.only(left: 2),
                              child: Text(item.name,
                                  style: Styles.contentStatusW300),
                            ),
                          );
                        }).toList(),
                        hint: Text(_chosenValue!,
                            style: Styles.contentStatusW300),
                        onChanged: (String? value) {
                          setState(() {
                            _chosenValue = value;
                            chosenReason = 'Select';
                            if (_chosenValue == 'rejectToEnrol'.tr()) {
                              isReasonUIVisible = true;
                            } else {
                              isReasonUIVisible = false;
                            }

                            checkStatus(_chosenValue);
                          });
                        },
                      ),
                    ],
                  ),
                ),
                Visibility(
                  visible: isReasonUIVisible,
                  child: Container(
                    padding: const EdgeInsets.all(05.0),
                    decoration: BoxDecoration(
                      color: const Color(0xFFF2F2F2),
                      borderRadius:
                          const BorderRadius.all(Radius.circular(0.0)),
                      border: Border.all(color: Colors.white),
                    ), //
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.stretch,
                      children: [
                        richText('end_reason'.tr(), ''),
                        DropdownButton(
                          alignment: AlignmentDirectional.centerStart,
                          isExpanded: true,
                          underline: const SizedBox(),
                          icon: const Visibility(
                            visible: true,
                            child: Icon(
                              Icons.arrow_drop_down_sharp,
                              color: xColor,
                            ),
                            replacement: SizedBox.shrink(),
                          ),
                          iconSize: 25.55,
                          value: chosenReason,
                          style: Styles.titleTextWithF14W700,
                          items: newLeadViewModel.accountUpdateReasonList
                              .map((item) {
                            return DropdownMenuItem(
                              value: item.name,
                              child: Container(
                                margin: const EdgeInsets.only(left: 2),
                                child: Text(item.name,
                                    style: Styles.contentStatusW300),
                              ),
                            );
                          }).toList(),
                          hint: Text(chosenReason,
                              style: Styles.contentStatusW300),
                          onChanged: (String? value) {
                            setState(() {
                              chosenReason = value!;
                              checkReason(chosenReason);
                            });
                          },
                        ),
                      ],
                    ),
                  ),
                ),

                const SizedBox(height: 10),

                Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    SizedBox(
                      width: 150,
                      height: 30,
                      child: ElevatedButton(
                        style: ButtonStyle(
                          padding: MaterialStateProperty.all<EdgeInsets>(
                              const EdgeInsets.all(10)),
                          foregroundColor:
                              MaterialStateProperty.all<Color>(Colors.white),
                          backgroundColor:
                              MaterialStateProperty.all<Color>(Colors.white),
                          shape:
                              MaterialStateProperty.all<RoundedRectangleBorder>(
                            RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(2.0),
                              side: const BorderSide(color: xColor, width: 1),
                            ),
                          ),
                        ),
                        child: Text(
                          'cancel'.tr(),
                          style: const TextStyle(
                            color: xColor,
                            fontSize: 10,
                            fontWeight: FontWeight.w700,
                          ),
                        ),
                        onPressed: () => Navigator.of(context).pop(),
                      ),
                    ),
                    const SizedBox(width: 10),
                    Visibility(
                      visible: true,
                      child: SizedBox(
                        width: 150,
                        height: 30,
                        child: ElevatedButton(
                          style: ButtonStyle(
                            foregroundColor:
                                MaterialStateProperty.all<Color>(Colors.white),
                            backgroundColor:
                                MaterialStateProperty.all<Color>(xColor),
                            shape: MaterialStateProperty.all<
                                RoundedRectangleBorder>(
                              RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(2.0),
                                side: const BorderSide(color: xColor, width: 1),
                              ),
                            ),
                          ),
                          child: Text(
                            'update'.tr(),
                            style: const TextStyle(
                              fontSize: 10,
                              color: kBackgroundColor,
                              fontWeight: FontWeight.w700,
                            ),
                          ),
                          onPressed: () {
                            if (_chosenValue == Constant.rejectToEnrol &&
                                chosenReason == 'Select') {
                              showSnackBar(context, 'Please select reason');
                              return;
                            }
                            if ((chosenReason == Constant.others) &&
                                (_addComments.isEmpty)) {
                              showSnackBar(context, 'Please provide comments');
                              return;
                            }
                            _showMyDialog(context);
                          },
                        ),
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  WillPopScope viewAllComments(List<AccountComments>? leadComments) {
    return WillPopScope(
      onWillPop: () async => true,
      child: SizedBox(
        height: 150,
        child: CustomScrollView(
          controller: _scrollController,
          slivers: [
            SliverList(
              delegate: SliverChildBuilderDelegate(
                (BuildContext context, int index) {
                  return Container(
                    padding: const EdgeInsets.symmetric(vertical: 5.0),
                    decoration: BoxDecoration(
                      color: index % 2 == 0 ? xColorlightGrey : Colors.white,
                    ),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.stretch,
                      children: [
                        // ignore: unnecessary_null_comparison
                        Text(leadComments![index].commentBy.toString(),
                            textAlign: TextAlign.start,
                            style: Styles.titleTextWithF12W700),
                        Text(leadComments[index].comment.toString(),
                            textAlign: TextAlign.start,
                            style: Styles.titleBlackTextWithF13W700),
                        Text(leadComments[index].commentDate.toString(),
                            textAlign: TextAlign.end,
                            style: Styles.titleTextWithF12W700),
                      ],
                    ),
                  );
                },
                childCount: leadComments?.length,
              ),
            ),
          ],
        ),
      ),
    );
  }

  Future<void> _showMyDialog(BuildContext ctx) async {
    return showDialog<void>(
      context: ctx,
      barrierDismissible: false, // user must tap button!
      builder: (BuildContext context) {
        return AlertDialog(
          title: Text('', style: Styles.titleTextWithF20W700),
          content: SingleChildScrollView(
            child: ListBody(
              children: <Widget>[
                const Text(''),
                Text('are_you_sure'.tr(), style: Styles.titleTextWithF20W700),
              ],
            ),
          ),
          actions: <Widget>[
            ElevatedButton(
              style: ElevatedButton.styleFrom(primary: xColor),
              onPressed: () => Navigator.pop(context, Constant.cancel),
              child: Text(
                'cancel'.tr(),
                style: const TextStyle(
                  fontSize: 12,
                  color: kBackgroundColor,
                  fontWeight: FontWeight.w700,
                ),
              ),
            ),
            ElevatedButton(
              style: ElevatedButton.styleFrom(primary: xColor),
              onPressed: () {
                leadUpdate();
                Navigator.pop(context, Constant.cancel);
              },
              child: Text(
                'submit'.tr(),
                style: const TextStyle(
                  fontSize: 12,
                  color: kBackgroundColor,
                  fontWeight: FontWeight.w700,
                ),
              ),
            ),
          ],
        );
      },
    );
  }

  leadUpdate() {
    // ignore: unused_local_variable
    final isValid = _formKey.currentState!.validate();
    _formKey.currentState!.save();

    Provider.of<IndividualLeadSubmitedViewmodel>(context, listen: false)
        .updateStatusComments(accountDetailsData, _addComments,
            getStatusCode(_chosenValue), getResonCode(chosenReason),
            successCallback: successUpdateExisting,
            failureCallback: failureUpdateExisting);
  }
}

class UploadedFile {
  String? fileType;
  File? filePath;

  UploadedFile({
    this.fileType,
    this.filePath,
  });
}
