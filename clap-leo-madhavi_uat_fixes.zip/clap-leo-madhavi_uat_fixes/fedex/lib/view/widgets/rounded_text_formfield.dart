// ignore_for_file: prefer_typing_uninitialized_variables

import 'package:fedex_app/utility/styles.dart';
import 'package:fedex_app/utility/theme_colors.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

class RoundedTextFormField extends StatelessWidget {
  const RoundedTextFormField({
    Key? key,
    this.controller,
    this.obsecureText = false,
    @required this.hintText,
    this.validator,
    required this.prefixIcon,
    required this.onSaved,
    required this.textInputType,
    required this.maxLines,
    required this.maxLength,
    required this.regExp,
    this.fillColor = xColorlightGrey,
    this.isScreenCheck = false,
    this.readOnly = false,
    this.isUperCase = false,
  }) : super(key: key);

  final TextEditingController? controller;
  final bool? obsecureText;
  final String? hintText;
  final validator;
  final Widget prefixIcon;
  final Function(String?)? onSaved;
  final TextInputType textInputType;
  final int maxLines;
  final int maxLength;
  final RegExp regExp;
  final Color fillColor;
  final bool isScreenCheck;
  final bool readOnly;
  final bool isUperCase;

  // ignore: unused_element
  _text(String str) {
    return Text(
      str,
      style: const TextStyle(fontSize: 12, color: Colors.indigo),
    );
  }

  @override
  Widget build(BuildContext context) {
    return TextFormField(
      key: key,
      readOnly: readOnly,
      autovalidateMode: AutovalidateMode.onUserInteraction,
      maxLines: maxLines,
      controller: controller,
      obscureText: obsecureText!,
      style: Styles.contentTextWithF30W300,
      validator: validator,
      onSaved: onSaved,
      keyboardType: textInputType,
      inputFormatters: [
        LengthLimitingTextInputFormatter(maxLength),
        FilteringTextInputFormatter.allow(regExp),
        UpperCaseTextFormatter(isUperCase),
      ],
      decoration: InputDecoration(
        contentPadding:
            const EdgeInsets.symmetric(vertical: 10.0, horizontal: 8.0),
        labelText: isScreenCheck == true ? hintText : null,
        labelStyle: Styles.titleTextWithF12W700,
        // hintText: hintText!,
        fillColor: fillColor,
        filled: true,
        prefixIcon: null,
        border: InputBorder.none,
        errorStyle: Styles.errorTextFormFieldF12W500,
        // focusedBorder: const OutlineInputBorder(
        //   borderSide: BorderSide(color: kPrimaryColor),
        //   borderRadius: BorderRadius.all(
        //     Radius.circular(5.0),
        //   ),
        // ),
        // enabledBorder: const OutlineInputBorder(
        //   borderSide: BorderSide(color: Colors.grey),
        //   borderRadius: BorderRadius.all(
        //     Radius.circular(5.0),
        //   ),
        // ),
        // errorBorder: const OutlineInputBorder(
        //   borderSide: BorderSide(color: kErrorColor),
        //   borderRadius: BorderRadius.all(
        //     Radius.circular(5.0),
        //   ),s
        // ),
        // focusedErrorBorder: const OutlineInputBorder(
        //   borderSide: BorderSide(color: kErrorColor),
        //   borderRadius: BorderRadius.all(
        //     Radius.circular(5.0),
        //   ),
        // ),
      ),
    );
  }
}

class UpperCaseTextFormatter extends TextInputFormatter {
  final bool isupercase;
  UpperCaseTextFormatter(this.isupercase);
  @override
  TextEditingValue formatEditUpdate(
      TextEditingValue oldValue, TextEditingValue newValue) {
    return TextEditingValue(
      text: isupercase == true ? newValue.text.toUpperCase() : newValue.text,
      selection: newValue.selection,
    );
  }
}

class AlwaseDisableFocuseMode extends FocusNode {
  final bool isFocus;

  AlwaseDisableFocuseMode(this.isFocus);
  bool get hasFocues => isFocus;
}
