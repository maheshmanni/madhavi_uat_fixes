// ignore_for_file: avoid_unnecessary_containers

import 'dart:async';
import 'dart:io';

import 'package:fedex_app/local_notification/notification_service.dart';
import 'package:fedex_app/model/notification_response.dart';
import 'package:fedex_app/utility/apis/api_response.dart';
import 'package:fedex_app/utility/constant.dart';
import 'package:fedex_app/utility/styles.dart';
import 'package:fedex_app/utility/theme_colors.dart';
import 'package:fedex_app/view/accounts_penetration/existing_accounts_penetration.dart';
import 'package:fedex_app/view/accounts_penetration/individual_accounts_penetration.dart';
import 'package:fedex_app/view/lead_submitted/individual_lead_submited.dart';
import 'package:fedex_app/view/lead_submitted/lead_submitted_page.dart';
import 'package:fedex_app/view/home/home_page.dart';
import 'package:fedex_app/view/login_user/auth_okta_service.dart';
import 'package:fedex_app/view/login_user/user_confirmation_page.dart';
import 'package:fedex_app/view/performance/my_performance.dart';
import 'package:fedex_app/viewmodel/custom_appbar_viewmodel.dart';
import 'package:flutter/material.dart';
import 'package:easy_localization/easy_localization.dart';
import 'package:provider/provider.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../new_lead/new_lead_page.dart';

// ignore: must_be_immutable
class CustomHomeAppbar extends StatefulWidget {
  //
  CustomHomeAppbar({
    Key? key,
    this.isCheckAppBarButtom = true,
    this.leadingBtn = true,
    this.selectedContext,
    this.rightMenuSelectedIndex = 0,
    this.checkCurrentPage,
  }) : super(key: key);

  final bool leadingBtn, isCheckAppBarButtom;
  BuildContext? selectedContext;
  final int rightMenuSelectedIndex;
  String? checkCurrentPage;

  @override
  _CustomHomeAppbarState createState() {
    return _CustomHomeAppbarState();
  }
}

class _CustomHomeAppbarState extends State<CustomHomeAppbar> {
  //
  LocalNotificationService localNotificationService =
      LocalNotificationService();
  CustomAppBarViewModel customAppBarViewModel = CustomAppBarViewModel();
  String stationId = "";
  String routeNo = "";
  int? accountLeadOid;

  String selectedLanguage = '';
  int count = 0;

  AuthOktaService? authOktaService;
  //
  @override
  void initState() {
    authOktaService = AuthOktaService.getInstance();
    selectedLanguage = 'EN';
    getStationId().then((value) {
      setState(() {
        stationId = value;
      });
    });

    getRouteNumber().then((value) {
      setState(() {
        routeNo = value;
      });
    });
    //
    getLanguageCode().then((value) {
      setState(() {
        // ignore: unnecessary_null_comparison
        if (value != null) {
          selectedLanguage = value;
        }
      });
    });

    getIsTimer().then((value) {
      setState(() {
        if (value != null) {
          // widget.isCheckNotification == value;

        }
      });
    });
    getAccountLeadOID().then((value) {
      setState(() {
        accountLeadOid = value;
      });
    });

    getNotificationCount().then((value) {
      setState(() {
        // ignore: unnecessary_null_comparison
        if (value != null) {
        } else {
          debugPrint('checkNotification : checkNotification');
        }
      });
    });
    // checkNotification();
    final provider = Provider.of<CustomAppBarViewModel>(context, listen: false);
    provider.checkNotificationTimer();
    provider.read();

    super.initState();
  }

  @override
  void didChangeDependencies() {
    debugPrint('CustomeAppBar');
    getAccountLeadOID().then((value) {
      setState(() {
        accountLeadOid = value;
      });
    });
    super.didChangeDependencies();
  }

  @override
  void dispose() {
    if (customAppBarViewModel.timer != null) {
      customAppBarViewModel.timer!.cancel();
    }

    super.dispose();
  }

  sucess(response) {
    getNitificationDetail(response);
  }

  failure(response) {
    getNitificationDetail(response);
  }

  void getNitificationDetail(ApiResponse _apiResponse) {
    NotificationResponse _newleadresponse = _apiResponse.data;
    switch (_apiResponse.status) {
      case Status.LOADING:
        {
          return debugPrint('Loading ...');
        }
      case Status.COMPLETED:
        {
          debugPrint('UPDATE_EXISTING_COMPLETED ...');
          final provider =
              Provider.of<CustomAppBarViewModel>(context, listen: true);
          provider.read();
          return debugPrint(
              'Success...getNitificationDetail: ${_newleadresponse.serviceStatus?.statusCode}');
        }
      case Status.ERROR:
        // ignore: unused_local_variable
        String msg = 'Please try again latter!';
        // ignore: unnecessary_null_comparison
        if (_newleadresponse != null) {
          msg = _newleadresponse.serviceStatus!.message!;
        }
        return debugPrint('Error: Please try again latter!');
      case Status.INITIAL:
      // break;
    }
  }

  @override
  Widget build(BuildContext context) {
    final provider = Provider.of<CustomAppBarViewModel>(context, listen: true);
    provider.notificationList;
    return AppBar(
      elevation: 0,
      backgroundColor: kPrimaryColor,
      leadingWidth: 115.0,
      leading: widget.leadingBtn
          ? Padding(
              padding: const EdgeInsets.only(left: 15.0),
              child: GestureDetector(
                onTap: () {
                  Navigator.pushNamed(context, HomePageNewPage.routeName);
                },
                child: Container(
                  //color: Colors.amber,
                  child: Image.asset(
                    Constant.logo114,
                    fit: BoxFit.contain,
                    width: 114.0,
                    height: 35.0,
                  ),
                ),
              ),
            )
          : Container(),
      actions: <Widget>[
        languagePopUpButton(),
        const SizedBox(width: 20.0),
        notificationPopUpButton(context, provider),
        rightPopUpButton(),
      ],
      bottom:
          widget.isCheckAppBarButtom == true ? bottomWidget(provider) : null,
    );
  }

  PopupMenuButton languagePopUpButton() {
    return PopupMenuButton<String>(
      onSelected: (value) async {
        setState(() {
          // ignore: unnecessary_null_comparison
          if (value != null) {
            selectedLanguage = value;
            setPreferenceData(value);
          }
        });
        if (value == 'EN') {
          widget.selectedContext!.setLocale(const Locale('en'));
          debugPrint('selected_lang : $value');
        } else if (value == 'JP') {
          widget.selectedContext!.setLocale(const Locale('ja'));
          debugPrint('selected_lang : $value');
        } else if (value == 'CN') {
          widget.selectedContext!.setLocale(
            const Locale.fromSubtags(
                languageCode: "zh",
                scriptCode: "Hant",
                countryCode: "zh_Hans_CN"),
          );
          debugPrint('selected_lang : $value');
        } else if (value == 'HK') {
          widget.selectedContext!.setLocale(
            const Locale.fromSubtags(
                languageCode: "zh",
                scriptCode: "Hant",
                countryCode: "zh_Hans_HK"),
          );
          debugPrint('selected_lang : $value');
        } else if (value == 'ID') {
          widget.selectedContext!.setLocale(const Locale('id'));
          debugPrint('selected_lang : $value');
        } else if (value == 'KR') {
          widget.selectedContext!.setLocale(const Locale('ko'));
          debugPrint('selected_lang : $value');
        } else if (value == 'MY') {
          widget.selectedContext!.setLocale(const Locale('my'));
          debugPrint('selected_lang : $value');
        } else if (value == 'TH') {
          widget.selectedContext!.setLocale(const Locale('th'));
          debugPrint('selected_lang : $value');
        } else if (value == 'TW') {
          widget.selectedContext!.setLocale(
            const Locale.fromSubtags(
                languageCode: "zh",
                scriptCode: "Hant",
                countryCode: "zh_Hans_TW"),
          );
          //lastFollowUpDate
        } else if (value == 'VN') {
          widget.selectedContext!.setLocale(const Locale('vi'));
          debugPrint('selected_lang : $value');
        }
        //
        if (widget.checkCurrentPage == "NEW_LEAD") {
          Navigator.pushReplacementNamed(context, NewLeadPage.routeName);
        } else if (widget.checkCurrentPage == "EXISTING_ACCOUNT") {
          Navigator.pushReplacementNamed(
              context, AccountsPenetrationPage.routeName);
        } else if (widget.checkCurrentPage == "LEAD_SUBMITED") {
          Navigator.pushReplacementNamed(context, LeadSubmittedPage.routeName);
        } else if (widget.checkCurrentPage == "IndividualAccounts") {
          debugPrint('leadOID : ${await getAccountLeadOID()}');
          Navigator.pushReplacementNamed(
              context, IndividualAccountsPenetrationPage.routeName,
              arguments: {'leadOID': await getAccountLeadOID()});
        }
      },
      child: Row(
        mainAxisAlignment: MainAxisAlignment.start,
        children: [
          Text(selectedLanguage,
              style: Styles.titleWhiteTextWithF18W700,
              textAlign: TextAlign.end),
          const SizedBox(
            width: 5.0,
          ),
          Image.asset(
            Constant.downArrowOrange,
            fit: BoxFit.fitWidth,
            width: 14,
            height: 9,
          ),
        ],
      ),
      // onSelected: (item) => handleClick(item),
      // EN:English
      // JP:日本語
      // CN: 简体中文
      // HK:繁體中文
      // TH: ไทย
      // KR: 한국인
      // MY:Bahasa-Melayu
      // VN: Tiếng Việt
      // ID:Bahasa-Indonesia
      itemBuilder: (context) => [
        const PopupMenuItem<String>(value: 'EN', child: Text('EN:English')),
        const PopupMenuItem<String>(value: 'JP', child: Text('JP:日本語')),
        const PopupMenuItem<String>(value: 'CN', child: Text('CN: 简体中文')),
        const PopupMenuItem<String>(value: 'HK', child: Text('HK:繁體中文')),
        const PopupMenuItem<String>(value: 'TH', child: Text('TH: ไทย')),
        const PopupMenuItem<String>(value: 'KR', child: Text('KR: 한국인')),
        const PopupMenuItem<String>(
            value: 'TW', child: Text('TW: Traditional chinese')),
        const PopupMenuItem<String>(
            value: 'MY', child: Text('MY:Bahasa-Melayu')),
        const PopupMenuItem<String>(value: 'VN', child: Text('VN: Tiếng Việt')),
        const PopupMenuItem<String>(
            value: 'ID', child: Text('ID:Bahasa-Indonesia')),
      ],
    );
  }

  notificationPopUpButton(
    context,
    CustomAppBarViewModel provider,
  ) {
    return PopupMenuButton<NData>(
      // icon: const Icon(Icons.menu),
      child: SizedBox(
        width: 44.0,
        height: 44.0,
        child: Stack(
          children: <Widget>[
            Positioned(
              top: 18,
              right: 18,
              child: Image.asset(
                Constant.notification,
                fit: BoxFit.fitWidth,
                width: 18.0,
              ),
            ),
            provider.totalNotificationCount != 0
                ? Positioned(
                    right: 10,
                    top: 8,
                    child: Container(
                      decoration: BoxDecoration(
                        color: xNotificationColor,
                        borderRadius: BorderRadius.circular(9),
                      ),
                      constraints: const BoxConstraints(
                        minWidth: 18,
                        minHeight: 18,
                      ),
                      child: Padding(
                        padding: const EdgeInsets.only(top: 3.0),
                        child: Text(
                          provider.totalNotificationCount.toString(),
                          style: Styles.titleWhiteTextWithF10,
                          textAlign: TextAlign.center,
                        ),
                      ),
                    ),
                  )
                : Container()
          ],
        ),
      ),
      onSelected: (item) {
        selectedNotification(context, provider, item.body, item.leadIOD,
            item.leadNoteOID, item.title, item.type, item.from);
        setState(() {
          //notifactionCount = 0;
          debugPrint('notification_selected_leadIOD: ${item.leadIOD}');
          setNotificationPreferenceData(0);
          setNotificationClearData();
        });
      },
      itemBuilder: (context) {
        List<NData>? notifiList =
            provider.notificationResponse!.responseData!.data;
        return notifiList!.map((item) {
          return PopupMenuItem(
            // onTap: () {
            //   selectedNotification(context, provider, item.body, item.leadIOD,
            //       item.leadNoteOID, item.title, item.type, item.from);
            // },
            textStyle: Styles.titleBlackTextWithF13W700,
            value: item,
            child: notificationWidget(item.body, item.leadIOD, item.leadNoteOID,
                item.title, item.type),
          );
        }).toList();
      },
    );
  }

  notificationWidget(
      String? body, int? leadIOD, leadNoteOID, String? title, String? type) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        const Divider(color: xColorlightGrey, thickness: 2),
        Text(
          title.toString(),
          style: Styles.titleTextWithF14W700,
        ),
        Text(
          body.toString(),
          style: Styles.titleGreyTextWithF08,
        )
      ],
    );
  }

  void selectedNotification(context, provider, String? body, int? leadIOD,
      leadNoteOID, String? title, String? type, String? from) {
    try {
      provider.readNotificationDetails(
          body!, leadIOD, leadNoteOID, title, type, from,
          successCallback: sucess, failureCallback: failure);

      if (from == 'LEAD') {
        debugPrint('notification going to  : $from ...$leadIOD');
        Navigator.pushNamed(context, IndividualLeadSubmitedPage.routeName,
            arguments: {'leadOID': leadIOD});
      } else {
        debugPrint('notification going to  : $from ...$leadIOD');
        Navigator.pushNamed(
            context, IndividualAccountsPenetrationPage.routeName,
            arguments: {'leadOID': leadIOD});
      }

      debugPrint('notification from : $from ...$leadIOD');
    } catch (e) {
      debugPrint('notification error : ${e.toString()}');
    }
  }

  PopupMenuButton rightPopUpButton() {
    return PopupMenuButton<int>(
      icon: const Icon(
        Icons.menu,
        color: Colors.white,
      ),
      onSelected: (item) => handleRightMenuClick(item),
      itemBuilder: (context) => [
        PopupMenuItem<int>(value: 0, child: Text('leadsSubmitted'.tr())),
        PopupMenuItem<int>(
            value: 1, child: Text('existingAccountsPenetration'.tr())),
        PopupMenuItem<int>(value: 2, child: Text('kpiReport'.tr())),
        PopupMenuItem<int>(value: 3, child: Text('logout'.tr())),
      ],
    );
  }

  PreferredSize bottomWidget(CustomAppBarViewModel provider) {
    return PreferredSize(
      preferredSize: const Size.fromHeight(30.0),
      child: Container(
        color: Colors.white,
        child: Column(
          mainAxisAlignment: MainAxisAlignment.start,
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Padding(
              padding: const EdgeInsets.all(12.0),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                mainAxisSize: MainAxisSize.max,
                children: [
                  Expanded(
                    flex: 1,
                    child: Row(
                      children: [
                        Text('stationId'.tr(),
                            overflow: TextOverflow.ellipsis,
                            maxLines: 2,
                            style: Styles.titleGreyTextWithF13),
                        Expanded(
                            child: Text(stationId,
                                style: Styles.titleBlackTextWithF13W700))
                      ],
                    ),
                  ),
                  Expanded(
                      flex: 1,
                      child: Row(
                        children: [
                          Text('routeNumber'.tr(),
                              overflow: TextOverflow.ellipsis,
                              maxLines: 2,
                              style: Styles.titleGreyTextWithF13),
                          Expanded(
                              child: Text(routeNo,
                                  style: Styles.titleBlackTextWithF13W700))
                        ],
                      )),
                  const SizedBox(width: 15),
                  GestureDetector(
                    onTap: () {
                      Navigator.pushReplacementNamed(
                          context, UserConfirmationPage.routeName);
                      if (provider.timer != null) {
                        provider.timer!.cancel();
                        provider.timer!.isActive != provider.timer!.isActive;
                        provider.timer!.isActive == false;

                        debugPrint('Timer : cancel');
                      }
                    },
                    child: Row(
                      children: [
                        ClipRRect(
                          child: Image.asset(
                            Constant.assetsEditIcon,
                            height: 18,
                            width: 18,
                            fit: BoxFit.fill,
                          ),
                        ),
                        const SizedBox(width: 5),
                        Text('edit'.tr(), style: Styles.edittextBlueWithF14W700)
                      ],
                    ),
                  ),
                ],
              ),
            ),
            Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: const [
                Divider(
                  height: 1.0,
                  color: xColorGrey,
                )
              ],
            ),
          ],
        ),
      ),
    );
  }

  setPreferenceData(languagCode) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString('languagCode', '$languagCode');
  }

  setIsTimer(isTimer) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setBool('isTimer', isTimer);
  }

  Future<bool?> getIsTimer() async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.getBool('isTimer');
  }

  setNotificationPreferenceData(notificationCount) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setInt('notificationCount', notificationCount);
  }

  setNotificationClearData() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.remove('notificationCount');
  }

  Future<int> getNotificationCount() async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.getInt('notificationCount')!;
  }

  Future<String> getStationId() async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.getString('stationId')!;
  }

  Future<String> getRouteNumber() async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.getString('routeNumber')!;
  }

  Future<String> getLanguageCode() async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.getString('languagCode')!;
  }

  getAccountLeadOID() async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.getInt('AccountLeadOID') ?? " ";
  }

  handleRightMenuClick(int item) async {
    switch (item) {
      case 0:
        {
          Navigator.pushNamed(
              widget.selectedContext!, LeadSubmittedPage.routeName);
          // if (widget.rightMenuSelectedIndex != 0) {}
        }
        break;
      case 1:
        Navigator.pushNamed(context, AccountsPenetrationPage.routeName);
        break;
      case 2:
        Navigator.pushNamed(context, MyPerformance.routeName,
            arguments: {'tabID': 0});
        break;
      case 3:
        // ignore: void_checks
        authOktaService?.logout().whenComplete(() {
          Navigator.popUntil(context, ModalRoute.withName('/login'));
          exit(0);
        });

        break;
      case 4:
        break;
      case 5:
        break;
      case 6:
        break;
    }
  }
}
