import 'package:easy_localization/easy_localization.dart';
import 'package:fedex_app/utility/styles.dart';
import 'package:fedex_app/utility/theme_colors.dart';
import 'package:flutter/material.dart';

class Countdown extends AnimatedWidget {
  Countdown({Key? key, this.animation, this.isFromExistingPage = true})
      : super(key: key, listenable: animation!);
  final Animation<int>? animation;
  final bool isFromExistingPage;

  @override
  build(BuildContext context) {
    Duration? clockTimer = Duration(seconds: animation?.value ?? 0);
    String? days = clockTimer.inDays.toString();
    //debugPrint('DAYS:  $days');
    String? hours = clockTimer.inHours.remainder(24).toString();
    //debugPrint('HOURS:  $hours');
    String? mins = (clockTimer.inMinutes.remainder(60)).toString();
    // debugPrint('MINS:  $mins');
    //
    // ignore: unused_local_variable
    String? sec =
        (clockTimer.inSeconds.remainder(60) % 60).toString().padLeft(2, '0');
    //debugPrint('SEC:  $sec');
    //
    // String timerText =
    //     '${clockTimer.inHours.remainder(60)}:${clockTimer.inMinutes.remainder(60)}:${(clockTimer.inSeconds.remainder(60) % 60).toString().padLeft(2, '0')}';

    return isFromExistingPage
        ? existingPageTimerRowWidget(context, days, hours, mins)
        : existingDetailPageTimerRowWidget(context, days, hours, mins);
  }

  Row existingPageTimerRowWidget(context, days, hours, mins) {
    return Row(
      children: [
        Expanded(
          child: Column(
            children: [
              const SizedBox(height: 5),
              Text(
                'DAYS'.tr(),
                textAlign: TextAlign.start,
                style: Styles.timeWithF10W400,
              ),
              Container(
                width: MediaQuery.of(context).size.width,
                margin: const EdgeInsets.all(5),
                padding: const EdgeInsets.all(5),
                decoration: const BoxDecoration(
                  color: xColorWhite,
                ),
                child: Text(
                  days,
                  textAlign: TextAlign.center,
                  style: Styles.timeLeftTextWithF20W700,
                ),
              ),
            ],
          ),
        ),
        Expanded(
          child: Column(
            children: [
              const SizedBox(height: 5),
              Text(
                'HRS'.tr(),
                textAlign: TextAlign.start,
                style: Styles.timeWithF10W400,
              ),
              Container(
                width: MediaQuery.of(context).size.width,
                margin: const EdgeInsets.all(5),
                padding: const EdgeInsets.all(5),
                decoration: const BoxDecoration(
                  color: xColorWhite,
                ),
                child: Text(
                  hours,
                  textAlign: TextAlign.center,
                  style: Styles.timeLeftTextWithF20W700,
                ),
              ),
            ],
          ),
        ),
        Expanded(
          child: Column(
            children: [
              const SizedBox(height: 5),
              Text(
                'MINS'.tr(),
                textAlign: TextAlign.start,
                style: Styles.timeWithF10W400,
              ),
              Container(
                width: MediaQuery.of(context).size.width,
                margin: const EdgeInsets.all(5),
                padding: const EdgeInsets.all(5),
                decoration: const BoxDecoration(
                  color: xColorWhite,
                ),
                child: Text(
                  mins,
                  textAlign: TextAlign.center,
                  style: Styles.timeLeftTextWithF20W700,
                ),
              ),
            ],
          ),
        ),
      ],
    );
  }

  Row existingDetailPageTimerRowWidget(context, days, hours, mins) {
    return Row(
      children: [
        Expanded(
          child: Row(
            children: [
              const SizedBox(height: 5),
              Text(
                '$days ',
                textAlign: TextAlign.center,
                style: Styles.textWithblackF15W700,
              ),
              Text(
                'DAYS ',
                textAlign: TextAlign.start,
                style: Styles.timeWithF10W400,
              ),
              Text(
                '$hours ',
                textAlign: TextAlign.center,
                style: Styles.textWithblackF15W700,
              ),
              Text(
                'HRS ',
                textAlign: TextAlign.start,
                style: Styles.timeWithF10W400,
              ),
              Text(
                '$mins ',
                textAlign: TextAlign.center,
                style: Styles.textWithblackF15W700,
              ),
              Text(
                'MINS',
                textAlign: TextAlign.start,
                style: Styles.timeWithF10W400,
              ),
            ],
          ),
        ),
      ],
    );
  }
}
