// ignore_for_file: avoid_unnecessary_containers, implementation_imports

import 'package:easy_localization/src/public_ext.dart';
import 'package:fedex_app/utility/apis/api_response.dart';
import 'package:fedex_app/utility/constant.dart';
import 'package:fedex_app/utility/styles.dart';
import 'package:fedex_app/utility/theme_colors.dart';
import 'package:fedex_app/view/accounts_penetration/existing_accounts_penetration.dart';
import 'package:fedex_app/view/lead_submitted/lead_submitted_page.dart';
// ignore: unused_import
import 'package:fedex_app/view/login_user/auth_okta_service.dart';
import 'package:fedex_app/view/login_user/user_confirmation_page.dart';
import 'package:fedex_app/view/new_lead/new_lead_page.dart';
import 'package:fedex_app/view/performance/my_performance.dart';
import 'package:fedex_app/view/widgets/custom_app_bar.dart';
import 'package:fedex_app/viewmodel/user_view_model.dart';
import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:provider/provider.dart';
import 'package:shared_preferences/shared_preferences.dart';

class HomePageNewPage extends StatefulWidget {
  static String routeName = '/HomePageNewPage';
  // AuthOktaService? authOktaService;

  const HomePageNewPage({Key? key}) : super(key: key);

  @override
  _HomePageNewPageState createState() => _HomePageNewPageState();
}

class _HomePageNewPageState extends State<HomePageNewPage> {
  // ignore: unused_field
  final _formKey = GlobalKey<FormState>();

  // ignore: unused_field
  final _stationIdController = TextEditingController();
  // ignore: unused_field
  final _routeNumberController = TextEditingController();

  var isUserConfirmationDone = false;
  var isNewLeadDropDownVisible = false;
  var isPerformanceDropDownVisible = false;
  String userName = "";

  @override
  void initState() {
    super.initState();
    getUserName().then((value) {
      userName = value;
    });
  }

  @override
  void didChangeDependencies() {
    debugPrint('HomePage');
    super.didChangeDependencies();
  }

  Future<String> getCountryCode() async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.getString('countryCode')!;
  }

  void getUserConfirmationInfo() {
    getCountryCode().then((String value) {
      setState(() {
        if (value.isEmpty) {
          isUserConfirmationDone = false;
        } else {
          isUserConfirmationDone = true;
        }
        //debugPrint('country code is:,$value');
      });
    });
  }

  @override
  Widget build(BuildContext context) {
    ApiResponse apiResponse = Provider.of<UserViewModel>(context).response;
    //gets the user is skip the confirmation of station id.
    getUserConfirmationInfo();

    return ScaffoldMessenger(
      child: Scaffold(
        appBar: PreferredSize(
            preferredSize: const Size.fromHeight(94.0),
            child: CustomHomeAppbar(
              selectedContext: context,
            )),
        body: Container(
          constraints: const BoxConstraints.expand(),
          decoration: const BoxDecoration(
            image: DecorationImage(
                image: AssetImage(Constant.landingBgIcon), fit: BoxFit.fill),
            //color: Colors.amber,
          ),
          child: SingleChildScrollView(
            child: Container(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.start,
                mainAxisSize: MainAxisSize.max,
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  SizedBox(
                    height: 20,
                    child: apiResponse.status == Status.LOADING
                        ? const Center(child: CircularProgressIndicator())
                        : const SizedBox(height: 0),
                  ),
                  middleViewWidget(),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }

  void goToNewLeadSubmitssionPage() {
    Navigator.pushNamed(context, NewLeadPage.routeName);
  }

  void goToUserConfiramtionPage() {
    Navigator.pushNamed(context, UserConfirmationPage.routeName);
  }

  Widget newLeadSubmitDropdownWidget() {
    return Column(
      children: [
        GestureDetector(
          child: Card(
            margin: const EdgeInsets.all(2),
            shape: RoundedRectangleBorder(
                side: const BorderSide(color: xColor, width: 1),
                borderRadius: BorderRadius.circular(1)),
            color: kBackgroundColor,
            child: Padding(
              padding: const EdgeInsets.all(12.0),
              child: Row(
                children: <Widget>[
                  Expanded(
                    flex: 1,
                    child: Container(
                      child: SvgPicture.asset(
                        Constant.newLeadIC,
                        height: 30,
                        width: 30,
                      ),
                    ),
                  ),
                  const SizedBox(width: 5),
                  Expanded(
                    flex: 8,
                    child: Container(
                      child: Text(
                        'SubmitNewLead'.tr(),
                        style: Styles.whiteTextButtonF16W400,
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
          onTap: () {
            isUserConfirmationDone == false
                ? goToUserConfiramtionPage()
                : goToNewLeadSubmitssionPage();
          },
        ),
        GestureDetector(
          child: Card(
            margin: const EdgeInsets.all(2),
            shape: RoundedRectangleBorder(
                side: const BorderSide(color: xColor, width: 1),
                borderRadius: BorderRadius.circular(1)),
            color: kBackgroundColor,
            child: Padding(
              padding: const EdgeInsets.all(12.0),
              child: Row(
                children: <Widget>[
                  Expanded(
                    flex: 1,
                    child: Container(
                      child: SvgPicture.asset(
                        Constant.leadListIC,
                        height: 30,
                        width: 30,
                      ),
                    ),
                  ),
                  const SizedBox(width: 5),
                  Expanded(
                    flex: 8,
                    child: Container(
                      child: Text(
                        'ViewSubmittedLeadList'.tr(),
                        style: Styles.whiteTextButtonF16W400,
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
          onTap: () {
            Navigator.pushNamed(context, LeadSubmittedPage.routeName);
          },
        ),
      ],
    );
  }

  Widget myPerformanceDropdownWidget() {
    return Column(
      children: [
        GestureDetector(
          child: Card(
            margin: const EdgeInsets.all(2),
            shape: RoundedRectangleBorder(
                side: const BorderSide(color: xColor, width: 1),
                borderRadius: BorderRadius.circular(1)),
            color: kBackgroundColor,
            child: Padding(
              padding: const EdgeInsets.all(12.0),
              child: Row(
                children: <Widget>[
                  Expanded(
                    flex: 1,
                    child: Container(
                      child: SvgPicture.asset(
                        Constant.newLeadOrngIC,
                        height: 30,
                        width: 30,
                      ),
                    ),
                  ),
                  const SizedBox(width: 5),
                  Expanded(
                    flex: 8,
                    child: Container(
                      child: Text(
                        'NewLeadSubmission'.tr(),
                        style: Styles.whiteTextButtonF16W400,
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
          onTap: () {
            Navigator.pushNamed(context, MyPerformance.routeName,
                arguments: {'tabID': 0});
          },
        ),
        GestureDetector(
          child: Card(
            margin: const EdgeInsets.all(2),
            shape: RoundedRectangleBorder(
                side: const BorderSide(color: xColor, width: 1),
                borderRadius: BorderRadius.circular(1)),
            color: kBackgroundColor,
            child: Padding(
              padding: const EdgeInsets.all(12.0),
              child: Row(
                children: <Widget>[
                  Expanded(
                    flex: 1,
                    child: Container(
                      child: SvgPicture.asset(
                        Constant.existAcOrngIC,
                        height: 30,
                        width: 30,
                      ),
                    ),
                  ),
                  const SizedBox(width: 5),
                  Expanded(
                    flex: 8,
                    child: Container(
                      child: Text(
                        'existingAccountsPenetration'.tr(),
                        style: Styles.whiteTextButtonF16W400,
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
          onTap: () {
            Navigator.pushNamed(context, MyPerformance.routeName,
                arguments: {'tabID': 1});
          },
        ),
      ],
    );
  }

  void goToPerformancePage(tabId) {
    Navigator.pushNamed(context, MyPerformance.routeName,
        arguments: {'tabID': tabId});
  }

  Future<String> getUserName() async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.getString('userName') ?? "";
  }

  Widget middleViewWidget() {
    return Container(
      margin: const EdgeInsets.only(left: 5, top: 40, right: 5, bottom: 30),
      height: MediaQuery.of(context).size.height,
      // height: 580,
      width: double.infinity,
      //   width: 570,
      //color: Colors.amber,
      child: Stack(
        children: <Widget>[
          Positioned(
            top: 35.0,
            left: 30,
            right: 30.0,
            //width: 450,
            child: Container(
              padding: const EdgeInsets.all(20),
              decoration: const BoxDecoration(
                image: DecorationImage(
                  image: AssetImage(Constant.courierbg),
                  fit: BoxFit.fill,
                ),
              ),
              child: Column(
                mainAxisAlignment: MainAxisAlignment.start,
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  const SizedBox(height: 20),
                  Text('hello'.tr(), style: Styles.titleHelloF12W700),
                  Text(userName, style: Styles.contentTextWithF30W300),
                  const SizedBox(height: 10),
                  GestureDetector(
                    child: Card(
                      margin: const EdgeInsets.all(2),
                      color: xColor,
                      child: Padding(
                        padding: const EdgeInsets.all(12.0),
                        child: Row(
                          children: <Widget>[
                            Expanded(
                              flex: 1,
                              child: Container(
                                child: SvgPicture.asset(
                                  Constant.iconOne,
                                  height: 30,
                                  width: 30,
                                ),
                              ),
                            ),
                            const SizedBox(width: 5),
                            Expanded(
                              flex: 8,
                              child: Container(
                                child: Text(
                                  'NewLeadSubmission'.tr(),
                                  style: Styles.landingButtonF20W400,
                                ),
                              ),
                            ),
                            Expanded(
                              flex: 1,
                              child: Container(
                                child: Icon(
                                  isNewLeadDropDownVisible == false
                                      ? Icons.arrow_forward_ios
                                      : Icons.keyboard_arrow_down_sharp,
                                  color: Colors.white,
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                    onTap: () {
                      setState(() {
                        isNewLeadDropDownVisible = !isNewLeadDropDownVisible;
                      });
                      // Navigator.pushNamed(context, NewLeadPage.routeName);
                    },
                  ),
                  Visibility(
                      visible: isNewLeadDropDownVisible ? true : false,
                      child: newLeadSubmitDropdownWidget()),
                  //   Visibility(
                  // visible: isNewLeadDropDownVisible ? true : false,
                  // isUserConfirmationDone == false
                  //     ? skipUserConfirmationtDropdownWidget()
                  //     : newLeadSubmitDropdownWidget(),
                  //   ),
                  GestureDetector(
                    child: Card(
                      margin: const EdgeInsets.all(2),
                      color: xColor,
                      child: Padding(
                        padding: const EdgeInsets.all(12.0),
                        child: Row(
                          children: <Widget>[
                            Expanded(
                              flex: 1,
                              child: Container(
                                child: SvgPicture.asset(
                                  Constant.iconTwo,
                                  height: 30,
                                  width: 30,
                                ),
                              ),
                            ),
                            const SizedBox(width: 5),
                            Expanded(
                              flex: 8,
                              child: Container(
                                child: Text(
                                  'existingAccountsPenetration'.tr(),
                                  style: Styles.landingButtonF20W400,
                                ),
                              ),
                            ),
                            Expanded(
                              flex: 1,
                              child: Container(
                                child: const Icon(
                                  Icons.arrow_forward_ios,
                                  color: Colors.white,
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                    onTap: () {
                      Navigator.pushNamed(
                          context, AccountsPenetrationPage.routeName);
                    },
                  ),
                  GestureDetector(
                    child: Card(
                      margin: const EdgeInsets.all(2),
                      color: xColor,
                      child: Padding(
                        padding: const EdgeInsets.all(12.0),
                        child: Row(
                          children: <Widget>[
                            Expanded(
                              flex: 1,
                              child: Container(
                                child: SvgPicture.asset(
                                  Constant.iconFive,
                                  height: 30,
                                  width: 30,
                                ),
                              ),
                            ),
                            const SizedBox(width: 5),
                            Expanded(
                              flex: 8,
                              child: Container(
                                child: Text(
                                  'myPerformance'.tr(),
                                  style: Styles.landingButtonF20W400,
                                ),
                              ),
                            ),
                            Expanded(
                              flex: 1,
                              child: Container(
                                child: Icon(
                                  isPerformanceDropDownVisible == false
                                      ? Icons.arrow_forward_ios
                                      : Icons.keyboard_arrow_down_sharp,
                                  color: Colors.white,
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                    onTap: () {
                      setState(() {
                        isPerformanceDropDownVisible =
                            !isPerformanceDropDownVisible;
                      });
                      // Navigator.pushNamed(context, NewLeadPage.routeName);
                    },
                  ),
                  Visibility(
                      visible: isPerformanceDropDownVisible ? true : false,
                      child: myPerformanceDropdownWidget()),
                ],
              ),
            ),
          ),
          // Positioned(
          //   left: MediaQuery.of(context).size.width / 2.0 - 69.0 / 2,
          //   child: SvgPicture.asset(
          //     Constant.userProfileIcon,
          //     width: 138 / 2,
          //     height: 138 / 2,
          //   ),
          // ),
        ],
      ),
    );
  }
}
