// ignore_for_file: implementation_imports, avoid_unnecessary_containers

import 'package:easy_localization/src/public_ext.dart';
import 'package:auto_size_text/auto_size_text.dart';
import 'package:fedex_app/model/lead_list_model.dart';
import 'package:fedex_app/utility/constant.dart';
import 'package:fedex_app/utility/styles.dart';
import 'package:fedex_app/utility/theme_colors.dart';
import 'package:fedex_app/view/new_lead/new_lead_page.dart';
import 'package:fedex_app/view/widgets/custom_app_bar.dart';
import 'package:fedex_app/viewmodel/lead_list_view_model.dart';
import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';

import 'individual_lead_submited.dart';

class LeadSubmittedPage extends StatefulWidget {
  //Map dict;
  static String routeName = '/LeadSubmittedPage';
  const LeadSubmittedPage({Key? key}) : super(key: key);

  @override
  _LeadSubmittedPageState createState() => _LeadSubmittedPageState();
}

enum SingingCharacter { all, status, date }

class _LeadSubmittedPageState extends State<LeadSubmittedPage> {
  final GlobalKey<ScaffoldMessengerState> _scaffoldMessengerKey =
      GlobalKey<ScaffoldMessengerState>();
  final ScrollController _scrollController = ScrollController();
  final _leadListViewModel = LeadListViewModel();
  String? _sortByFilterValue = 'All';
  String? _statusFilterValue = 'All';
  String? _dateFilterValue = '';
  // Default Radio Button Selected Item When App Starts.
  String radioButtonItem = 'ONE';
  String sortByAscDesc = 'DESC';
  bool isAllAscDesc = false;
  bool isStatusAscDesc = false;
  bool isDateAscDesc = false;
  // Group Value for Radio Button.
  int id = 1;
  @override
  void initState() {
    super.initState();
    // read();
  }

  @override
  void didChangeDependencies() {
    //_leadListViewModel.statusFilterList;
    super.didChangeDependencies();
  }

  @override
  Widget build(BuildContext context) {
    _leadListViewModel.read();
    return WillPopScope(
      onWillPop: () async => true,
      child: ScaffoldMessenger(
        key: _scaffoldMessengerKey,
        child: Scaffold(
          appBar: PreferredSize(
              preferredSize:
                  const Size.fromHeight(Constant.kStandardAppBarHeight),
              child: CustomHomeAppbar(
                isCheckAppBarButtom: false,
                selectedContext: context,
                rightMenuSelectedIndex: 0,
                checkCurrentPage: 'LEAD_SUBMITED',
              )),
          body: Container(
            color: Colors.white,
            child: SafeArea(
              bottom: false,
              child: _detailUI(),
            ),
          ),
        ),
      ),
    );
  }

  double _safeAreaTop(BuildContext context) =>
      MediaQuery.of(context).padding.top;

  // ignore: unused_element
  double _safeAreaBottom(BuildContext context) =>
      MediaQuery.of(context).padding.bottom;

  _detailUI() {
    final height = MediaQuery.of(context).size.height;

    return StreamBuilder(
        stream: _leadListViewModel.leadList,
        builder: (context, AsyncSnapshot<LeadListModel> snapshot) {
          if (snapshot.hasData) {
            final response = snapshot.data;
            if (response?.serviceStatus?.statusCode == 200 ||
                response?.serviceStatus?.statusCode == 201) {
              return _buildCustomWidget(response!, height);
            } else {
              return Center(child: Text(response!.serviceStatus!.message!));
            }
          } else if (snapshot.hasError) {
            showSnackBar(context, 'NO DATA FOUND');
            return Center(child: Text(snapshot.error.toString()));
          }
          return const Center(
            child: CircularProgressIndicator(),
          );
        });
  }

  _buildCustomWidget(LeadListModel response, height) {
    return Column(
      children: <Widget>[
        SizedBox(
          height: height -
              Constant.kStandardAppBarHeight -
              _safeAreaTop(context) -
              75,
          child: CustomScrollView(
            controller: _scrollController,
            slivers: [
              SliverPadding(
                padding: const EdgeInsets.all(16.0),
                sliver: SliverToBoxAdapter(
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        'leadsSubmitted'.tr(),
                        style: Styles.titleTextWithF18W700,
                      ),
                      GestureDetector(
                        onTap: () {
                          Navigator.pushNamed(context, NewLeadPage.routeName);
                        },
                        child: Row(
                          children: [
                            ClipRRect(
                              child: Image.asset(
                                Constant.changeIcon,
                                width: 10,
                                height: 12,
                                fit: BoxFit.fitWidth,
                              ),
                            ),
                            const SizedBox(width: 8),
                            Text('createdNewLead'.tr(),
                                style: Styles.editTextBlueWithF14W700)
                          ],
                        ),
                      )
                    ],
                  ),
                ),
              ),
              SliverPadding(
                padding:
                    const EdgeInsets.only(left: 5.0, right: 5.0, bottom: 10.0),
                sliver: SliverToBoxAdapter(
                  child: Container(
                    height: 120.0,
                    color: kPrimaryColor,
                    child: Padding(
                      padding: const EdgeInsets.all(10.0),
                      child: Column(
                        children: [
                          sortByRadioFilter(),
                          const SizedBox(height: 5),
                          Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            crossAxisAlignment: CrossAxisAlignment.center,
                            children: [
                              // filterSortByWidget(),
                              // const SizedBox(
                              //   width: 10.0,
                              // ),
                              filterStatusWidget(),
                              const SizedBox(
                                width: 5.0,
                              ),
                              filterDateWidget(),
                              const SizedBox(
                                width: 5.0,
                              ),
                              filterSubmitButton(),
                            ],
                          ),
                        ],
                      ),
                    ),
                  ),
                ),
              ),
              SliverList(
                delegate: SliverChildBuilderDelegate(
                    (BuildContext context, int index) {
                  //
                  int count =
                      response.responseData!.data!.viewLeadList!.length + 1;
                  //debugPrint('INDEX : $count');
                  //
                  return Container(
                    padding: const EdgeInsets.symmetric(vertical: 15.0),
                    decoration: BoxDecoration(
                      color: index % 2 == 0 ? xColorlightGrey : Colors.white,
                    ),
                    //showSnackBar(context, 'NO DATA FOUND');
                    //listHeaderWidget()
                    //leadListWidget(response.responseData!.data!.viewLeadList![index - 1]),

                    child: index == 0
                        ? count == 1
                            ? listHeaderWidget2()
                            : listHeaderWidget()
                        : leadListWidget(response
                            .responseData!.data!.viewLeadList![index - 1]),
                  );
                },
                    childCount:
                        response.responseData!.data!.viewLeadList!.length + 1 ==
                                1
                            ? 1
                            : response
                                    .responseData!.data!.viewLeadList!.length +
                                1),
              ),
            ],
          ),
        ),
        SizedBox(
          height: 70.0,
          child: paginationWidget(
              response.responseData!.data!.viewLeadPagination!),
        )
      ],
    );
  }

  Expanded sortByRadioFilter() {
    return Expanded(
      child: Row(
        children: <Widget>[
          Text(
            'sortBy'.tr(),
            textAlign: TextAlign.start,
            style: Styles.radioButtonTitle,
          ),
          //SortByRadio filter ALL
          Expanded(
            child: FittedBox(
              child: Row(children: [
                Radio(
                  activeColor: Colors.white,
                  focusColor: Colors.white,
                  value: 1,
                  groupValue: id,
                  onChanged: (val) {
                    setState(() {
                      isStatusAscDesc = false;
                      isDateAscDesc = false;
                      _sortByFilterValue = 'ALL';
                      id = 1;
                      _leadListViewModel.onSortByAll(
                          _sortByFilterValue, sortByAscDesc);
                    });
                  },
                ),
                SizedBox(
                  child: Text(
                    'all'.tr(),
                    style: Styles.radioButtonTitle,
                  ),
                ),
                IconButton(
                    onPressed: () => {
                          setState(() {
                            isStatusAscDesc = false;
                            isDateAscDesc = false;
                            isAllAscDesc = !isAllAscDesc;
                            debugPrint('selected_isAllAscDesc : $isAllAscDesc');
                            isAllAscDesc == true
                                ? sortByAscDesc = 'ASC'
                                : sortByAscDesc = 'DESC';
                            debugPrint(
                                'seected_sortByAscDesc : $sortByAscDesc');
                            _sortByFilterValue = 'ALL';
                            id = 1;
                            _leadListViewModel.onSortByAll(
                                _sortByFilterValue, sortByAscDesc);
                          }),
                        },
                    icon: Icon(
                      isAllAscDesc == true
                          ? Icons.arrow_upward
                          : Icons.arrow_downward,
                      color: Colors.white,
                      size: 20.0,
                    )),
              ]),
            ),
          ),

          //SortByRadio filter STATUS
          Expanded(
            child: FittedBox(
              child: Row(children: [
                Radio(
                  activeColor: Colors.white,
                  focusColor: Colors.white,
                  value: 2,
                  groupValue: id,
                  onChanged: (val) {
                    setState(() {
                      isAllAscDesc = false;
                      isDateAscDesc = false;
                      _sortByFilterValue = 'STATUS';
                      id = 2;
                      _leadListViewModel.onSortByStatus(
                          _sortByFilterValue, sortByAscDesc);
                    });
                  },
                ),
                SizedBox(
                  child: Text(
                    'status'.tr(),
                    style: Styles.radioButtonTitle,
                  ),
                ),
                IconButton(
                    onPressed: () => {
                          setState(() {
                            isAllAscDesc = false;
                            isDateAscDesc = false;
                            isStatusAscDesc = !isStatusAscDesc;
                            isStatusAscDesc == true
                                ? sortByAscDesc = 'ASC'
                                : sortByAscDesc = 'DESC';
                            _sortByFilterValue = 'STATUS';
                            id = 2;
                            _leadListViewModel.onSortByStatus(
                                _sortByFilterValue, sortByAscDesc);
                          }),
                        },
                    icon: Icon(
                      isStatusAscDesc == true
                          ? Icons.arrow_upward
                          : Icons.arrow_downward,
                      color: Colors.white,
                      size: 20.0,
                    )),
              ]),
            ),
          ),

          //SortByRadio filter DATE
          Expanded(
            child: FittedBox(
              child: Row(children: [
                Radio(
                  value: 3,
                  activeColor: Colors.white,
                  focusColor: Colors.white,
                  groupValue: id,
                  onChanged: (val) {
                    setState(() {
                      isStatusAscDesc = false;
                      isAllAscDesc = false;
                      _sortByFilterValue = 'DATE';
                      id = 3;
                      _leadListViewModel.onSortByDate(
                          _sortByFilterValue, sortByAscDesc);
                    });
                  },
                ),
                SizedBox(
                  child: Text(
                    'date'.tr(),
                    style: Styles.radioButtonTitle,
                  ),
                ),
                IconButton(
                    onPressed: () => {
                          setState(() {
                            isStatusAscDesc = false;
                            isAllAscDesc = false;
                            isDateAscDesc = !isDateAscDesc;
                            isDateAscDesc == true
                                ? sortByAscDesc = 'ASC'
                                : sortByAscDesc = 'DESC';
                            _sortByFilterValue = 'DATE';
                            id = 3;
                            _leadListViewModel.onSortByDate(
                                _sortByFilterValue, sortByAscDesc);
                          }),
                        },
                    icon: Icon(
                      isDateAscDesc == true
                          ? Icons.arrow_upward
                          : Icons.arrow_downward,
                      color: Colors.white,
                      size: 20.0,
                    )),
              ]),
            ),
          ),
        ],
      ),
    );
  }

  Widget filterSubmitButton() {
    return Expanded(
      child: GestureDetector(
        child: Card(
          margin: const EdgeInsets.only(bottom: 0, left: 3, top: 14, right: 1),
          color: xColor,
          child: Container(
            height: 35,
            padding: const EdgeInsets.all(5.0),
            child: Row(
              children: <Widget>[
                Expanded(
                  flex: 1,
                  child: Container(
                    child: Text(
                      'submit'.tr(),
                      textAlign: TextAlign.center,
                      style: Styles.titleWhiteTextWithF12W700,
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
        onTap: () {
          debugPrint(_sortByFilterValue);
          debugPrint(_statusFilterValue);
          debugPrint(_dateFilterValue);

          _leadListViewModel.onFilterSubmit(_sortByFilterValue,
              _statusFilterValue, _dateFilterValue, sortByAscDesc);
        },
      ),
    );
  }

  Widget listHeaderWidget() {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16.0),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: <Widget>[
          Expanded(
            child: Text(
              'salesLeadId'.tr(),
              style: Styles.titleGreyTextWithF12W700,
            ),
          ),
          Expanded(
            child: Text(
              'companyName'.tr(),
              style: Styles.titleGreyTextWithF12W700,
            ),
          ),
          Expanded(
            child: Text(
              'status'.tr(),
              style: Styles.titleGreyTextWithF12W700,
            ),
          ),
          Expanded(
            child: Text(
              'remarks'.tr(),
              style: Styles.titleGreyTextWithF12W700,
            ),
          ),
        ],
      ),
    );
  }

  Widget listHeaderWidget2() {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16.0),
      child: Column(
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: <Widget>[
              Expanded(
                child: Text(
                  'salesLeadId'.tr(),
                  style: Styles.titleGreyTextWithF12W700,
                ),
              ),
              Expanded(
                child: Text(
                  'companyName'.tr(),
                  style: Styles.titleGreyTextWithF12W700,
                ),
              ),
              Expanded(
                child: Text(
                  'status'.tr(),
                  style: Styles.titleGreyTextWithF12W700,
                ),
              ),
              Expanded(
                child: Text(
                  'remarks'.tr(),
                  style: Styles.titleGreyTextWithF12W700,
                ),
              ),
            ],
          ),
          const SizedBox(height: 50),
          errorMessageShow(),
        ],
      ),
    );
  }

  Widget leadListWidget(ViewLeadList viewLead) {
    final leadId = viewLead.leadId;
    final dateStr = viewLead.createdDate;
    final company = viewLead.companyName;
    final status = _leadListViewModel.checkStatus(viewLead.leadStatus);
    final remark = viewLead.remark;
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16.0),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: <Widget>[
          Expanded(
            child: GestureDetector(
              onTap: () => Navigator.pushNamed(
                  context, IndividualLeadSubmitedPage.routeName,
                  arguments: {'leadOID': viewLead.leadOID}),
              child: Column(
                mainAxisAlignment: MainAxisAlignment.start,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  AutoSizeText(
                    leadId ?? "",
                    style: Styles.titleTextPrimaryF12W700,
                    textAlign: TextAlign.left,
                    maxLines: 1,
                    minFontSize: 10,
                    overflow: TextOverflow.ellipsis,
                  ),
                  AutoSizeText(
                    dateStr ?? "",
                    style: Styles.titleGreyTextWithF8,
                    textAlign: TextAlign.left,
                    minFontSize: 8,
                    maxLines: 2,
                  )
                ],
              ),
            ),
          ),
          Expanded(
            child: AutoSizeText(
              company ?? "",
              style: Styles.titleGreyTextWithF12,
              textAlign: TextAlign.left,
              maxLines: 2,
              minFontSize: 10,
              overflow: TextOverflow.ellipsis,
            ),
          ),
          Expanded(
            child: AutoSizeText(
              status ?? "",
              style: Styles.titleGreyTextWithF12,
              textAlign: TextAlign.left,
              maxLines: 2,
              minFontSize: 10,
              overflow: TextOverflow.ellipsis,
            ),
          ),
          Expanded(
            child: AutoSizeText(
              remark ?? "",
              style: Styles.titleGreyTextWithF12,
              textAlign: TextAlign.left,
              maxLines: 4,
              minFontSize: 10,
              overflow: TextOverflow.ellipsis,
            ),
          ),
        ],
      ),
      //   SizedBox(height: 16.0),
      // ],
      //),
    );
  }

  Widget errorMessageShow() {
    debugPrint('Error_message');
    return Container(
      alignment: Alignment.center,
      height: 20,
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 15.0),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          crossAxisAlignment: CrossAxisAlignment.center,
          children: <Widget>[
            Expanded(
              flex: 1,
              child: Text(
                'NO DATA FOUND',
                style: Styles.errorTextFormFieldF12W500,
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget filterSortByWidget() {
    return Expanded(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            'sortBy'.tr(),
            style: Styles.titleWhiteTextWithF12W700,
          ),
          const SizedBox(
            height: 2,
          ),
          Container(
            height: 35.0,
            margin: const EdgeInsets.all(0.0),
            padding: const EdgeInsets.all(5.0),
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: const BorderRadius.all(Radius.circular(0.0)),
              border: Border.all(color: Colors.white),
            ), //
            child: DropdownButton<String>(
              alignment: AlignmentDirectional.centerStart,
              isExpanded: true,
              underline: const SizedBox(),
              icon: Visibility(
                visible: true,
                child: Image.asset(
                  Constant.dropDownGreyIcon,
                  fit: BoxFit.contain,
                  width: 11.0,
                  height: 6.0,
                ),
                replacement: const SizedBox.shrink(),
              ),
              // iconSize: 25.55,
              value: _sortByFilterValue,
              style: Styles.titleTextWithF12W700,
              items: <String>[
                'All',
                'Status',
                'Date',
              ].map<DropdownMenuItem<String>>((String value) {
                return DropdownMenuItem<String>(
                  value: value,
                  child: Text(value, style: Styles.titleGreyTextWithF12),
                );
              }).toList(),
              hint: Text('All', style: Styles.titleGreyTextWithF12),
              onChanged: (value) {
                setState(() {
                  _sortByFilterValue = value!;
                  //_leadListViewModel.onSelectSortBy(value);
                });
              },
            ),
          ),
        ],
      ),
    );
  }

  Widget filterStatusWidget() {
    return Expanded(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            'status'.tr(),
            style: Styles.titleWhiteTextWithF12W700,
          ),
          const SizedBox(
            height: 2,
          ),
          Container(
            height: 35.0,
            margin: const EdgeInsets.all(0.0),
            padding: const EdgeInsets.all(5.0),
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: const BorderRadius.all(Radius.circular(0.0)),
              border: Border.all(color: Colors.white),
            ), //
            child: DropdownButton<String>(
              alignment: AlignmentDirectional.centerStart,
              isExpanded: true,
              underline: const SizedBox(),
              icon: Visibility(
                visible: true,
                child: Image.asset(
                  Constant.dropDownGreyIcon,
                  fit: BoxFit.contain,
                  width: 11.0,
                  height: 6.0,
                ),
                replacement: const SizedBox.shrink(),
              ),
              //iconSize: 25.55,
              value: _statusFilterValue,
              style: Styles.titleTextWithF12W700,
              items: _leadListViewModel.statusFilterList
                  .map<DropdownMenuItem<String>>((Status value) {
                return DropdownMenuItem<String>(
                  value: value.id,
                  child: Text(value.name, style: Styles.titleGreyTextWithF08),
                );
              }).toList(),
              hint: Text('All', style: Styles.titleGreyTextWithF08),
              onChanged: (value) {
                setState(() {
                  _statusFilterValue = value!;
                  //_leadListViewModel.onselectStatus(value);
                });
              },
            ),
          ),
        ],
      ),
    );
  }

  Widget filterDateWidget() {
    return Expanded(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            'date'.tr(),
            style: Styles.titleWhiteTextWithF12W700,
          ),
          const SizedBox(
            height: 2,
          ),
          GestureDetector(
            onTap: () {
              debugPrint('tap pickr');
              _leadListViewModel.getDateTimeFromPicker(context).then((value) {
                setState(() {
                  _dateFilterValue = value;
                  debugPrint(_dateFilterValue);
                  // _leadListViewModel.onSelectDate(value);
                });
              });
            },
            child: Container(
              height: 35.0,
              margin: const EdgeInsets.all(0.0),
              padding: const EdgeInsets.all(5.0),
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: const BorderRadius.all(Radius.circular(0.0)),
                border: Border.all(color: Colors.white),
              ), //

              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  Text(
                    _dateFilterValue!,
                    style: Styles.titleTextWithF11W700,
                  ),
                  Visibility(
                    visible: _dateFilterValue == '' ? false : true,
                    child: GestureDetector(
                      onTap: () {
                        setState(() {
                          _dateFilterValue = "";
                        });
                      },
                      child: const Icon(Icons.highlight_remove_sharp, size: 15),
                    ),
                  ),
                  Visibility(
                    visible: true,
                    child: Image.asset(
                      Constant.calenderIcon,
                      fit: BoxFit.contain,
                      width: 15.0,
                      height: 15.0,
                    ),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget paginationWidget(ViewLeadPagination leadPagination) {
    _leadListViewModel.paginationCalulation(leadPagination);
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 15.0),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.start,
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          Text(
            'rows_per_page'.tr(),
            style: Styles.titleGreyTextWithF12W700,
          ),
          const SizedBox(
            width: 5,
          ),
          Container(
            width: 50.0,
            height: 30.0,
            padding: const EdgeInsets.all(5.0),
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: const BorderRadius.all(Radius.circular(0.0)),
              border: Border.all(color: xColorGrey),
            ), //
            child: DropdownButton<int>(
              alignment: AlignmentDirectional.centerStart,
              isExpanded: true,
              underline: const SizedBox(),
              icon: Visibility(
                visible: true,
                child: Image.asset(
                  Constant.dropDownGreyIcon,
                  fit: BoxFit.contain,
                  width: 10.0,
                  height: 10.0,
                ),
                replacement: const SizedBox.shrink(),
              ),
              // iconSize: 25.55,
              value: _leadListViewModel.selectedPageSize,
              style: Styles.titleTextWithF12W700,
              items: _leadListViewModel.pageSizeArr
                  .map<DropdownMenuItem<int>>((value) {
                return DropdownMenuItem<int>(
                  value: value,
                  child: Text('$value', style: Styles.titleGreyTextWithF12),
                );
              }).toList(),
              // hint: Text('',
              //     style: Styles.titleGreyTextWithF12),
              onChanged: (value) {
                _leadListViewModel.onSelectPageSize(value!);
              },
            ),
          ),
          const SizedBox(width: 10),
          Text(
            '${_leadListViewModel.fromPageSize} to ${_leadListViewModel.toPageSize} of ${leadPagination.totalRecords}',
            style: Styles.titleGreyTextWithF12W700,
          ),
          const SizedBox(width: 10),
          Expanded(
              child: Row(
            mainAxisAlignment: MainAxisAlignment.end,
            children: [
              GestureDetector(
                  onTap: () {
                    if (_leadListViewModel.pageNumber != 1) {
                      _leadListViewModel.onSelectFirstPage();
                    }
                  },
                  child: SvgPicture.asset(
                    Constant.firstArrowIcon,
                    width: 8,
                    height: 12,
                    fit: BoxFit.fitWidth,
                    color: _leadListViewModel.pageNumber != 1
                        ? xColorDarkGrey
                        : xColorGrey,
                  )),
              const SizedBox(width: 15),
              GestureDetector(
                  onTap: () {
                    if (_leadListViewModel.pageNumber != 1) {
                      _leadListViewModel.onSelectPreviousPage();
                    }
                  },
                  child: SizedBox(
                    child: Image.asset(
                      Constant.leftArrowIcon,
                      width: 8,
                      height: 12,
                      fit: BoxFit.fitWidth,
                      color: _leadListViewModel.pageNumber != 1
                          ? xColorDarkGrey
                          : xColorGrey,
                    ),
                  )),
              const SizedBox(width: 20),
              GestureDetector(
                  onTap: () {
                    if (_leadListViewModel.pageNumber !=
                        _leadListViewModel.getLastPageNumber()) {
                      _leadListViewModel.onSelectNextPage();
                    }
                  },
                  child: SizedBox(
                    child: Image.asset(
                      Constant.rightArrowIcon,
                      width: 8,
                      height: 12,
                      fit: BoxFit.fitWidth,
                      color: _leadListViewModel.pageNumber !=
                              _leadListViewModel.getLastPageNumber()
                          ? xColorDarkGrey
                          : xColorGrey,
                    ),
                  )),
              const SizedBox(width: 15),
              GestureDetector(
                  onTap: () {
                    if (_leadListViewModel.pageNumber !=
                        _leadListViewModel.getLastPageNumber()) {
                      _leadListViewModel.onSelectLastPage();
                    }
                  },
                  child: SvgPicture.asset(
                    Constant.lastArrowIcon,
                    width: 8,
                    height: 12,
                    fit: BoxFit.fitWidth,
                    color: _leadListViewModel.pageNumber !=
                            _leadListViewModel.getLastPageNumber()
                        ? xColorDarkGrey
                        : xColorGrey,
                  )),
            ],
          )),
        ],
      ),
    );
  }

  @override
  void dispose() {
    _scrollController.dispose();
    _leadListViewModel.dispose();
    super.dispose();
  }

  showSnackBar(BuildContext context, String text) {
    _scaffoldMessengerKey.currentState!.showSnackBar(
      SnackBar(
        behavior: SnackBarBehavior.floating,
        backgroundColor: Colors.red,
        content: Text(text, style: Styles.titleWhiteTextWithF12W700),
      ),
    );
  }
}
