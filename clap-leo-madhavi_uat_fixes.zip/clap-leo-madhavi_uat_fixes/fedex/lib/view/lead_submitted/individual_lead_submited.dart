// ignore_for_file: unnecessary_null_comparison, implementation_imports, unused_field

import 'dart:convert';
import 'dart:typed_data';
import 'package:easy_localization/src/public_ext.dart';
import 'package:fedex_app/model/add_comments.dart';
import 'package:fedex_app/model/individual_lead_model.dart';
import 'package:fedex_app/utility/apis/api_response.dart';
import 'package:fedex_app/utility/constant.dart';
import 'package:fedex_app/utility/styles.dart';
import 'package:fedex_app/utility/theme_colors.dart';
import 'package:fedex_app/view/widgets/custom_app_bar.dart';
import 'package:fedex_app/viewmodel/individual_lead_viewmodel.dart';
import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:provider/provider.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../../model/file_download.dart';
import '../widgets/rounded_text_formfield.dart';
import 'dart:io';

class IndividualLeadSubmitedPage extends StatefulWidget {
  static String routeName = '/individualLeadSubmitedPage';
  const IndividualLeadSubmitedPage({Key? key}) : super(key: key);

  @override
  _IndividualLeadSubmitedPageState createState() =>
      _IndividualLeadSubmitedPageState();
}

class _IndividualLeadSubmitedPageState
    extends State<IndividualLeadSubmitedPage> {
  final _formKey = GlobalKey<FormState>();
  final GlobalKey<ScaffoldMessengerState> _scaffoldMessengerKey =
      GlobalKey<ScaffoldMessengerState>();

  final newLeadViewModel = IndividualLeadSubmitedViewmodel();

  final _companyNameController = TextEditingController();
  final _customerLastNameController = TextEditingController();
  final _customerFirstNameController = TextEditingController();
  final _customerTitleController = TextEditingController();
  final _contactPhoneController = TextEditingController();
  final _contactMobileController = TextEditingController();
  final _addressLineOneController = TextEditingController();
  final _addressLineTwoController = TextEditingController();
  final _cityController = TextEditingController();
  final _postalController = TextEditingController();
  final _emailController = TextEditingController();
  final _remarksController = TextEditingController();
  final _addCommentsController = TextEditingController();

  var _companyName = '';
  var _customerLastName = '';
  var _customerFirstName = '';
  final _customerTitle = '';
  var _contactPhone = '';
  var _addressLineOne = '';
  var _addressLineTwo = '';
  var _city = '';
  var _postal = '';
  var _email = '';
  var _remarks = '';
  var _addComments = '';
  var endRessoneStatus = '';
  final ScrollController _scrollController = ScrollController();
  String? _radioValue; //Initial definition of radio button value
  String? choice;
  bool? isReadyForAccountOpening = false;
  bool? isCheckedAttachement = false;
  String? _imageFilePath;
  String? _chosenValue;
  bool isViewComments = false;
  bool isAddComments = false;
  final List<UploadedFile> _imageFilePathList = [];

  bool isUploadedFiles = false;
  int count = 0;
  final bool _autovalidate = false;
  final bool _isAttachementButtonDisabled = false;
  int businesAttachCount = 0,
      acOpenAttachCount = 0,
      businesCardAttachCount = 0,
      otherAttachCount = 0;
  bool _loading = false;
  List<String> tempList = [];
  String stationId = "";
  String routeNo = "";
  String countryCode = "";
  int maxPostalCodeLength = 0;
  bool isHeaderError = false;
  bool isImageVisiable = false;
  Uint8List? _byteImage;

  String? leadId;
  String? companyName = '';
  String? firstName = '';
  String? lastName = '';
  String? contactPhone = '';
  Object? contactMobile = '';
  String? email = '';
  String? customerTitle = '';
  String? city = '';
  String? address1 = '';
  String? address2 = '';
  String? postalCode = '';
  String? remark = '';
  String? submitterUserId = '';
  String? submitterUserName = '';
  String? locationCode = '';
  String? routerNumber = '';
  String? createdTimeStamp = '';
  String? status = '';
  String? endReason = '';
  String? statusTimeStamp = '';
  String? salesId = '';
  String? managerId = '';
  String? accountNumber = '';
  dynamic selectedLeadOID;
  // ignore: non_constant_identifier_names
  String _LeadId = '';
  LeadDetails? leadDetails;
  List<LeadComments>? leadCommentsList = [];

  void radioButtonChanges(String? value) {
    setState(() {
      _radioValue = value;
      switch (value) {
        case 'YES':
          choice = value;
          break;
        case 'NO':
          choice = value;
          break;
        default:
          choice = null;
      }
      debugPrint(choice); //Debug the choice in console
    });
  }

  void checkboxnChanges(bool? value) {
    setState(() {
      isReadyForAccountOpening = value;
      debugPrint(choice); //Debug the choice in console
    });
  }

  @override
  void initState() {
    Future.delayed(const Duration(milliseconds: 100), () {});
    debugPrint('BYTE-IMAGE : $_byteImage');
    isImageVisiable = false;
    getCountryCode().then((value) {
      setState(() {
        if (value == 'HK') {
          countryCode = value;
          maxPostalCodeLength = 6;
        } else if (value == 'JP') {
          countryCode = value;
          maxPostalCodeLength = 7;
        } else if (value == 'CN') {
          countryCode = value;
          maxPostalCodeLength = 6;
        } else if (value == 'TW') {
          countryCode = value;
          maxPostalCodeLength = 6;
        } else if (value == 'TH') {
          countryCode = value;
          maxPostalCodeLength = 5;
        } else if (value == 'KR') {
          countryCode = value;
          maxPostalCodeLength = 5;
        } else if (value == 'SG') {
          countryCode = value;
          maxPostalCodeLength = 6;
        } else if (value == 'MY') {
          countryCode = value;
          maxPostalCodeLength = 6;
        } else if (value == 'PH') {
          countryCode = value;
          maxPostalCodeLength = 6;
        } else if (value == 'VN') {
          countryCode = value;
          maxPostalCodeLength = 6;
        } else if (value == 'ID') {
          countryCode = value;
          maxPostalCodeLength = 6;
        } else if (value == 'AU') {
          countryCode = value;
          maxPostalCodeLength = 6;
        } else if (value == 'NG') {
          countryCode = value;
          maxPostalCodeLength = 6;
        } else {
          maxPostalCodeLength = 6;
        }

        //countryCode = value;
      });
    });

    getStationId().then((value) {
      setState(() {
        stationId = value;
      });
    });
    getRouteNumber().then((value) {
      setState(() {
        routeNo = value;
      });
    });
    super.initState();
  }

  void showSnackBar(BuildContext context, String text) {
    _scaffoldMessengerKey.currentState!.showSnackBar(
      SnackBar(
        behavior: SnackBarBehavior.floating,
        backgroundColor: Colors.red,
        content: Text(text, style: Styles.titleWhiteTextWithF12W700),
      ),
    );
  }

  Future<String> getStationId() async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.getString('stationId')!;
  }

  Future<String> getRouteNumber() async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.getString('routeNumber')!;
  }

  Future<String> getCountryCode() async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.getString('countryCode')!;
  }

  @override
  void didChangeDependencies() {
    Future.delayed(const Duration(milliseconds: 100), () {
      newLeadViewModel.fetchLeadDetailsData(selectedLeadOID.toString(),
          successCallback: success, failureCallback: failure);
    });
    newLeadViewModel.statusUpdateList;
    super.didChangeDependencies();
  }

  @override
  void dispose() {
    _imageFilePathList.clear();
    _companyNameController.dispose();
    _customerLastNameController.dispose();
    _customerFirstNameController.dispose();
    _customerTitleController.dispose();
    _contactPhoneController.dispose();
    _contactMobileController.dispose();
    _addressLineOneController.dispose();
    _addressLineTwoController.dispose();
    _cityController.dispose();
    _postalController.dispose();
    _emailController.dispose();
    _remarksController.dispose();
    //resetFileCounts();
    super.dispose();
  }

  void clearTextfield() {
    _companyNameController.clear();
    _customerLastNameController.clear();
    _customerFirstNameController.clear();
    _customerTitleController.clear();
    _contactPhoneController.clear();
    _contactMobileController.clear();
    _addressLineOneController.clear();
    _addressLineTwoController.clear();
    _cityController.clear();
    _postalController.clear();
    _emailController.clear();
    _remarksController.clear();
    isReadyForAccountOpening = false;
  }

  successComments(response) {
    getCommentsResponse(response);
  }

  failureComments(response) {
    getCommentsResponse(response);
  }

  success(response) {
    getNewLeadResponse(response);
  }

  failure(response) {
    getNewLeadResponse(response);
  }

  successDocCallback(response) {
    getFileDownloadResponse(response);
  }

  failureDocCallback(response) {}

  void getFileDownloadResponse(ApiResponse _apiResponse) {
    FileDownloadResponse? _newleadresponse = _apiResponse.data;
    switch (_apiResponse.status) {
      case Status.LOADING:
        return debugPrint('Loading ...');
      case Status.INITIAL:
        break;
      case Status.COMPLETED:
        {
          debugPrint('COMPLETED ...');
          // ignore: unused_local_variable
          final _message = _newleadresponse?.serviceStatus?.message;
          final blobString = _newleadresponse?.responseData?.data?.blob;
          //Fluttertoast.showToast(msg: "$_message");
          debugPrint('FILE_STRING ... ${blobString.toString()}');
          setState(() {
            _byteImage = const Base64Decoder().convert(blobString.toString());
            isImageVisiable = true;
          });

          //newLeadViewModel.imageSaveInGallery(blobString.toString());
          return debugPrint(
              'Success... ${_newleadresponse?.responseData?.data}');
        }
      case Status.ERROR:
        // ignore: unused_local_variable
        String msg = 'Please try again latter!';
        if (_newleadresponse != null) {
          msg = _newleadresponse.serviceStatus!.message!;
        }
        return debugPrint('Error: Please try again latter!');
    }
  }

  void getNewLeadResponse(ApiResponse _apiResponse) {
    IndividualLeadResponse? _newleadresponse = _apiResponse.data;
    switch (_apiResponse.status) {
      case Status.LOADING:
        _loading = true;
        //showLoadingIndicator('Please wait ...');
        return debugPrint('Loading ...');
      case Status.INITIAL:
        _loading = true;

        break;
      case Status.COMPLETED:
        {
          _loading = false;
          // ignore: unused_local_variable
          final _message = _newleadresponse?.serviceStatus?.message;
          if (_newleadresponse?.serviceStatus?.status == true) {
            //
            leadDetails = _newleadresponse?.responseData?.data?.leadDetails;
            leadCommentsList =
                _newleadresponse?.responseData?.data?.leadComments;
            setState(() {
              //isViewComments = true;
            });
            //Get LeadIndividual Details
            getLeadIndividualDetails(leadDetails);
          }

          return debugPrint(
              'Success... ${_newleadresponse?.responseData?.data}');
        }
      case Status.ERROR:
        _loading = false;
        // ignore: unused_local_variable
        String msg = 'Please try again latter!';
        if (_newleadresponse != null) {
          msg = _newleadresponse.serviceStatus!.message!;
        }
        return debugPrint('Error: Please try again latter!');
    }
  }

  void getCommentsResponse(ApiResponse _apiResponse) {
    CommentsResponseModel? _newleadresponse = _apiResponse.data;
    switch (_apiResponse.status) {
      case Status.LOADING:
        _loading = true;
        return debugPrint('Loading ...');
      case Status.INITIAL:
        _loading = true;
        break;
      case Status.COMPLETED:
        {
          _loading = false;
          // ignore: unused_local_variable
          final _message = _newleadresponse?.serviceStatus?.message;
          // debugPrint('CommentsRespons  : $_message');
          if (_newleadresponse?.serviceStatus?.status == true) {
            _addCommentsController.clear();
            isAddComments = false;
            List<LeadComments>? newCommentList =
                _newleadresponse?.responseData?.data?.leadComments;
            setState(() {
              leadCommentsList!.add(newCommentList![0]);
              isViewComments = true;
            });

            debugPrint('List: {$newCommentList}');
          }
          return debugPrint(
              'Success... ${_newleadresponse?.responseData?.data}');
        }
      case Status.ERROR:
        _loading = false;
        // ignore: unused_local_variable
        String msg = 'Please try again latter!';
        if (_newleadresponse != null) {
          msg = _newleadresponse.serviceStatus!.message!;
        }
        return debugPrint('Error: Please try again latter!');
    }
  }

  getLeadIndividualDetails(LeadDetails? leadDetails) {
    leadId = leadDetails?.leadId;
    companyName = leadDetails?.companyName;
    firstName = leadDetails?.firstName;
    lastName = leadDetails?.lastName;
    contactPhone = leadDetails?.contactPhone;
    contactMobile = leadDetails?.contactMobile;
    email = leadDetails?.email;
    customerTitle = leadDetails?.customerTitle;
    city = leadDetails?.city;
    address1 = leadDetails?.address1;
    address2 = leadDetails?.address2;
    postalCode = leadDetails?.postalCode;
    remark = leadDetails?.remark;
    submitterUserId = leadDetails?.submitterUserId;
    submitterUserName = leadDetails?.submitterUserName;
    locationCode = leadDetails?.locationCode;
    routerNumber = leadDetails?.routerNumber;
    createdTimeStamp = leadDetails?.createdTimeStamp;
    status = leadDetails?.status;
    endReason = leadDetails?.endReason;
    statusTimeStamp = leadDetails?.statusTimeStamp;
    salesId = leadDetails?.salesId;
    managerId = leadDetails?.managerId;
    accountNumber = leadDetails?.accountNumber;
    debugPrint('leadId : $leadId');
    _LeadId = leadId.toString();

    _companyNameController.text =
        companyName.toString() == 'null' ? ' ' : companyName.toString();
    _customerLastNameController.text =
        lastName.toString() == 'null' ? ' ' : lastName.toString();
    _customerFirstNameController.text =
        firstName.toString() == 'null' ? ' ' : firstName.toString();
    _customerTitleController.text =
        customerTitle.toString() == 'null' ? ' ' : customerTitle.toString();
    _contactPhoneController.text =
        contactPhone.toString() == 'null' ? ' ' : contactPhone.toString();
    _contactMobileController.text =
        contactMobile.toString() == 'null' ? ' ' : contactMobile.toString();
    _addressLineOneController.text =
        address1.toString() == 'null' ? ' ' : address1.toString();
    _addressLineTwoController.text =
        address2.toString() == 'null' ? ' ' : address2.toString();
    _cityController.text = city.toString() == 'null' ? ' ' : city.toString();
    _postalController.text =
        postalCode.toString() == 'null' ? ' ' : postalCode.toString();
    _emailController.text = email.toString() == 'null' ? ' ' : email.toString();
    _remarksController.text =
        remark.toString() == 'null' ? ' ' : remark.toString();

    if (status == '4') {
      endRessoneStatus = newLeadViewModel
          .checkEndResonStatusForFailedToOpenAccountEndReasons(endReason)!;
    } else if (status == '5') {
      endRessoneStatus =
          newLeadViewModel.checkEndResonStatusForInvalidLead(endReason)!;
    } else if (status == '7') {
      endRessoneStatus = newLeadViewModel
          .checkEndResonStatusForInvalidAndFaileToOpen(endReason)!;
    }
  }

  Widget richText(String? name, String? name2) {
    return Container(
      margin: const EdgeInsets.only(
        left: 5,
        top: 5,
      ),
      child: RichText(
        text: TextSpan(
          style: const TextStyle(
            color: Colors.black,
          ),
          children: <TextSpan>[
            TextSpan(text: name.toString(), style: Styles.titleTextWithF12W700),
            TextSpan(
                text: name2.toString(),
                style: const TextStyle(color: Colors.red, fontSize: 15)),
          ],
        ),
      ),
    );
  }

  bool? isCountryCodeOptional(String countryCode) {
    if (countryCode == 'HK' || countryCode == 'VN') {
      return true;
    } else {
      return false;
    }
  }

  @override
  Widget build(BuildContext context) {
    final Map<String, Object?> arg =
        ModalRoute.of(context)!.settings.arguments as Map<String, Object?>;
    selectedLeadOID = arg['leadOID'];
    debugPrint('leadOID : $selectedLeadOID');
    return ScaffoldMessenger(
      key: _scaffoldMessengerKey,
      child: Scaffold(
        appBar: PreferredSize(
            preferredSize:
                const Size.fromHeight(Constant.kStandardAppBarHeight),
            child: CustomHomeAppbar(
              isCheckAppBarButtom: false,
              selectedContext: context,
            )),
        body: _detailUI(),
      ),
    );
  }

  _detailUI() {
    return StreamBuilder(
        stream: newLeadViewModel.leadList,
        builder: (context, AsyncSnapshot<IndividualLeadResponse> snapshot) {
          if (snapshot.hasData) {
            final response = snapshot.data;
            if (response?.serviceStatus?.statusCode == 200) {
              return bodyViewWidget(response!);
            } else {
              return Center(child: Text(response!.serviceStatus!.message!));
            }
          } else if (snapshot.hasError) {
            return Center(child: Text(snapshot.error.toString()));
          }
          return const Center(
            child: CircularProgressIndicator(),
          );
        });
  }

  Container bodyViewWidget(IndividualLeadResponse leadResponse) {
    return Container(
      color: kBackgroundColor,
      margin: const EdgeInsets.all(10),
      child: SingleChildScrollView(
        child: Form(
          key: _formKey,
          child: Padding(
            padding: const EdgeInsets.symmetric(vertical: 0, horizontal: 0),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                const SizedBox(height: 10),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    // SvgPicture.asset('assets/icons/user_profile.svg'),
                    Text(
                      'sales_lead'.tr(),
                      textAlign: TextAlign.start,
                      style: Styles.titleTextWithF26,
                    ),
                    GestureDetector(
                      onTap: () => Navigator.of(context).pop(),
                      child: Row(
                        children: [
                          SvgPicture.asset(
                            Constant.assetsBackArrow,
                            height: 20,
                            width: 20,
                          ),
                          const SizedBox(width: 5),
                          Text(
                            'back'.tr(),
                            textAlign: TextAlign.start,
                            style: Styles.titleTextWithF26,
                          ),
                        ],
                      ),
                    )
                  ],
                ),
                const SizedBox(height: 15),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Expanded(
                        child: Column(
                      crossAxisAlignment: CrossAxisAlignment.stretch,
                      children: [
                        Text(
                          leadResponse.responseData?.data?.leadDetails?.leadId
                              as String,
                          textAlign: TextAlign.start,
                          style: const TextStyle(
                              fontSize: 20, color: kPrimaryColor),
                        ),
                        Text(
                          createdTimeStamp.toString(),
                          textAlign: TextAlign.start,
                          style: Styles.titleGreyTextWithF12W700,
                        ),
                        Text(
                          accountNumber.toString() == null
                              ? accountNumber.toString()
                              : "",
                          textAlign: TextAlign.start,
                          style: Styles.titleTextWithF11W700,
                        ),
                      ],
                    )),
                    Expanded(
                        child: Column(
                      crossAxisAlignment: CrossAxisAlignment.end,
                      children: [
                        Text(
                          'status'.tr(),
                          textAlign: TextAlign.right,
                          style: Styles.titleGreyTextWithF12W700,
                        ),
                        Text(
                          newLeadViewModel.checkStatus(status.toString())
                              as String,
                          textAlign: TextAlign.right,
                          style: Styles.titleGreyTextWithF12W700,
                        ),
                        Text(
                          endRessoneStatus,
                          textAlign: TextAlign.right,
                          style: Styles.titleGreyTextWithF12W700,
                        ),
                      ],
                    )),
                  ],
                ),

                const SizedBox(height: 15),
                //RegExp regExp =  RegExp("[a-zA-Z -]");
                Container(
                  alignment: Alignment.centerLeft,
                  color: xColorlightGrey,
                  child: Column(
                    children: [
                      richText("companyName".tr(), ''),
                      const SizedBox(height: 1),
                    ],
                  ),
                ),

                RoundedTextFormField(
                  readOnly: true,
                  controller: _companyNameController,
                  maxLines: 2,
                  maxLength: 85,
                  regExp: RegExp(Constant.patternChar),
                  textInputType: TextInputType.text,
                  hintText: Constant.companyName,
                  prefixIcon: const Icon(Icons.home_work_outlined),
                  validator: (value) {
                    if (value.toString().length < 2) {
                      return Constant.pleaseProvideComanyName;
                    } else if (value.toString().length > 80) {
                      return "Max 80 Characters Are Allowed";
                    }

                    return null;
                  },
                  onSaved: (value) {
                    _companyName = value!;
                  },
                ),
                const SizedBox(height: 10),
                Container(
                  alignment: Alignment.centerLeft,
                  color: xColorlightGrey,
                  child: Column(
                    children: [
                      richText("customerTitle".tr(), ''),
                      const SizedBox(height: 1),
                    ],
                  ),
                ),

                RoundedTextFormField(
                  readOnly: true,
                  controller: _customerTitleController,
                  maxLines: 1,
                  maxLength: 85,
                  regExp: RegExp(Constant.patternChar),
                  textInputType: TextInputType.text,
                  hintText: Constant.companyName,
                  prefixIcon: const Icon(Icons.home_work_outlined),
                  validator: (value) {
                    if (value.toString().length < 2) {
                      return Constant.pleaseProvideComanyName;
                    } else if (value.toString().length > 80) {
                      return "Max 80 Characters Are Allowed";
                    }

                    return null;
                  },
                  onSaved: (value) {
                    _companyName = value!;
                  },
                ),
                const SizedBox(height: 10),

                Container(
                  alignment: Alignment.centerLeft,
                  color: xColorlightGrey,
                  child: Column(
                    children: [
                      richText("customerFirstName".tr(), ''),
                      const SizedBox(height: 1),
                    ],
                  ),
                ),
                RoundedTextFormField(
                  readOnly: true,
                  controller: _customerFirstNameController,
                  maxLines: 1,
                  maxLength: 62,
                  regExp: RegExp(Constant.patternChar),
                  textInputType: TextInputType.name,
                  hintText: Constant.customerFirstName,
                  prefixIcon: const Icon(Icons.supervised_user_circle),
                  validator: (value) {
                    if (value.toString().length < 2) {
                      return Constant.pleaseProvideCustomerFirstName;
                    } else if (value.toString().length > 60) {
                      return "Max 60 Characters Are Allowed";
                    }
                    return null;
                  },
                  onSaved: (value) {
                    _customerFirstName = value!;
                  },
                ),
                const SizedBox(height: 10),
                Container(
                  alignment: Alignment.centerLeft,
                  color: xColorlightGrey,
                  child: Column(
                    children: [
                      richText("customerLastName".tr(), ''),
                      const SizedBox(height: 1),
                    ],
                  ),
                ),
                RoundedTextFormField(
                  readOnly: true,
                  controller: _customerLastNameController,
                  textInputType: TextInputType.name,
                  maxLines: 1,
                  maxLength: 62,
                  regExp: RegExp(Constant.patternChar),
                  hintText: Constant.customerLastName,
                  prefixIcon: const Icon(Icons.phone),
                  validator: (value) {
                    if (value.toString().length < 2) {
                      return Constant.pleaseProvideCustomerLastName;
                    } else if (value.toString().length > 60) {
                      return "Max 60 Characters Are Allowed";
                    }
                    return null;
                  },
                  onSaved: (value) {
                    _customerLastName = value!;
                  },
                ),
                const SizedBox(height: 10),

                Container(
                  alignment: Alignment.centerLeft,
                  color: xColorlightGrey,
                  child: Column(
                    children: [
                      richText("telephoneNumber".tr(), ''),
                      const SizedBox(height: 1),
                    ],
                  ),
                ),
                RoundedTextFormField(
                  readOnly: true,
                  controller: _contactPhoneController,
                  textInputType: TextInputType.phone,
                  maxLines: 1,
                  maxLength: 15,
                  regExp: RegExp(Constant.pattternPhone),
                  hintText: Constant.telephoneNumber,
                  prefixIcon: const Icon(Icons.email_rounded),
                  validator: (value) {
                    // if (newLeadViewModel.validateMobile(value) != null) {
                    //   return Constant.pleaseProvideTeleNumber;
                    // }
                    return null;
                  },
                  onSaved: (value) {
                    _contactPhone = value!;
                  },
                ),
                const SizedBox(height: 10),
                Container(
                  alignment: Alignment.centerLeft,
                  color: xColorlightGrey,
                  child: Column(
                    children: [
                      richText("mobileNumber".tr(), ''),
                      const SizedBox(height: 1),
                    ],
                  ),
                ),
                RoundedTextFormField(
                  readOnly: true,
                  controller: _contactMobileController,
                  maxLines: 1,
                  maxLength: 15,
                  regExp: RegExp(Constant.pattternPhone),
                  textInputType: TextInputType.phone,
                  hintText: Constant.mobileNumber,
                  prefixIcon: const Icon(Icons.email_rounded),
                  validator: null,
                  onSaved: (value) {
                    _contactPhone = value!;
                  },
                ),
                const SizedBox(height: 10),
                Container(
                  alignment: Alignment.centerLeft,
                  color: xColorlightGrey,
                  child: Column(
                    children: [
                      richText("addressOne".tr(), ''),
                      const SizedBox(height: 1),
                    ],
                  ),
                ),
                RoundedTextFormField(
                  readOnly: true,
                  controller: _addressLineOneController,
                  textInputType: TextInputType.streetAddress,
                  maxLines: 2,
                  maxLength: 75,
                  regExp: RegExp(Constant.pattternEmail),
                  hintText: Constant.addressOne,
                  prefixIcon: const Icon(Icons.remember_me_outlined),
                  validator: (value) {
                    if (value.toString().length < 2) {
                      return Constant.pleaseProvideAddress;
                    } else if (value.toString().length > 70) {
                      return "Max 70 Characters Are Allowed";
                    }
                    return null;
                  },
                  onSaved: (value) {
                    _addressLineOne = value!;
                  },
                ),
                const SizedBox(height: 10),
                Container(
                  alignment: Alignment.centerLeft,
                  color: xColorlightGrey,
                  child: Column(
                    children: [
                      richText("addressTwo".tr(), ''),
                      const SizedBox(height: 1),
                    ],
                  ),
                ),
                RoundedTextFormField(
                  readOnly: true,
                  controller: _addressLineTwoController,
                  textInputType: TextInputType.streetAddress,
                  maxLines: 2,
                  maxLength: 70,
                  regExp: RegExp(Constant.pattternEmail),
                  hintText: Constant.addressTwo,
                  prefixIcon: const Icon(Icons.remember_me_outlined),
                  validator: null,
                  // validator: (value) {
                  //   if (value.toString().length < 2) {
                  //     return Constant.pleaseProvideAddress;
                  //   }
                  //   return null;
                  // },
                  onSaved: (value) {
                    _addressLineTwo = value!;
                  },
                ),
                const SizedBox(height: 10),
                Container(
                  alignment: Alignment.centerLeft,
                  color: xColorlightGrey,
                  child: Column(
                    children: [
                      richText("city".tr(), ''),
                      const SizedBox(height: 1),
                    ],
                  ),
                ),
                RoundedTextFormField(
                  readOnly: true,
                  controller: _cityController,
                  textInputType: TextInputType.name,
                  maxLines: 1,
                  maxLength: 40,
                  hintText: Constant.city,
                  regExp: RegExp(Constant.patternChar),
                  prefixIcon: const Icon(Icons.remember_me_outlined),
                  validator: (value) {
                    if (value.toString().length < 2) {
                      return Constant.pleaseProvideCity;
                    } else if (value.toString().length > 35) {
                      return "Max 35 Characters Are Allowed";
                    }
                    return null;
                  },
                  onSaved: (value) {
                    _city = value!;
                  },
                ),
                const SizedBox(height: 10),

                Container(
                  alignment: Alignment.centerLeft,
                  color: xColorlightGrey,
                  child: Column(
                    children: [
                      richText(
                          "postal".tr(),
                          isCountryCodeOptional(countryCode) == true
                              ? ''
                              : '*'),
                      const SizedBox(height: 1),
                    ],
                  ),
                ),
                RoundedTextFormField(
                  readOnly: true,
                  controller: _postalController,
                  textInputType: TextInputType.name,
                  maxLines: 1,
                  maxLength: 10,
                  regExp: RegExp(Constant.pattternPostal),
                  hintText: Constant.postal,
                  prefixIcon: const Icon(Icons.remember_me_outlined),
                  validator: null,
                  onSaved: (value) {
                    _postal = value!;
                  },
                ),

                const SizedBox(height: 10),
                Container(
                  alignment: Alignment.centerLeft,
                  color: xColorlightGrey,
                  child: Column(
                    children: [
                      richText("email".tr(), ''),
                      const SizedBox(height: 1),
                    ],
                  ),
                ),
                RoundedTextFormField(
                  readOnly: true,
                  controller: _emailController,
                  textInputType: TextInputType.emailAddress,
                  maxLines: 1,
                  maxLength: 60,
                  regExp: RegExp(Constant.pattternEmail),
                  hintText: Constant.email,
                  prefixIcon: const Icon(Icons.remember_me_outlined),
                  validator: (value) {
                    // if (newLeadViewModel.validateEmail(value) != null) {
                    //   return Constant.pleaseProvideEmail;
                    // }
                    return null;
                  },
                  onSaved: (value) {
                    _email = value!;
                  },
                ),
                const SizedBox(height: 10),
                Container(
                  alignment: Alignment.centerLeft,
                  color: xColorlightGrey,
                  child: Column(
                    children: [
                      richText("remarks".tr(), ''),
                      const SizedBox(height: 1),
                    ],
                  ),
                ),
                RoundedTextFormField(
                  readOnly: true,
                  controller: _remarksController,
                  textInputType: TextInputType.multiline,
                  maxLines: 1,
                  maxLength: 500,
                  regExp: RegExp(Constant.pattternEmail),
                  hintText: Constant.remarks,
                  prefixIcon: const Icon(Icons.remember_me_outlined),
                  validator: null,
                  // validator: (value) {
                  //   if (value.toString().length < 2) {
                  //     return Constant.pleaseProvideRemarks;
                  //   }
                  //   return null;
                  // },
                  onSaved: (value) {
                    _remarks = value!;
                  },
                ),
                const SizedBox(height: 10),
                Visibility(
                  visible: isAddComments ? true : false,
                  child: Column(
                    children: [
                      Container(
                        alignment: Alignment.centerLeft,
                        color: xColorlightGrey,
                        child: Column(
                          children: [
                            richText('add_comments'.tr(), ''),
                            const SizedBox(height: 1),
                          ],
                        ),
                      ),
                      RoundedTextFormField(
                        controller: _addCommentsController,
                        textInputType: TextInputType.multiline,
                        maxLines: 2,
                        maxLength: 500,
                        regExp: RegExp(Constant.pattternEmail),
                        hintText: 'ADD Comment',
                        prefixIcon: const Icon(Icons.remember_me_outlined),
                        validator: (value) {
                          if (value.toString().length < 2) {
                            return 'Please Provide Comment';
                          } else {
                            _addComments = value;
                          }
                          return null;
                        },
                        onSaved: null,
                      ),
                    ],
                  ),
                ),

                const SizedBox(height: 25),
                //Add Comments and View comments

                Visibility(
                  visible:
                      newLeadViewModel.isAddCommentsCheck(status.toString()),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      GestureDetector(
                        onTap: () {
                          setState(() {
                            isViewComments = !isViewComments;
                          });
                        },
                        child: Text(
                          'view_all_comments'.tr(),
                          style: Styles.commentTitletBlueWithF14W700,
                        ),
                      ),
                      GestureDetector(
                        onTap: () {
                          setState(() {
                            isAddComments = !isAddComments;
                          });
                        },
                        child: Text(
                          'add_comments'.tr(),
                          style: Styles.commentTitletBlueWithF14W700,
                        ),
                      ),
                    ],
                  ),
                ),
                const SizedBox(height: 10),
                Visibility(
                    visible: isViewComments ? true : false,
                    child: leadCommentsList == []
                        ? SizedBox(
                            height: 20,
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.center,
                              children: [
                                Text(
                                  'no_comments_available'.tr(),
                                  textAlign: TextAlign.center,
                                  style: Styles.titleBlackTextWithF13W700,
                                )
                              ],
                            ),
                          )
                        : viewAllComments(leadCommentsList)),

                const SizedBox(height: 2),

                Visibility(
                  visible: _byteImage == null ? false : isImageVisiable,
                  child: _byteImage == null
                      ? Container()
                      : SizedBox(
                          height: 150,
                          width: 300,
                          child: Image.memory(
                            _byteImage!,
                          ),
                        ),
                ),
                const SizedBox(height: 5),

                Visibility(
                  // ignore: prefer_is_empty
                  visible: leadResponse
                              .responseData?.data?.leadAttachments!.length ==
                          0
                      ? false
                      : true,
                  child: Container(
                    color: xColorlightGrey,
                    padding: const EdgeInsets.all(5.0),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          'attachements'.tr(),
                          style: Styles.titleTextWithF14W700,
                        ),
                        const SizedBox(height: 10),
                        GridView.builder(
                          padding: const EdgeInsets.all(5.0),
                          shrinkWrap: true,
                          gridDelegate:
                              const SliverGridDelegateWithFixedCrossAxisCount(
                            crossAxisCount: 2,
                            crossAxisSpacing: 0.1,
                            mainAxisSpacing: 0.1,
                            childAspectRatio: (2 / 1),
                            mainAxisExtent: 50,
                          ),
                          // ignore: prefer_if_null_operators,
                          itemCount: leadResponse
                                      .responseData?.data?.leadAttachments ==
                                  null
                              ? 0
                              : leadResponse
                                  .responseData?.data?.leadAttachments!.length,
                          itemBuilder: (context, int index) {
                            return Column(
                              mainAxisAlignment: MainAxisAlignment.start,
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Row(
                                  mainAxisAlignment: MainAxisAlignment.start,
                                  children: [
                                    Text(
                                      newLeadViewModel.fileTitleLocal(
                                          leadResponse.responseData?.data
                                              ?.leadAttachments![index].docType
                                              .toString()
                                              .toUpperCase()),
                                      style: Styles.titleTextWithF10W400,
                                    ),
                                  ],
                                ),
                                GestureDetector(
                                  onTap: () {
                                    newLeadViewModel.fetchDownloadDocument(
                                        leadResponse.responseData?.data
                                            ?.leadAttachments![index].docUrl
                                            .toString() as String,
                                        successCallback: successDocCallback,
                                        failureCallback: failureDocCallback);
                                  },
                                  child: Text(
                                    leadResponse.responseData?.data
                                        ?.leadAttachments![index].docName
                                        .toString() as String,
                                    style: Styles.texUnderLinetWithF10W400,
                                  ),
                                ),
                              ],
                            );
                          },
                        ),
                      ],
                    ),
                  ),
                ),

                const SizedBox(height: 10),

                Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Expanded(
                      child: SizedBox(
                        height: 40,
                        child: ElevatedButton(
                          style: ButtonStyle(
                            padding: MaterialStateProperty.all<EdgeInsets>(
                                const EdgeInsets.all(10)),
                            foregroundColor:
                                MaterialStateProperty.all<Color>(Colors.white),
                            backgroundColor:
                                MaterialStateProperty.all<Color>(Colors.white),
                            shape: MaterialStateProperty.all<
                                RoundedRectangleBorder>(
                              RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(1.0),
                                side: const BorderSide(color: xColor, width: 1),
                              ),
                            ),
                          ),
                          child: Text(
                            "cancel".tr(),
                            style: const TextStyle(
                              color: xColor,
                              fontSize: 10,
                              fontWeight: FontWeight.w700,
                            ),
                          ),
                          onPressed: () => Navigator.of(context).pop(),
                        ),
                      ),
                    ),
                    const SizedBox(width: 10),
                    Expanded(
                      child: SizedBox(
                        height: 40,
                        child: ElevatedButton(
                          style: ButtonStyle(
                            foregroundColor:
                                MaterialStateProperty.all<Color>(Colors.white),
                            backgroundColor: MaterialStateProperty.all<Color>(
                                newLeadViewModel.isAddCommentsCheck(
                                            status.toString()) ==
                                        false
                                    ? xColorNormalGrey
                                    : xColor),
                            shape: MaterialStateProperty.all<
                                RoundedRectangleBorder>(
                              RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(1.0),
                                side: BorderSide(
                                    color: newLeadViewModel.isAddCommentsCheck(
                                                status.toString()) ==
                                            false
                                        ? xColorNormalGrey
                                        : xColor,
                                    width: 1),
                              ),
                            ),
                          ),
                          child: Text(
                            'update'.tr(),
                            style: const TextStyle(
                              fontSize: 10,
                              color: kBackgroundColor,
                              fontWeight: FontWeight.w700,
                            ),
                          ),
                          onPressed: newLeadViewModel
                                      .isAddCommentsCheck(status.toString()) ==
                                  false
                              ? null
                              : () {
                                  if (_addCommentsController.text != '') {
                                    _showMyDialog(context);
                                  } else {
                                    showSnackBar(
                                        context, "please_provide_comment".tr());
                                  }
                                },
                          // onPressed: () {
                          //   if (_addCommentsController.text != '') {
                          //     _showMyDialog(context);
                          //   } else {
                          //     showSnackBar(
                          //         context, "please_provide_comment".tr());
                          //   }
                          //},
                        ),
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  WillPopScope viewAllComments(List<LeadComments>? leadComments) {
    return WillPopScope(
      onWillPop: () async => true,
      child: SizedBox(
        height: 100,
        child: CustomScrollView(
          controller: _scrollController,
          slivers: [
            SliverList(
              delegate: SliverChildBuilderDelegate(
                (BuildContext context, int index) {
                  return Container(
                    padding: const EdgeInsets.symmetric(vertical: 5.0),
                    decoration: BoxDecoration(
                      color: index % 2 == 0 ? xColorlightGrey : Colors.white,
                    ),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.stretch,
                      children: [
                        Text(leadComments![index].commentBy.toString(),
                            textAlign: TextAlign.start,
                            style: Styles.titleTextWithF12W700),
                        Text(leadComments[index].comment.toString(),
                            textAlign: TextAlign.start,
                            style: Styles.titleBlackTextWithF13W700),
                        Text(leadComments[index].commentDate.toString(),
                            textAlign: TextAlign.end,
                            style: Styles.titleTextWithF12W700),
                      ],
                    ),
                  );
                },
                childCount: leadComments?.length,
              ),
            ),
          ],
        ),
      ),
    );
  }

  Future<void> _showMyDialog(BuildContext ctx) async {
    return showDialog<void>(
      context: ctx,
      barrierDismissible: false, // user must tap button!
      builder: (BuildContext context) {
        return AlertDialog(
          title:
              Text('leadSubmission'.tr(), style: Styles.titleTextWithF20W700),
          content: SingleChildScrollView(
            child: ListBody(
              children: <Widget>[
                const Text(''),
                Text('are_you_sure'.tr(), style: Styles.titleTextWithF20W700),
              ],
            ),
          ),
          actions: <Widget>[
            ElevatedButton(
              style: ElevatedButton.styleFrom(primary: xColor),
              onPressed: () => Navigator.pop(context, Constant.cancel),
              child: Text(
                'cancel'.tr(),
                style: const TextStyle(
                  fontSize: 12,
                  color: kBackgroundColor,
                  fontWeight: FontWeight.w700,
                ),
              ),
            ),
            ElevatedButton(
              style: ElevatedButton.styleFrom(primary: xColor),
              onPressed: () {
                leadUpdate();
              },
              child: Text(
                'submit'.tr(),
                style: const TextStyle(
                  fontSize: 12,
                  color: kBackgroundColor,
                  fontWeight: FontWeight.w700,
                ),
              ),
            ),
          ],
        );
      },
    );
  }

  leadUpdate() {
    // ignore: unused_local_variable
    final isValid = _formKey.currentState!.validate();
    if (_addComments != '') {
      Provider.of<IndividualLeadSubmitedViewmodel>(context, listen: false)
          .fetchLeadComments(leadDetails, _addComments,
              successCallback: successComments,
              failureCallback: failureComments);

      debugPrint('sucess api call $_addComments');

      Navigator.pop(context, Constant.ok);
      return;
    } else {
      _formKey.currentState!.save();
      Navigator.pop(context, Constant.ok);
      debugPrint('integration API call');
    }
  }
}

class UploadedFile {
  String? fileType;
  File? filePath;

  UploadedFile({
    this.fileType,
    this.filePath,
  });
}
