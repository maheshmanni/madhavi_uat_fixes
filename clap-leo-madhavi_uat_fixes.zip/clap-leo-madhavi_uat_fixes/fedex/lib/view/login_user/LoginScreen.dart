// ignore_for_file: file_names

import 'package:fedex_app/view/login_user/auth_okta_service.dart';
import 'package:fedex_app/view/login_user/user_confirmation_page.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

class LoginScreen extends StatefulWidget {
  const LoginScreen({Key? key}) : super(key: key);

  static const routeName = '/login';

  @override
  State<LoginScreen> createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {
  AuthOktaService? authOktaService;
  @override
  void initState() {
    super.initState();

    authOktaService = AuthOktaService.getInstance();

    if (mounted) {
      initOktaSiginIn();
    }
  }

  void initOktaSiginIn() async {
    authOktaService?.getAccessToken().then((token) async {
      if (token != null) {
        debugPrint('accesstoken : $token');
        //Navigator.of(context).pushNamed(UserConfirmationPage.routeName,
        //    arguments: UserConfirmationPage(authOktaService: authOktaService));
        Navigator.of(context).pushNamed(UserConfirmationPage.routeName);
      } else {
        debugPrint('accesstoken : $token');
        await authOktaService?.authorize();
        authOktaService?.isAuthenticated().then((value) async {
          if (value == true) {
            Navigator.of(context).pushNamed(UserConfirmationPage.routeName);
          } else {
            SystemNavigator.pop();
          }
        });
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    // new AuthOktaService().authorize();
    return Scaffold(
      body: Center(
        child: Container(
            // child: RaisedButton(
            //   color: Colors.blue,
            //   textColor: Colors.black,
            //   onPressed: () async {
            //     await authOktaService.authorize();
            //     authOktaService.isAuthenticated().then((value) {
            //       if (value == true) {
            //         Navigator.of(context)
            //             .pushNamed(UserConfirmationPage.routeName);
            //       } else {
            //         SystemNavigator.pop();
            //       }
            //     });
            //   },
            //   child: const Text('SignIn'),
            // ),
            ),
      ),
    );
  }
}
