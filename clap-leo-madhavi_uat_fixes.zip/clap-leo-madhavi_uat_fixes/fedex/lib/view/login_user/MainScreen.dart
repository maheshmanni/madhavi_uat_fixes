// ignore_for_file: file_names

// import 'package:fedex_app/view/login_user/auth_okta_service.dart';
// import 'package:flutter/material.dart';
// import 'package:flutter/material.dart';
// import 'package:fluttertoast/fluttertoast.dart';
// import 'package:http/http.dart' as http;
// import 'dart:async';

// import 'dart:convert';

// class MainScreen extends StatelessWidget {
//   static const routeName = '/main';
//   bool isAuthenticated = false;

//   parseUser(Map<String, dynamic> json) {
//     return json['name'] as String;
//   }

//   @override
//   Widget build(BuildContext context) {
//     AuthOktaService authOktaService = new AuthOktaService();
//     return Scaffold(
//       body: SingleChildScrollView(
//         child: Center(
//           child: Column(
//             mainAxisSize: MainAxisSize.min,
//             children: <Widget>[
//               const SizedBox(height: 30),
//               RaisedButton(
//                 onPressed: () async {
//                   try {
//                     debugPrint('user info clicked ');

//                     var accessToken = await authOktaService.getAccessToken();
//                     // get(accessToken!);

//                   } catch (e) {
//                     debugPrint('user info error is.. :${e.toString()} ');
//                   }
//                 },
//                 child: const Text('GetUser', style: TextStyle(fontSize: 20)),
//               ),
//               const SizedBox(height: 30),
//               RaisedButton(
//                 onPressed: () async {
//                   await authOktaService.logout();
//                   Navigator.of(context).pushReplacementNamed('/splash');
//                 },
//                 child: const Text('Logout', style: TextStyle(fontSize: 20)),
//               ),
//               const SizedBox(height: 30),
//               RaisedButton(
//                 onPressed: () async {
//                   isAuthenticated = await authOktaService.isAuthenticated();
//                   Fluttertoast.showToast(
//                       msg: "isAuthenticated: ${isAuthenticated.toString()}");
//                 },
//                 child: const Text('IsAuthenticated',
//                     style: TextStyle(fontSize: 20)),
//               ),
//               const SizedBox(height: 30),
//               RaisedButton(
//                 onPressed: () async {
//                   var accessToken = await authOktaService.getAccessToken();
//                   Fluttertoast.showToast(msg: "AccessToken: $accessToken");
//                   debugPrint('access token is...:${accessToken}');
//                 },
//                 child: const Text('GetAccessToken',
//                     style: TextStyle(fontSize: 20)),
//               ),
//               const SizedBox(height: 30),
//               RaisedButton(
//                 onPressed: () async {
//                   var idToken = await authOktaService.getIdToken();
//                   Fluttertoast.showToast(msg: "idToken: $idToken");
//                 },
//                 child: const Text('GetIdToken', style: TextStyle(fontSize: 20)),
//               ),
//               const SizedBox(height: 30),
//               RaisedButton(
//                 onPressed: () async {
//                   var result = await authOktaService.revokeAccessToken();
//                   Fluttertoast.showToast(msg: "result: $result");
//                   Navigator.of(context).pushReplacementNamed('/splash');
//                 },
//                 child: const Text('RevokeAccessToken',
//                     style: TextStyle(fontSize: 20)),
//               ),
//               const SizedBox(height: 30),
//               RaisedButton(
//                 onPressed: () async {
//                   var result = await authOktaService.revokeIdToken();
//                   Fluttertoast.showToast(msg: "result: $result");
//                   Navigator.of(context).pushReplacementNamed('/splash');
//                 },
//                 child:
//                     const Text('RevokeIdToken', style: TextStyle(fontSize: 20)),
//               ),
//               const SizedBox(height: 30),
//               RaisedButton(
//                 onPressed: () async {
//                   var result = await authOktaService.revokeRefreshToken();
//                   Fluttertoast.showToast(msg: "result: $result");
//                   Navigator.of(context).pushReplacementNamed('/splash');
//                 },
//                 child: const Text('RevokeRefreshToken',
//                     style: TextStyle(fontSize: 20)),
//               ),
//               const SizedBox(height: 30),
//               RaisedButton(
//                 onPressed: () async {
//                   var result = await authOktaService.clearTokens();
//                   Fluttertoast.showToast(msg: "result: $result");
//                   Navigator.of(context).pushReplacementNamed('/splash');
//                 },
//                 child:
//                     const Text('ClearTokens', style: TextStyle(fontSize: 20)),
//               ),
//               const SizedBox(height: 30),
//               RaisedButton(
//                 onPressed: () async {
//                   var result = await authOktaService.introspectAccessToken();
//                   Fluttertoast.showToast(msg: "introspectAccessToken: $result");
//                 },
//                 child: const Text('IntrospectAccessToken',
//                     style: TextStyle(fontSize: 20)),
//               ),
//               const SizedBox(height: 30),
//               RaisedButton(
//                 onPressed: () async {
//                   var result = await authOktaService.introspectIdToken();
//                   Fluttertoast.showToast(msg: "introspectIdToken: $result");
//                 },
//                 child: const Text('introspectIdToken',
//                     style: TextStyle(fontSize: 20)),
//               ),
//               const SizedBox(height: 30),
//               RaisedButton(
//                 onPressed: () async {
//                   var result = await authOktaService.introspectRefreshToken();
//                   Fluttertoast.showToast(
//                       msg: "introspectRefreshToken: $result");
//                 },
//                 child: const Text('introspectRefreshToken',
//                     style: TextStyle(fontSize: 20)),
//               ),
//               const SizedBox(height: 30),
//               RaisedButton(
//                 onPressed: () async {
//                   var result = await authOktaService.refreshTokens();
//                   Fluttertoast.showToast(msg: "refreshTokens: $result");
//                 },
//                 child:
//                     const Text('refreshTokens', style: TextStyle(fontSize: 20)),
//               ),
//             ],
//           ),
//         ),
//       ),
//     );
//   }
// }
