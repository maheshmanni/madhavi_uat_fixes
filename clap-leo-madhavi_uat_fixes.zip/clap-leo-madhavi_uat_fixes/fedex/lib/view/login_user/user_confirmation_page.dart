// ignore_for_file: avoid_unnecessary_containers, sized_box_for_whitespace

import 'dart:convert';
import 'package:fedex_app/model/user_model.dart';
import 'package:fedex_app/utility/apis/api_response.dart';
import 'package:fedex_app/utility/constant.dart';
import 'package:fedex_app/utility/styles.dart';
import 'package:fedex_app/utility/theme_colors.dart';
import 'package:fedex_app/view/home/home_page.dart';
import 'package:fedex_app/view/login_user/auth_okta_service.dart';
import 'package:fedex_app/view/widgets/rounded_text_formfield.dart';
import 'package:fedex_app/viewmodel/new_lead_viewmodel.dart';
import 'package:fedex_app/viewmodel/user_view_model.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:easy_localization/easy_localization.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:provider/provider.dart';
// ignore: library_prefixes
import 'package:http/http.dart' as Http;

class UserConfirmationPage extends StatefulWidget {
  static String routeName = '/UserConfirmationPage';
  // AuthOktaService? authOktaService;
  const UserConfirmationPage({Key? key}) : super(key: key);

  @override
  _UserConfirmationPageState createState() => _UserConfirmationPageState();
}

class _UserConfirmationPageState extends State<UserConfirmationPage> {
  final _formKey = GlobalKey<FormState>();

  final _stationIdController = TextEditingController();
  final _routeNumberController = TextEditingController();
  final _scaffoldMessengerKey = GlobalKey<ScaffoldMessengerState>();
  final newLeadViewModel = NewLeadViewModel();
  AuthOktaService? authOktaService;

  setAccessToken() async {
    // final arg =
    //     ModalRoute.of(context)!.settings.arguments as UserConfirmationPage;
    // debugPrint('argument: $arg');

    // final prefs = await SharedPreferences.getInstance();
    // authOktaService?.getAccessToken().then((token) async {
    //   if (token != null) {
    //     debugPrint('setting accesstoken : $token');
    //     // prefs.setString('accessToken', token);
    //     getUserInfo(token);
    //   } else {
    //     debugPrint('accesstoken:----> NULL >>>>');
    //   }
    // });
    authOktaService?.getAccessToken().then((value) {
      if (value != null) {
        debugPrint('token not null callin get user data ');
        authOktaService?.setUserAccessToken(value);
        get(value);
      }
    });
  }

  Future<dynamic> getUserInfo(String token) async {
    debugPrint("====getUserInfo called ");
    debugPrint("==== accesstoken while getting user info : $token");
    try {
      //Pass headers below
      return Http.get(
          Uri.parse(
              "https://${AuthOktaService.OKTA_DOMAIN}/oauth2/aus14jeflq47cJVW20h8/v1/userinfo"),
          headers: {
            "Authorization": "Bearer $token"
          }).then((Http.Response response) {
        final int statusCode = response.statusCode;
        debugPrint("====response : ${response.body}");
        debugPrint("====status code : $statusCode");

        Map<String, dynamic> values = json.decode(response.body);

        //ToDo : need to remove the default values after demo
        // ignore: prefer_is_empty
        if (values.length > 0) {
          authOktaService?.setUserName(values['name'] ?? "");
          authOktaService?.setEmployeeNumber(values['employeeNumber'] ?? "");
          authOktaService?.setCountryCode(values['locale'] ?? "");
          debugPrint('Get CountryCode for OKTA : ${values['locale']}');
        }
      });
    } catch (e) {
      debugPrint(e.toString());
    }
  }

  Future<void> getUserDetail(ApiResponse apiResponse) async {
    UserConfirmationModel? user = apiResponse.data;
    switch (apiResponse.status) {
      case Status.LOADING:
        return debugPrint('Loading...');
      case Status.COMPLETED:
        {
          Navigator.pushNamed(context, HomePageNewPage.routeName);
          return debugPrint('Success... ${user?.responseData?.data}');
        }
      case Status.ERROR:
        // ignore: unused_local_variable
        String msg = 'Please try again latter!';
        if (user != null) {
          msg = user.serviceStatus!.message!;
        }
        showSnackBar(context, user!.serviceStatus!.message!);
        return debugPrint('Error: Please try again latter!');
      case Status.INITIAL:
        break;
    }
  }

  success(response) {
    getUserDetail(response);
  }

  failure(response) {
    if (response != null) {
      getUserDetail(response);
    } else {
      String msg = 'Please try again latter!';
      showSnackBar(context, msg);
    }
  }

  @override
  void initState() {
    super.initState();
    authOktaService = AuthOktaService.getInstance();
    // if (authOktaService?.getEmployeeNumber() == null) {
    // debugPrint("employee number null setting now");
    // authOktaService?.setUserName("Ashish Patil (OSV)");
    // authOktaService?.setEmployeeNumber("4391667");
    // }
    setAccessToken();
  }

  Future<bool> callWillPop() async {
    // ignore: void_checks
    await SystemNavigator.pop().whenComplete(() {
      return true;
    });
    return false;
  }

  @override
  Widget build(BuildContext context) {
    ApiResponse apiResponse = Provider.of<UserViewModel>(context).response;
    return WillPopScope(
        onWillPop: () => callWillPop(),
        child: ScaffoldMessenger(
          key: _scaffoldMessengerKey,
          child: Scaffold(
            body: Container(
              constraints: const BoxConstraints.expand(),
              decoration: const BoxDecoration(
                image: DecorationImage(
                    image: AssetImage(Constant.landingBgIcon),
                    fit: BoxFit.fill),
                //color: Colors.amber,
              ),
              child: SingleChildScrollView(
                child: Container(
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.start,
                    mainAxisSize: MainAxisSize.max,
                    crossAxisAlignment: CrossAxisAlignment.center,
                    children: [
                      Padding(
                        padding: const EdgeInsets.only(
                            left: 50.0, top: 105.0, right: 50.0),
                        child: Image.asset(
                          Constant.logoIcon,
                          fit: BoxFit.contain,
                          width: 150,
                          height: 80,
                        ),
                      ),
                      SizedBox(
                        height: 40,
                        child: apiResponse.status == Status.LOADING
                            ? const Center(child: CircularProgressIndicator())
                            : const SizedBox(height: 0),
                      ),
                      middleViewWidget(),
                    ],
                  ),
                ),
              ),
            ),
          ),
        ));
  }

  Future<dynamic> get(String token) async {
    return Http.get(
        Uri.parse(
            "https://${AuthOktaService.OKTA_DOMAIN}/oauth2/${AuthOktaService.OKTA_AUTHORIZER}/v1/userinfo"),
        headers: {
          "Authorization": "Bearer $token"
        }).then((Http.Response response) {
      final int statusCode = response.statusCode;
      debugPrint("====response : ${response.body}");
      debugPrint("====status code : $statusCode");
      debugPrint("getuser info clicked ,access token ...: $token");

      Map<String, dynamic> values = json.decode(response.body);
      // ignore: prefer_is_empty
      if (values.length > 0) {
        Fluttertoast.showToast(
            msg:
                "User Name : ${values['name']} \n User Id :${values['employeeNumber']}\n Country Code :${values['locale']}");

        authOktaService?.setUserName(values['name'] ?? "");
        authOktaService?.setEmployeeNumber(values['employeeNumber'] ?? "");
        authOktaService?.setCountryCode(values['locale'] ?? "");
        debugPrint('Get CountryCode for OKTA : ${values['locale']}');
        //_postList .add(Post.fromJson(map));           // debugPrint('Id-------${map['id']}');         // }       // }
      }
    });
  }

  Widget middleViewWidget() {
    //AuthOktaService? authOktaService = AuthOktaService.getInstance();
    return Form(
      key: _formKey,
      child: Container(
        height: 370,
        width: 570.0,
        //  height: 350,
        // width: 570.0,
        //color: Colors.amber,
        child: Stack(
          children: <Widget>[
            Positioned(
              // top: 75.0,
              left: 20.0,
              right: 20.0,
              child: Container(
                decoration: const BoxDecoration(
                  image: DecorationImage(
                    image: AssetImage(Constant.courierbg),
                    fit: BoxFit.fill,
                  ),
                ),
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.start,
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: <Widget>[
                    const SizedBox(
                      height: 30.0,
                    ),
                    //const SizedBox(height: 49),
                    Padding(
                      padding: const EdgeInsets.symmetric(horizontal: 35),
                      child: RoundedTextFormField(
                        key: const Key('stationid'),
                        isScreenCheck: true,
                        controller: _stationIdController,
                        maxLength: 5,
                        maxLines: 1,
                        isUperCase: true,
                        fillColor: Colors.white,
                        regExp: RegExp(Constant.patternStnId),
                        textInputType: TextInputType.name,
                        hintText: 'stationIdTitle'.tr(),
                        prefixIcon: const Icon(Icons.home_work_outlined),
                        validator: (value) {
                          if (value.toString().isEmpty) {
                            return 'pleaseProvideStationId'.tr();
                          } else if (value.length < 3) {
                            return 'pleaseProvideValidStationId'.tr();
                          }
                          return null;
                        },
                        onSaved: (value) {},
                      ),
                    ),
                    const SizedBox(height: 8),
                    Padding(
                      padding: const EdgeInsets.symmetric(horizontal: 35),
                      child: RoundedTextFormField(
                        key: const Key('routenumber'),
                        isScreenCheck: true,
                        controller: _routeNumberController,
                        maxLength: 4,
                        maxLines: 1,
                        isUperCase: true,
                        fillColor: Colors.white,
                        regExp: RegExp(Constant.patternRouteNum),
                        textInputType: TextInputType.text,
                        hintText: 'routeNumberTitle'.tr(),
                        prefixIcon: const Icon(Icons.supervised_user_circle),
                        validator: (value) {
                          if (value.toString().isEmpty) {
                            return 'pleaseProvideRouteNumber'.tr();
                          } else if (value.length < 3) {
                            return 'pleaseProvideValidRouteNumber'.tr();
                          }
                          return null;
                        },
                        onSaved: (value) {
                          //_customerFirstName = value!;
                        },
                      ),
                    ),
                    const SizedBox(height: 13),
                    Padding(
                      padding: const EdgeInsets.symmetric(horizontal: 35),
                      child: Container(
                        width: MediaQuery.of(context).size.width,
                        // constraints: const BoxConstraints.expand(),
                        height: 40.0,
                        child: TextButton(
                            key: const Key('submit'),
                            style: TextButton.styleFrom(
                              // shape: RoundedRectangleBorder(
                              //   side: BorderSide(
                              //     //color: pastelGreenColor,
                              //   ),
                              //   borderRadius: BorderRadius.circular(16.0),
                              // ),
                              backgroundColor: xColor,
                            ),
                            onPressed: () {
                              // authOktaService!.getUserLoginStatus().then(
                              //   (value) {
                              //     if (value == false) {
                              //       debugPrint("access token is null");
                              //       SystemNavigator.pop();
                              //     }
                              //   },
                              // );
                              final isValid = _formKey.currentState!.validate();

                              if (isValid) {
                                //Navigator.pushNamed(context, HomePageNewPage.routeName);
                                Provider.of<UserViewModel>(context,
                                        listen: false)
                                    .fetchUserData(
                                        _stationIdController.text.toUpperCase(),
                                        _routeNumberController.text
                                            .toUpperCase(),
                                        successCallback: success,
                                        failureCallback: failure);
                              }
                            },
                            child: Text(
                              'submit'.tr(),
                              style: Styles.titleWhiteTextWithF20W700,
                            )),
                      ),
                    ),
                    const SizedBox(width: 13),
                    Padding(
                      padding: const EdgeInsets.symmetric(horizontal: 50),
                      child: Container(
                          width: MediaQuery.of(context).size.width,
                          // constraints: const BoxConstraints.expand(),
                          height: 40.0,
                          child: TextButton(
                              key: const Key('skip'),
                              onPressed: () {
                                // authOktaService!.getUserLoginStatus().then(
                                //   (value) {
                                //     if (value == false) {
                                //       debugPrint("access token is null");
                                //       SystemNavigator.pop();
                                //     }
                                //   },
                                // );
                                Navigator.pushNamed(
                                    context, HomePageNewPage.routeName);
                              },
                              child: Text('skip'.tr(),
                                  style: Styles.skipButtonF14W400))),
                    ),

                    const SizedBox(height: 5),
                  ],
                ),
              ),
            ),
            /*Positioned(
              left: MediaQuery.of(context).size.width / 2.0 - 69.0 / 2,
              child:
                  // Image.asset(
                  //   userProfileIcon,
                  //   height: 160.0,
                  //   fit: BoxFit.fitHeight,
                  // ),
                  SvgPicture.asset(
                Constant.userProfileIcon,
                width: 138 / 2,
                height: 138 / 2,
              ),
            ),*/
          ],
        ),
      ),
    );
  }

  void showSnackBar(BuildContext context, String text) {
    _scaffoldMessengerKey.currentState!.showSnackBar(
      SnackBar(
        behavior: SnackBarBehavior.floating,
        backgroundColor: Colors.red,
        content: Text(text, style: Styles.titleWhiteTextWithF12W700),
      ),
    );
  }
}
