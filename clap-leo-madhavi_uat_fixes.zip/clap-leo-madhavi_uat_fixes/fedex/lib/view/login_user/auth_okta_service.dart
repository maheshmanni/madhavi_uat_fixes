// ignore_for_file: import_of_legacy_library_into_null_safe, non_constant_identifier_names, unnecessary_this

import 'package:flutter/material.dart';
import 'package:flutter_okta_sdk/flutter_okta_sdk.dart';
import 'package:flutter_okta_sdk/BaseRequest.dart';

import 'dart:async';

import 'package:shared_preferences/shared_preferences.dart';

class AuthOktaService {
  static AuthOktaService? _instance;
  static OktaSDK? oktaSdk;

  AuthOktaService._internal();

  static AuthOktaService getInstance() {
    _instance ??= AuthOktaService._internal();
    oktaSdk = OktaSDK();
    return _instance!;
  }

  static String OKTA_DOMAIN = '';
  static String OKTA_AUTHORIZER = '';
  static String OKTA_CLIENT_ID = '';

  static String OKTA_ISSUER_URL = '';
  static String OKTA_DISCOVERY_URL = '';

  // ignore: constant_identifier_names
  static const String OKTA_REDIRECT_URI = 'com.fedex.eai3538111:/callback';
  // ignore: constant_identifier_names
  static const String OKTA_LOGOUT_REDIRECT_URI = 'com.fedex.eai3538111:/';

//scopes: ['openid', 'profile', 'email', 'offline_access']

  static final oktaBaseRequest = BaseRequest(
      clientId: OKTA_CLIENT_ID,
      discoveryUrl: OKTA_DISCOVERY_URL,
      endSessionRedirectUri: OKTA_LOGOUT_REDIRECT_URI,
      redirectUrl: OKTA_REDIRECT_URI,
      scopes: ['openid', 'profile', 'email', 'offline_access']);

  Future createConfig() async {
    await oktaSdk?.createConfig(oktaBaseRequest);
  }

  Future authorize() async {
    try {
      if (oktaSdk?.isInitialized == false) {
        await this.createConfig();
      }
      debugPrint("OKTA isInitialized... :${oktaSdk?.isInitialized}");
      await oktaSdk?.signIn();
      // var accessToken = getAccessToken();
      // if (accessToken != null) {
      //   accessToken.then((value) {
      //     debugPrint("OKTA accessToken.. :${value}");
      //   });
      //   getUserInfo(accessToken);
      //   // isUserLoggedIn(true);
      // }
    } catch (e) {
      debugPrint("OKTA Error.. :${oktaSdk?.isInitialized}");
    }
  }

  Future logout() async {
    try {
      if (oktaSdk?.isInitialized == false) {
        await this.createConfig();
      }
      await oktaSdk?.signOut();
    } catch (e) {
      debugPrint('$e');
    }
  }

  Future getUser() async {
    try {
      if (oktaSdk?.isInitialized == false) {
        await this.createConfig();
      }
      return await oktaSdk?.getUser();
    } catch (e) {
      debugPrint('$e');
    }
  }

  setUserName(String? userName) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString('userName', userName!);
  }

  setUserAccessToken(String token) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString('accessToken', token);
  }

  Future<String?> getUserName() async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.getString('userName');
  }

  setEmployeeNumber(String? empNum) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString('employeeNumber', empNum!);
  }

  setCountryCode(String? code) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString('OKTACountryCode', code!);
  }

  Future<String?> getEmployeeNumber() async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.getString('employeeNumber');
  }

  // isUserLoggedIn(isSignedIn) async {
  //   final prefs = await SharedPreferences.getInstance();
  //   await prefs.setBool('isSignedIn', isSignedIn);
  // }

  // Future<bool> getUserLoginStatus() async {
  //   final prefs = await SharedPreferences.getInstance();
  //   return prefs.getBool('isSignedIn')!;
  // }

  Future<bool?> isAuthenticated() async {
    try {
      if (oktaSdk?.isInitialized == false) {
        await this.createConfig();
      }
      return await oktaSdk?.isAuthenticated();
    } catch (e) {
      debugPrint('$e');
    }
    return false;
  }

  Future<String?> getAccessToken() async {
    try {
      if (oktaSdk?.isInitialized == false) {
        await this.createConfig();
      }
      return await oktaSdk?.getAccessToken();
    } catch (e) {
      debugPrint('$e');
    }
    return null;
  }

  Future<String?> getIdToken() async {
    try {
      if (oktaSdk?.isInitialized == false) {
        await this.createConfig();
      }
      return await oktaSdk?.getIdToken();
    } catch (e) {
      debugPrint('$e');
    }
    return null;
  }

  Future<bool?> revokeAccessToken() async {
    try {
      if (oktaSdk?.isInitialized == false) {
        await this.createConfig();
      }
      return await oktaSdk?.revokeAccessToken();
    } catch (e) {
      debugPrint('$e');
    }
    return false;
  }

  Future<bool?> revokeIdToken() async {
    try {
      if (oktaSdk?.isInitialized == false) {
        await this.createConfig();
      }
      return await oktaSdk?.revokeIdToken();
    } catch (e) {
      debugPrint('$e');
    }
    return false;
  }

  Future<bool?> revokeRefreshToken() async {
    try {
      if (oktaSdk?.isInitialized == false) {
        await this.createConfig();
      }
      return await oktaSdk?.revokeRefreshToken();
    } catch (e) {
      debugPrint('$e');
    }
    return false;
  }

  Future<bool?> clearTokens() async {
    try {
      if (oktaSdk?.isInitialized == false) {
        await this.createConfig();
      }
      return await oktaSdk?.clearTokens();
    } catch (e) {
      debugPrint('$e');
    }
    return false;
  }

  Future<String?> introspectAccessToken() async {
    try {
      if (oktaSdk?.isInitialized == false) {
        await this.createConfig();
      }
      return await oktaSdk?.introspectAccessToken();
    } catch (e) {
      debugPrint('$e');
    }
    return null;
  }

  Future<String?> introspectIdToken() async {
    try {
      if (oktaSdk?.isInitialized == false) {
        await this.createConfig();
      }
      return await oktaSdk?.introspectIdToken();
    } catch (e) {
      debugPrint('$e');
    }
    return null;
  }

  Future<String?> introspectRefreshToken() async {
    try {
      if (oktaSdk?.isInitialized == false) {
        await this.createConfig();
      }
      return await oktaSdk?.introspectRefreshToken();
    } catch (e) {
      debugPrint('$e');
    }
    return null;
  }

  Future<String?> refreshTokens() async {
    try {
      if (oktaSdk?.isInitialized == false) {
        await this.createConfig();
      }
      return await oktaSdk?.refreshTokens();
    } catch (e) {
      debugPrint('$e');
    }
    return null;
  }
}
