import 'package:fedex_app/model/account_existing_update.dart';
import 'package:fedex_app/model/api_repository.dart';
import 'package:fedex_app/model/individual_account_model.dart';
import 'package:fedex_app/utility/services/base_service.dart';
import 'package:fedex_app/viewmodel/individual_lead_viewmodel.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:shared_preferences/shared_preferences.dart';

void main() {
  setUp(() async {});
  // ignore: unused_local_variable
  final individualLeadViewmodel = IndividualLeadSubmitedViewmodel();

  group('Given individual existing account  load &', () {
    test('Page should get individual existing account  leadOid data', () async {
      final prefs = await SharedPreferences.getInstance();
      String? token = prefs.getString("accessToken");

      IndividualAccountModel individualAccount = await APiRepository()
          .fetchAccountDetails(
              token!, BaseService.existingleadIndividual('2534'),
              baseURL: BaseService.baseAccountUrl);

      expect(individualAccount.serviceStatus?.statusCode, 200);
      expect(individualAccount.serviceStatus?.status, true);
    });
  });

  // group('Given Update individual existing account  load &', () {
  //   test('Page should get Update individual existing account data', () async {
  //     AccountExistingUpdate accountExistingUpdate = await APiRepository()
  //         .updateExistingAccountPenetration(
  //             BaseService.existingleadIndividualUpdated('2534', '1'),
  //             baseURL: BaseService.baseAccountUrl);

  //     expect(accountExistingUpdate.serviceStatus?.statusCode, 200);
  //     expect(accountExistingUpdate.serviceStatus?.status, true);
  //   });
  // });

  group('Given ExistingAccounts individual Comments api loaded & ', () {
    test('Page should get list of comments data', () async {
      //Lead comments request parameter
      final prefs = await SharedPreferences.getInstance();
      String? token = prefs.getString("accessToken");
      final body = {
        "accountOIDs": ['2534'],
        "comment": 'Hi.this is  test comments',
        "endReason": '2',
        "status": '1',
      };

      AccountExistingUpdate addComments = await APiRepository()
          .fetchExistingAccountStatusUpdate(
              BaseService.existingleadStatusCommentsUpdate,
              body,
              token.toString());

      expect(addComments.serviceStatus?.statusCode, 200);
      expect(addComments.serviceStatus?.status, true);
      expect(addComments.serviceStatus?.message,
          addComments.serviceStatus?.message.toString());
    });
  });
}
