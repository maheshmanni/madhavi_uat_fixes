import 'package:fedex_app/model/add_comments.dart';
import 'package:fedex_app/model/api_repository.dart';
import 'package:fedex_app/model/individual_lead_model.dart';
import 'package:fedex_app/utility/common_urls.dart';
import 'package:fedex_app/utility/services/base_service.dart';
import 'package:fedex_app/viewmodel/individual_lead_viewmodel.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:shared_preferences/shared_preferences.dart';

void main() {
  setUp(() async {});

  //lead id - 1459
  // ignore: unused_local_variable
  final individualLeadViewmodel = IndividualLeadSubmitedViewmodel();

  getEmpNumber() async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.getString('employeeNumber')!;
  }

  group('Given Sales Lead page load &', () {
    test('Page should get Sales Lead data', () async {
      //
      final prefs = await SharedPreferences.getInstance();
      String? token = prefs.getString("accessToken");
      IndividualLeadResponse individualLead = await APiRepository()
          .fetchLeadDetails(token!, BaseService.leadIndividual('1459'));

      expect(individualLead.serviceStatus?.statusCode, 200);
      expect(individualLead.serviceStatus?.status, true);
    });
  });

  group('Given Lead Comments api loaded & ', () {
    test('Page should get list of comments data', () async {
      //Lead comments request parameter
      String currentDateStr =
          getCurrentDateTimeFormat("yyyy-MM-dd'T'HH:mm:ss.SSS");
      final body = {
        "accountNumber": "",
        "address1": 'address1',
        "address2": 'address2',
        "city": 'city',
        "clapLeadOid": 1459,
        "comment": "comments",
        "companyName": 'companyName',
        "contactMobile": '89878788',
        "contactPhone": '8372481',
        "customerTitle": 'Mr',
        "email": 'jhgfhg@ghd.com',
        "firstName": 'firstName',
        "lastName": 'lastName',
        "leadEndReason": 'endReason',
        "leadNoteOID": 0,
        "leadStatus": '1',
        "postalCode": '56547',
        "receiverName": "",
        "receiverTimestamp": currentDateStr,
        "receiverUid": "",
        "sendTimeStamp": currentDateStr,
        "statusUpdated": true,
        // ignore: unnecessary_string_interpolations
        "submitterUserId": "${await getEmpNumber()}",
        "submitterUserName": 'shange Lee',
        "userRole": {"1": "COURIER"}
      };

      CommentsResponseModel addComments = await APiRepository()
          .fetchAddComments(BaseService.leadNotes, body, 'token');

      expect(addComments.serviceStatus?.statusCode, 201);
      expect(addComments.serviceStatus?.status, true);
      expect(addComments.serviceStatus?.message,
          addComments.serviceStatus?.message.toString());
    });
  });
}
