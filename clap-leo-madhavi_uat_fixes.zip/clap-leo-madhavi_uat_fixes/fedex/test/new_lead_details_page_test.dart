import 'package:fedex_app/model/api_repository.dart';
import 'package:fedex_app/model/individual_lead_model.dart';
import 'package:fedex_app/utility/services/base_service.dart';
import 'package:fedex_app/viewmodel/individual_lead_viewmodel.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:shared_preferences/shared_preferences.dart';

void main() {
  setUp(() async {});

  //lead id - 1459
  // ignore: unused_local_variable
  final individualLeadViewmodel = IndividualLeadSubmitedViewmodel();

  group('Given Sales Lead page load &', () {
    test('Page should get Sales Lead data', () async {
      //
      final prefs = await SharedPreferences.getInstance();
      String? token = prefs.getString("accessToken");
      IndividualLeadResponse individualLead = await APiRepository()
          .fetchLeadDetails(token!, BaseService.leadIndividual('1459'));

      expect(individualLead.serviceStatus?.statusCode, 200);
      expect(individualLead.serviceStatus?.status, true);
    });
  });
}
