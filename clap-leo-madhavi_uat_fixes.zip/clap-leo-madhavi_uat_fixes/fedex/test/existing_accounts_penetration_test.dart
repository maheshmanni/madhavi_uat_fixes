import 'package:fedex_app/model/account_penetration.dart';
import 'package:fedex_app/model/account_time_frame.dart';
import 'package:fedex_app/model/api_repository.dart';
import 'package:fedex_app/utility/services/base_service.dart';
import 'package:fedex_app/viewmodel/individual_lead_viewmodel.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:shared_preferences/shared_preferences.dart';

getRouteNumber() async {
  final prefs = await SharedPreferences.getInstance();
  return prefs.getString('routeNumber') ?? " ";
}

getEmpNumber() async {
  final prefs = await SharedPreferences.getInstance();
  return prefs.getString('employeeNumber')!;
}

void main() {
  setUp(() async {});
  // ignore: unused_local_variable
  final individualLeadViewmodel = IndividualLeadSubmitedViewmodel();
  String? accToken =
      'eyJraWQiOiJYVThlbm81UDVPVF9GNjJ3R1N6dl9KeHA3RTlYb3VzWnBqTnhTY3lfU1dZIiwiYWxnIjoiUlMyNTYifQ.eyJ2ZXIiOjEsImp0aSI6IkFULnZOcEluaTNvN1ZrVXc3UmdGSVIydE9tR2tqSzhNSFdoMGVUTDRvNXFsZUUub2FyMWs0bG1kdE1Ya3lYUmQwaDciLCJpc3MiOiJodHRwczovL3B1cnBsZWlkLXRlc3Qub2t0YXByZXZpZXcuY29tL29hdXRoMi9hdXMxNGplZmxxNDdjSlZXMjBoOCIsImF1ZCI6IkFQUDM1MzgxMTEiLCJpYXQiOjE2NDgzNzM4ODgsImV4cCI6MTY0ODM3NzQ4OCwiY2lkIjoiMG9hMTRyc2ZyY2NIalF0SGkwaDgiLCJ1aWQiOiIwMHUxNDh4cHNxZHpuQ0luZDBoOCIsInNjcCI6WyJlbWFpbCIsIm9mZmxpbmVfYWNjZXNzIiwicHJvZmlsZSIsIm9wZW5pZCJdLCJhdXRoX3RpbWUiOjE2NDgzNzM4ODYsInN1YiI6IjQzOTE2NjdAdGNvcnAudGVzdC1kcy5mZWRleC5jb20iLCJncm91cHMiOlsiYW1lYV9jbGFwX2xtZF9kZXZfYXBwMzUzODExMSIsImFtZWFfY2xhcF9kaXNwYXRjaF9kZXZfYXBwMzUzODExMSIsImFtZWFfY2xhcF9hZG1pbl9kZXZfYXBwMzUzODExMSIsImFtZWFfY2xhcF9zdXBwb3J0X2Rldl9hcHAzNTM4MTExIiwiYW1lYV9jbGFwX3NhbGVzX2Rldl9hcHAzNTM4MTExIiwiYW1lYV9jbGFwX3N1cGVyX2Rldl9hcHAzNTM4MTExIl0sImVtcGxveWVlTnVtYmVyIjoiNDM5MTY2NyJ9.UmAe7IOQmZ8qf91XJgUHL2Cxkf2FnGO6b2LkemWDLtz5_x6tMXGI6weam_C';

  group('Given AccountTimeFrame page load ', () {
    test('Page should get AccountTimeFrame data', () async {
      // final prefs = await SharedPreferences.getInstance();
      // String? token = prefs.getString("accessToken");
      final body = {
        "routeNumber": "123",
        "userIds": ["4391667"],
        "userRole": "COURIER"
      };
      //
      dynamic response = await APiRepository().fetchTimeFrameDetail(
          BaseService.existingAccountTimeFrame, body, accToken);

      AccountTimeFrame apData = AccountTimeFrame.fromJson(response);

      expect(apData.serviceStatus?.statusCode, 200);
      expect(apData.serviceStatus?.status, true);
    });
  });

  group('Given ExistingAccountPenetration api loaded & ', () {
    test('Page should get ExistingAccountPenetration data', () async {
      // final prefs = await SharedPreferences.getInstance();
      // String? token = prefs.getString("accessToken");
      //Lead comments request parameter
      final body = {
        "filters": {
          "admin": false,
          "date": "",
          "countryCode": "SG",
          "invalidAccounts": "false",
          "market": "",
          "month": "",
          "operation": "AccInProgress",
          "routeNumber": "123",
          "deptNumber": [""],
          "sortBy": "All",
          "sortorder": "DESC",
          "status": "All",
          "support": false,
          "userIds": ["4391667"],
          "userRole": {"1": "COURIER"}
        },
        "pageNumber": 1,
        "pageSize": 10
      };

      dynamic response = await APiRepository().fetchAccountPenetrationDetail(
          BaseService.existingAccountPenetrationList, body, accToken);

      AccountPenetration apData = AccountPenetration.fromJson(response);

      expect(apData.serviceStatus!.statusCode, 200);
      expect(apData.serviceStatus!.status, true);
    });
  });
}
