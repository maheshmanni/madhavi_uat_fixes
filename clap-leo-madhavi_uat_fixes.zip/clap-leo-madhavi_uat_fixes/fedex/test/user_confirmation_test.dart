//import'package:flutter/services.dart';

import 'package:fedex_app/model/api_repository.dart';
import 'package:fedex_app/model/user_model.dart';
import 'package:fedex_app/viewmodel/user_view_model.dart';
import 'package:flutter_test/flutter_test.dart';

void main() {
  setUp(() async {});

  // ignore: unused_local_variable
  final viewModel = UserViewModel();

  group('Given User confirmation page load', () {
    test('Page should get user confirmation data', () async {
      String? accToken =
          'eyJraWQiOiJYVThlbm81UDVPVF9GNjJ3R1N6dl9KeHA3RTlYb3VzWnBqTnhTY3lfU1dZIiwiYWxnIjoiUlMyNTYifQ.eyJ2ZXIiOjEsImp0aSI6IkFULnZOcEluaTNvN1ZrVXc3UmdGSVIydE9tR2tqSzhNSFdoMGVUTDRvNXFsZUUub2FyMWs0bG1kdE1Ya3lYUmQwaDciLCJpc3MiOiJodHRwczovL3B1cnBsZWlkLXRlc3Qub2t0YXByZXZpZXcuY29tL29hdXRoMi9hdXMxNGplZmxxNDdjSlZXMjBoOCIsImF1ZCI6IkFQUDM1MzgxMTEiLCJpYXQiOjE2NDgzNzM4ODgsImV4cCI6MTY0ODM3NzQ4OCwiY2lkIjoiMG9hMTRyc2ZyY2NIalF0SGkwaDgiLCJ1aWQiOiIwMHUxNDh4cHNxZHpuQ0luZDBoOCIsInNjcCI6WyJlbWFpbCIsIm9mZmxpbmVfYWNjZXNzIiwicHJvZmlsZSIsIm9wZW5pZCJdLCJhdXRoX3RpbWUiOjE2NDgzNzM4ODYsInN1YiI6IjQzOTE2NjdAdGNvcnAudGVzdC1kcy5mZWRleC5jb20iLCJncm91cHMiOlsiYW1lYV9jbGFwX2xtZF9kZXZfYXBwMzUzODExMSIsImFtZWFfY2xhcF9kaXNwYXRjaF9kZXZfYXBwMzUzODExMSIsImFtZWFfY2xhcF9hZG1pbl9kZXZfYXBwMzUzODExMSIsImFtZWFfY2xhcF9zdXBwb3J0X2Rldl9hcHAzNTM4MTExIiwiYW1lYV9jbGFwX3NhbGVzX2Rldl9hcHAzNTM4MTExIiwiYW1lYV9jbGFwX3N1cGVyX2Rldl9hcHAzNTM4MTExIl0sImVtcGxveWVlTnVtYmVyIjoiNDM5MTY2NyJ9.UmAe7IOQmZ8qf91XJgUHL2Cxkf2FnGO6b2LkemWDLtz5_x6tMXGI6weam_C';
      final body = {
        "countryCode": 'SG',
        "routerNumber": '123',
        "stationCode": 'SINA'
      };
      // final prefs = await SharedPreferences.getInstance();
      // String? token = prefs.getString("accessToken");
      UserConfirmationModel user = await APiRepository()
          .fetchUserConfirmationDetail('lead/station', body, "");

      expect(user.serviceStatus?.statusCode, 200);
      //expect(user.serviceStatus?.statusCode, 201);
      expect(user.responseData?.data?.countryCode, 'SG');
    });
  });

  // group('Given User confirmation: set preference function call', () {
  //   test('Objects should get from sharedpreference', () async {
  //     await viewModel.setPreferenceData('THAI', '123', 'TI');

  //     final pref = await SharedPreferences.getInstance();

  //     expect(pref.getString('stationId'), 'THAI');
  //     expect(pref.getString('routeNumber'), '123');
  //     expect(pref.getString('countryCode'), 'TI');
  //   });
  // });
}
