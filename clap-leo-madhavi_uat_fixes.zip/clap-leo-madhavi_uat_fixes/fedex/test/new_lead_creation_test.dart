import 'package:fedex_app/model/api_repository.dart';
import 'package:fedex_app/model/new_lead_model.dart';
import 'package:fedex_app/utility/services/base_service.dart';
import 'package:fedex_app/viewmodel/new_lead_viewmodel.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:shared_preferences/shared_preferences.dart';

getRouteNumber() async {
  final prefs = await SharedPreferences.getInstance();
  return prefs.getString('routeNumber') ?? " ";
}

getEmpNumber() async {
  final prefs = await SharedPreferences.getInstance();
  return prefs.getString('employeeNumber')!;
}

void main() {
  setUp(() async {});

  // ignore: unused_local_variable
  final newLeadViewModel = NewLeadViewModel();

  group('Given New Lead creation page load', () {
    test('Page should get new lead creation data', () async {
      final prefs = await SharedPreferences.getInstance();
      String? token = prefs.getString("accessToken");
      final jsonBody = {
        "address1": "Special 1 Dongfeng Avenue Economic Technology",
        "address2": "Dvpt Zone Wuhan",
        "city": "China",
        "companyName": "Dongfeng Motor Corporation",
        "contactMobile": "8764563746",
        "contactPhone": "6452846538",
        "customerTitle": "Mr",
        "email": "wang.shu@www.dfmc.com.cn",
        "endReason": null,
        "firstName": "Wang ",
        "lastName": "Shu",
        "locationCode": "SINA",
        "managerId": "string",
        "postalCode": "430056 ",
        "readyForAccountOpening": false,
        "remark": "Hi,thanks",
        "routerNumber": "${await getRouteNumber()}",
        "status": "1",
        "submitterUserId": "${await getEmpNumber()}",
        "submitterUserName": "Shang Lee"
      };
      LeadResponseData leadResponse = (await APiRepository()
          .fetchNewLeadData(BaseService.lead, jsonBody, token.toString()));

      expect(leadResponse.serviceStatus?.statusCode, 201);
      expect(leadResponse.serviceStatus?.status, true);

      //expect(user.serviceStatus?.statusCode, 201);
      //expect(leadResponse.responseData?.data, 'TI');
    });
  });
}
