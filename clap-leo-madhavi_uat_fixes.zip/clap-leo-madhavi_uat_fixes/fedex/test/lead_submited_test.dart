//import'package:flutter/services.dart';

import 'package:fedex_app/model/api_repository.dart';
import 'package:fedex_app/model/lead_list_model.dart';
import 'package:fedex_app/utility/services/base_service.dart';
import 'package:fedex_app/viewmodel/lead_list_view_model.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:shared_preferences/shared_preferences.dart';

void main() {
  setUp(() async {});

  // ignore: unused_local_variable
  final viewModel = LeadListViewModel();

  getEmpNumber() async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.getString('employeeNumber')!;
  }

  getCountryCode() async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.getString('countryCode') ?? " ";
  }

  group('Given Lead submited page load', () {
    test('Page should get Lead submited data', () async {
      // final body = {
      //   "filters": {
      //     "date": "",
      //     "sortBy": "All",
      //     "sortorder": "DESC",
      //     "status": "All"
      //   },
      //   "pageNumber": "1",
      //   "pageSize": "10"
      // };

      final body = {
        "filters": {
          "admin": false,
          // ignore: unnecessary_string_interpolations
          "countryCode": "${await getCountryCode()}",
          "date": '02/24/22', //mm/dd/yy
          "deptNumber": [""],
          "sortBy": 'All',
          "sortorder": "DESC",
          "status": 'All',
          "support": false,
          // ignore: unnecessary_string_interpolations
          "userIds": ["${await getEmpNumber()}"],
          "userRole": {"1": "COURIER"}
        },
        "pageNumber": 1,
        "pageSize": 10
      };

      dynamic response = await APiRepository()
          .fetchLeadListDetail(BaseService.leadSubmitedList, body, 'token');
      LeadListModel leadListModel = LeadListModel.fromJson(response);

      expect(leadListModel.serviceStatus?.statusCode, 200);
      expect(leadListModel.serviceStatus?.status, true);
    });
  });
}
