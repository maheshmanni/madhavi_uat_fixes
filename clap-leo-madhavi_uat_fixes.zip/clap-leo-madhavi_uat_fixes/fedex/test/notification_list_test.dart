import 'package:fedex_app/model/api_repository.dart';
import 'package:fedex_app/model/notification_response.dart';
import 'package:fedex_app/utility/services/base_service.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:shared_preferences/shared_preferences.dart';

getEmpNumber() async {
  final prefs = await SharedPreferences.getInstance();
  return prefs.getString('employeeNumber')!;
}

void main() {
  setUp(() async {});

  group('Given submitter id &', () {
    test('Page should get list of notifications for the submitter ID',
        () async {
      final prefs = await SharedPreferences.getInstance();
      String? token = prefs.getString("accessToken");
      NotificationResponse notificationResponse = await APiRepository()
          .fetchNotificationDetails(
              BaseService.notification("${await getEmpNumber()}"),
              token.toString());

      expect(notificationResponse.serviceStatus?.statusCode, 200);
      expect(notificationResponse.serviceStatus?.status, true);
    });
  });

  // group('Given selected notification details', () {
  //   test('Page should the confirmation on Read Notification', () async {
  //     final jsonbody = [
  //       {
  //         "id": leadIOD,
  //         "title": title,
  //         "body": body,
  //         "type": type,
  //         "from": from,
  //         "noteOID": leadNoteOID
  //       }
  //     ];

  //     NotificationResponse notifResponse = await APiRepository()
  //         .readNotification(BaseService.readNotification(), jsonbody);

  //     expect(notifResponse.serviceStatus?.statusCode, 200);
  //     // expect(notifResponse.serviceStatus?.statusCode, 201);
  //   });
  // });
}
