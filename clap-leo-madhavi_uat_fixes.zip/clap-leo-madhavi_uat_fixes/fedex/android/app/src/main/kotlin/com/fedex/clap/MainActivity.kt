package com.fedex.clap

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
